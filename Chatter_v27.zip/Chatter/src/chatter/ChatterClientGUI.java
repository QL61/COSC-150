package chatter;

import javax.swing.*;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

/**
 * ChatterClientGUI class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class ChatterClientGUI extends JFrame implements ActionListener, KeyListener{

	private static final long serialVersionUID = 1L;
	private static final String WELCOME_TO_CHAT = "Welcome to the Chatroom\n";
	private static final String TYPE_CHAT_MSG = "Type Chat Message Here \n";
	private static final String NICK_NAME_COMMAND = "Type /nick \'name\' to change nickname";
	private static final String SLASH_NICK = "/nick";
	private static final String INVALID_UN = "Invalid Username (username may already be taken "
			+ "and cannot contain spaces). Please try again.";
	private static final String USER_LOGON_MSG = " logged on! Say hi!\n\n";
	private static final String LOGOUT_MSG = " Logged off :(\n\n";
	private JLabel usernameLabel;							// label for username
	private JTextField username;							// hold current username
	private JTextField tfServer, tfPort;					// write server address and port number
	private JButton loginBtn, sendBtn, exitBtn;				// buttons
	private JComboBox usernameList; 						// list of clients
	private JTextArea taMsgHistory;							// message history text area
	private JTextArea taMessenger;							// text box
	private int defaultPort;								// the default port number
	private String defaultIP;								// the default ip
	private ChatterClient client;
	
	// Constructor connection receiving a socket number
	ChatterClientGUI(String host, int port) {		
		//System.out.println("inside clientGUI constructor");
		
		super("Chat Client");
		defaultPort = port;
		defaultIP = host;
		
		// The NorthPanel
		JPanel northPanel = new JPanel(new GridLayout(3,2)); // the server name and port number
		JPanel serverAddress = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for server address
		JPanel portNumber = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for port number
		tfServer = new JTextField(defaultIP);
		tfPort = new JTextField("" + defaultPort);
		tfPort.setHorizontalAlignment(SwingConstants.RIGHT);

		serverAddress.add(new JLabel("Server Address:  "));
		serverAddress.add(tfServer);
		portNumber.add(new JLabel("Port Number:  "));
		portNumber.add(tfPort);
		// adds Server port field to GUI
		northPanel.add(serverAddress, BorderLayout.NORTH);
		northPanel.add(portNumber, BorderLayout.NORTH);

		// UsernameLabel and username TextField
		usernameLabel = new JLabel("Enter your username below", SwingConstants.CENTER);
		northPanel.add(usernameLabel, BorderLayout.LINE_START);
		northPanel.add(new JLabel(""));
		username = new JTextField("Anonymous");
		username.setBackground(Color.WHITE);
		northPanel.add(username, BorderLayout.SOUTH);

		// username list creation
		PopupMenuListener pmListener = new PopupMenuListener() {
			boolean initialized = false;
			
			@Override
			public void popupMenuCanceled(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				String[] initList = {"G r o u p"};
				if (!initialized) {
					usernameList = (JComboBox) e.getSource();
					ComboBoxModel model = new DefaultComboBoxModel(initList);
					usernameList.setModel(model);
					initialized = true;
				}
				//else {
					System.out.println("should remove " + usernameList.getItemCount() + " -1 items");
					
					for (int i = usernameList.getItemCount()-1; i > 0; i--) {
						//System.out.println("will remove " + usernameList.getItemAt(i));

						usernameList.removeItemAt(i);
					}
					for (int i = 0; i < client.getNameList().size(); i++) {
						//System.out.println("adding " + client.getNameList().get(i));
						usernameList.addItem(client.getNameList().get(i));
					}
				}
		};
		usernameList = new JComboBox();
		usernameList.addItem("G r o u p");
		usernameList.setSelectedItem("G r o u p");
		usernameList.addPopupMenuListener(pmListener);
		usernameList.addActionListener(this);
		usernameList.setEnabled(false);
		northPanel.add(usernameList, BorderLayout.SOUTH);
		//add to frame
		add(northPanel, BorderLayout.NORTH);

		// CenterPanel
		taMsgHistory = new JTextArea(WELCOME_TO_CHAT, 80, 80);
		JPanel centerPanel = new JPanel(new GridLayout(1,1));
		centerPanel.add(new JScrollPane(taMsgHistory));
		taMsgHistory.setEditable(false);

		// MessengerPanel
		taMessenger = new JTextArea(TYPE_CHAT_MSG + NICK_NAME_COMMAND);
		taMessenger.setBackground(Color.WHITE);
		taMessenger.setEditable(false);
		taMessenger.addKeyListener(this);
		centerPanel.add(taMessenger);
		add(centerPanel, BorderLayout.CENTER);
		
		// button creation
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(this);
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		exitBtn.setEnabled(false);		// must login before being able to exit
		sendBtn = new JButton("Send");
		sendBtn.addActionListener(this);
		sendBtn.setEnabled(false);

		JPanel southPanel = new JPanel();
		southPanel.add(loginBtn);
		southPanel.add(sendBtn);
		southPanel.add(exitBtn);
		add(southPanel, BorderLayout.SOUTH);
		
		//set the word wrap of message history and Messenger
		taMessenger.setWrapStyleWord(true);
		taMessenger.setLineWrap(true);
		taMsgHistory.setWrapStyleWord(true);
		taMsgHistory.setLineWrap(true);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				exitBtn.doClick();
			}
		});

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(750, 500);
		setVisible(true);
		taMessenger.requestFocus();
	}

	/**
	 * for enter key being pressed
	 */
	public void keyPressed(KeyEvent e) {
		if(sendBtn.isEnabled()) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER){
				sendBtn.doClick();
			}
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER && 
				!(taMessenger.getText().trim().equals(INVALID_UN.trim()))) {			
			taMessenger.setText("");
		}
	}
	
	/**
	 * Button or JTextField clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// check for which button is pressed
		if(e.getSource() == exitBtn) {

			//Send exit command to the server
			Map<String, String> messageInfo = new HashMap<String, String>();
			messageInfo.put("type", ChatterMessage.EXIT);
			messageInfo.put("sender", client.getClientUsername());
			messageInfo.put("recipient", client.getClientUsername());
			messageInfo.put("message",client.getClientUsername() + LOGOUT_MSG);
			client.sendMessage(new ChatterMessage(messageInfo));
			
			//disable all buttons
			sendBtn.setEnabled(false);
			exitBtn.setEnabled(false);
			loginBtn.setEnabled(false);
			taMessenger.setEditable(false);
			usernameList.setEnabled(false);
			taMsgHistory.setText("Logged off. Goodbye!");  //display bye to the user
					
		}
		else if (e.getSource() == sendBtn) {
			//System.out.println("click was sendBtn:: in sendBtn:: ");
			
			String msg = taMessenger.getText();
			String messageType = "";

			if (msg.indexOf(SLASH_NICK) != -1) {
				String nickChangeStr = msg.substring(msg.indexOf(SLASH_NICK) + SLASH_NICK.length());
				//System.out.println("----" + nickChangeStr + "-----");
				nickChangeStr = nickChangeStr.trim();
				if (checkValidUsernameInput(nickChangeStr)) {
					client.setUsername(nickChangeStr);
					username.setText(nickChangeStr);
					taMessenger.setText("");
				}
				else {
					//System.out.println("invalid username put in taMessenger");
					taMessenger.setText(INVALID_UN);
				}
			}			
			else { 
				if (((String) usernameList.getSelectedItem()).equalsIgnoreCase("g r o u p")) {
					messageType = ChatterMessage.PUBLIC;
				}
				else {
					messageType = ChatterMessage.PRIVATE;
				}

				Map<String, String> messageInfo = new HashMap<String, String>();
				messageInfo.put("type", messageType);
				messageInfo.put("sender", client.getClientUsername());
				messageInfo.put("recipient", (String) usernameList.getSelectedItem());
				messageInfo.put("message", msg + "\n\n");

				if ( messageType.equals(ChatterMessage.PRIVATE) ) {
					taMsgHistory.append(client.getClientUsername() + " to " 
							+ (String) usernameList.getSelectedItem() + ": " + msg + "\n\n");
				}

				client.sendMessage(new ChatterMessage(messageInfo));
				taMessenger.setText("");
			}
		}
		else if(e.getSource() == loginBtn) {
			//System.out.println("actionPerformed: in loginBtn");

			// connection requested
			if (checkValidUsernameInput(getUsername())) {
				String username = getUsername().trim();
				String server = tfServer.getText().trim();
				String portNumber = tfPort.getText().trim();

				// create new Client
				client = new ChatterClient(server, Integer.parseInt(portNumber), username, this);
				// test to start Client
				if(!client.start()) 
					return;

				if (client.getNameList() != null) {
					for (int i = 0; i < client.getNameList().size(); i++) {
						usernameList.addItem(client.getNameList().get(i));
					}				
				}
				usernameLabel.setText(NICK_NAME_COMMAND);
				usernameList.setEnabled(true);
				//enable username List
				this.username.setEditable(false);
				// disable login button
				loginBtn.setEnabled(false);
				// enable the 2 buttons
				exitBtn.setEnabled(true);
				sendBtn.setEnabled(true);
				// disable the Server and Port JTextField
				tfServer.setEditable(false);
				tfPort.setEditable(false);
				taMessenger.setEditable(true);	
				taMessenger.setFocusable(true);
				// Action listener for when the user enter a message
				taMessenger.addFocusListener(new FocusListener() {
					public void focusGained(FocusEvent e) {}
					public void focusLost(FocusEvent e) {}
				});

				
				client.sendMessage(new ChatterMessage(ChatterMessage.PUBLIC, username, 
						(String) usernameList.getSelectedItem(), username + USER_LOGON_MSG));
				
				//printChatHistory();
			}
			else {
				usernameLabel.setText(INVALID_UN);
			}
		}
	}

	public void printChatHistory(ChatterMessage cm) {		
		String msgSender = cm.getSender();
		String msgReceiver = cm.getRecipient();

		if (cm.getMessageType().equals(ChatterMessage.PUBLIC) && cm.getMessage().contains(USER_LOGON_MSG)) {
			taMsgHistory.append("SERVER >> " + cm.getMessage());
		}
		else if (cm.getMessageType().equals(ChatterMessage.PUBLIC)) {
			System.out.println(msgSender + " is the sender of this public message");
			taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
		}
		else if ( cm.getMessageType().equals(ChatterMessage.PRIVATE) ) {
			if ( msgReceiver.equals(client.getClientUsername()) ) {
				taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
			}
		}
	}

	private boolean checkValidUsernameInput(String text) {
		boolean validUN = false;
		if (client != null) {
			for (int i = 0; i < client.getNameList().size(); i++) {
				String nameCompare = client.getNameList().get(i);
				if (text.equals(nameCompare)) {
					validUN = true;
				}
			}
		}
		if (!(validUN || text.contains(" ") || text.equals(""))) {
			validUN = true;
		}
		return validUN;
	}
		
	public String getUsername() {
		return username.getText();
	}

	@Override
	public void keyTyped(KeyEvent e) {}
	
} //end of ChatterClientGui class
