package paint;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 * Triangle class
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public class Triangle extends Shape {

	//constants
	private static final double DEFAULT_EMPTY_VALUE = 0.0;
	private static final String SIDE_STRING_1 = "side1";
	private static final String SIDE_STRING_2 = "side2";
	private static final String SIDE_STRING_3 = "side3";
	private static final int MAX_COORD = 3;

	//class member variables
	private double side1;
	private double side2;
	private double side3;
	private Coordinates v1, v2, v3;

	/**
	 * Triangle constructor
	 * @param args	a hashmap that contains the shape and associated side values
	 */
	Triangle(ArrayList<Coordinates>coordList, Color color) {
		setCoordinates(coordList);
		this.color = color;
	}

	/**
	 * sets value of v1
	 * @param c1
	 */
	private void setV1(Coordinates c1) {
		v1 = c1;
	}
	
	/**
	 * sets value of v2
	 * @param c1
	 */
	private void setV2(Coordinates c1) {
		v2 = c1;
	}
	
	/**
	 * sets value of v3
	 * @param c1
	 */
	private void setV3(Coordinates c1) {
		v3 = c1;
	}
	/**
	 * sets value of side1
	 * @param sideValue
	 */
	private void setSide1(Coordinates c1, Coordinates c2) {
		side1 = distanceBetween(c1, c2);
	}


	/**
	 * sets value of side2
	 * @param sideValue
	 */
	private void setSide2(Coordinates c1, Coordinates c2) {
		side2 = distanceBetween(c1, c2);		
	}


	/**
	 * sets value of side3
	 * @param sideValue
	 */
	private void setSide3(Coordinates c1, Coordinates c2) {
		side3 = distanceBetween(c1, c2);
	}

	/**
	 * @return v1 the value of side1
	 */
	protected Coordinates getV1() {
		return v1;
	}

	/**
	 * @return v2 the value of side1
	 */
	protected Coordinates getV2() {
		return v2;
	}

	/**
	 * @return v3 the value of side1
	 */
	protected Coordinates getV3() {
		return v3;
	}

	
	/**
	 * @return side1 the value of side1
	 */
	protected double getSide1() {
		return side1;
	}

	/**
	 * @return side2 the value of side2
	 */
	protected double getSide2() {
		return side2;
	}

	/**
	 * @return side3 the value of side3
	 */
	protected double getSide3() {
		return side3;
	}

	/**
	 * @return tempArea the area of the triangle
	 */
	public double getArea() {
		double intermediateS = 0;
		double tempArea = 0;

		intermediateS = (side1 + side2 + side3)/2;
		if (side1 > DEFAULT_EMPTY_VALUE && side2 > DEFAULT_EMPTY_VALUE && side3 > DEFAULT_EMPTY_VALUE) {
			tempArea = Math.sqrt(intermediateS*(intermediateS-side1)*(intermediateS-side2)*(intermediateS-side3));		
		}
		return tempArea;
	}

	/**
	 * @return tempPerimeter the perimeter of the triangle
	 */
	public double getPerimeter() {
		double tempPerimeter = 0;
		if (side1 > DEFAULT_EMPTY_VALUE && side2 > DEFAULT_EMPTY_VALUE && side3 > DEFAULT_EMPTY_VALUE) {
			tempPerimeter = side1 + side2 + side3;
		}
		return tempPerimeter;
	}

	
	@Override
	public void setCoordinates(ArrayList<Coordinates> coordList) {
		int currentPos = 0;
		if (coordList.size() >= MAX_COORD) {
			setV1(coordList.get(currentPos));
			currentPos++;
			setV2(coordList.get(currentPos));
			currentPos++;
			setV3(coordList.get(currentPos));
			setSide1(v1, v2);
			setSide2(v1, v2);
			setSide3(v2, v3);
		}
		else System.out.println("Invalid number of coordinates");
	}

	@Override
	public void drawShape(Graphics g) {
		// TODO Auto-generated method stub
		
	}
}
