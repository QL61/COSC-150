package paint;

import java.awt.Color;
import java.awt.Graphics;


/**
 * abstract Shape class
 * It is the parent class for various shapes
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public abstract class Shape {
	
	// Member variables
	protected Color color;
	
	// METHODS
	public abstract double getArea();
	public abstract double getPerimeter();	
	public abstract void drawShape(Graphics g);
	public abstract boolean isInRange(Coordinates c);
	public abstract void resize (Coordinates press, Coordinates release);

	public double distanceBetween(Coordinates a, Coordinates b) {
		return Math.sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
	}
	public Color getColor() { return this.color; }
}

