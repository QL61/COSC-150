package paint;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Ellipse2D;
import java.lang.Math;

/**
 * Oval class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class Oval extends Shape {
	
	// FIELDS
	private	double maj = 0, min = 0;
	private Coordinates v1, v2, v3, v4;

	// CONSTRUCTOR
	public Oval(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(new Coordinates(release.x, press.y));
		setV3(release);
		setV4(new Coordinates(press.x, release.y));
		this.updateAxes();
		this.color = color;
	}
	
	// METHODS
	/**
	 * calculate area of oval
	 * 
	 * @return double area
	 */
	@Override public double getArea() {
		System.out.println("maj = " +maj + " min = " +min);
		return Math.PI * maj/2 * min/2;
	}
	
	/**
	 * calculate perimeter of oval
	 * 
	 * @return double perimeter
	 */
	@Override public double getPerimeter() { // calculated using Ramanujan's Formula 1
		return Math.PI*(3*(maj/2+min/2)-Math.sqrt((3*maj/2+min/2)*(maj/2+3*min/2)));
	}
	
	/**
	 * set V1
	 * 
	 * @param Coordinate c
	 */
	public void setV1(Coordinates c) {
		this.v1 = c;
		this.updateAxes();
	}
	
	/**
	 * set V2
	 * 
	 * @param Coordinate c
	 */	
	public void setV2(Coordinates c) {
		this.v2 = c;
		this.updateAxes();
	}
	
	/**
	 * set V3
	 * 
	 * @param Coordinate c
	 */
	public void setV3(Coordinates c) {
		this.v3 = c;
		updateAxes();
	}
	
	/**
	 * set V4
	 * 
	 * @param Coordinate c
	 */
	public void setV4(Coordinates c) {
		this.v4 = c;
		updateAxes();
	}
	
	
	/**
	 * set major axis length
	 * 
	 * @param double w
	 */
	public void setMajAxis(double w) {
		this.maj = w;
	}
	
	/**
	 * set minimum axis length
	 * 
	 * @param double h
	 */
	public void setMinAxis(double h) {
		this.min = h;
	}
	
	/**
	 * get V1
	 * 
	 * @return Coordinates v1
	 */
	public Coordinates getV1() {
		return v1;
	}
	
	/**
	 * get V2
	 * 
	 * @return Coordinates v2
	 */
	public Coordinates getV2() {
		return v2;
	}
	
	/**
	 * get V3
	 * 
	 * @return Coordinates v3
	 */
	public Coordinates getV3() {
		return v3;
	}
	
	/**
	 * get V4
	 * 
	 * @return Coordinates v4
	 */
	public Coordinates getV4() {
		return v4;
	}
	
	/**
	 * get major axis length
	 * 
	 * @return double maj
	 */
	public double getMajAxis() {
		return maj;
	}

	/**
	 * get minor axis length
	 * 
	 * @return double min
	 */
	public double getMinAxis() {
		return min;
	}
	

	/**
	 * update the Axes to reflect changes to shape
	 */
	private void updateAxes() {
		//v1 and v3 cannot be null in order for the shape to update 
		//the axes
		if (getV1() != null && getV3() != null ) {
			double h = Math.abs((v1.getX() - v3.getX()));
			double v = Math.abs((v1.getY() - v3.getY()));

			//set major and minor axes length
			setMajAxis(h);
			setMinAxis(v);
		}
	}


	/**
	 * check to see if coordinates fall 
	 * within the shape.
	 * 
	 * @param Coordinates c
	 * @return boolean inRange
	 */
	@Override
	public boolean isInRange(Coordinates c) {
		boolean inRange = false;
		
		//create a 2d ellipse to check to see if shape contains the point
		Ellipse2D curOval = new Ellipse2D.Double(v1.getX(), v1.getY(), getMajAxis(), getMinAxis());
		if (curOval.contains(c.getX(), c.getY())) {
			inRange = true;
		}
		return inRange;
	}
	
	/**
	 * draw the shape with the given dimensions
	 * 
	 * @param Graphics g
	 */
	@Override
	public void drawShape(Graphics g) {
		int tempY1 = v3.getY();
		int tempY2 = v1.getY();
		int tempX1 = v3.getX();
		int tempX2 = v1.getX();
		
		//these checks are used to see where the point dragged
		//are in relation to the other points
		if(v1.getX() < v3.getX() && v1.getY() > v3.getY()) {
			v1.setY(tempY1);
			v2.setY(tempY2);
		}
		else if(v1.getX() > v3.getX() && v1.getY() < v3.getY()) {
			v1.setX(tempX1);
			v2.setX(tempX2);
		}
		else if(v1.getX() > v3.getX() && v1.getY() > v3.getY()) {
			v1.setY(tempY1);
			v3.setY(tempY2);
			v1.setX(tempX1);
			v3.setX(tempX2);
		}
		g.setColor(getColor());
		g.drawOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
		g.fillOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
		
	}
	
	/**
	 * resize the shape
	 * 
	 * @param Coordinates press
	 * @param Coordinates release
	 */
	@Override
	public void resize (Coordinates press, Coordinates release) {
		
		//first check to see if press is in range
		if (isInRange(press)) {
			//these checks are to determine to which vertex of the oval the press is closest to
			if (distanceBetween(press, v1) < distanceBetween(press, v2) && distanceBetween(press, v1) < distanceBetween(press, v4)) {
				this.setV1(release);
				v2.setY(release.getY());
				v4.setX(release.getX());
			}
			else if (distanceBetween(press, v2) < distanceBetween(press, v3) && distanceBetween(press, v2) < distanceBetween(press, v1)) {
				this.setV2(release);
				v1.setY(release.getY());
				v3.setX(release.getX());
			}
			else if (distanceBetween(press, v3) < distanceBetween(press, v2) && distanceBetween(press, v3) < distanceBetween(press, v4)) {
				this.setV3(release);
				v2.setX(release.getX());
				v4.setY(release.getY());
				
			}
			else { 
				this.setV4(release); 
				v1.setX(release.getX());
				v3.setY(release.getY());
			}
			//update axes once all vertices are set
			updateAxes();
		} // END if
	}	
}