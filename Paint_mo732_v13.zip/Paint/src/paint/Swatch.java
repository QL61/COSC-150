package paint;

import java.awt.*;

/**
 * Swatch class
 * 
 * author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class Swatch
{
	//constants 
	private static final int COLOR_SWATCH_WIDTH = 50;
	private static final int COLOR_SWATCH_HEIGHT = 30;
	
	//member variables 
	protected Color color;
	protected int x, y; // pixels from upper left to upper left corner
	protected Color paletteColor[] = 
		{Color.WHITE, Color.PINK, Color.RED, 
				Color.ORANGE, Color.YELLOW, Color.GREEN, 
				Color.BLUE, Color.MAGENTA, Color.BLACK};	// color palette is an array of predetermined colors
	protected static int currentColorPos = 0;

	// constructor, give upper left corner and color
	public Swatch( int x1, int y1, Color c1 )
	{
		x = x1; y = y1; color = c1;
	}

	// constructor without color, sets initial color to black
	public Swatch( int x1, int y1 )
	{		
		x = x1; y = y1; 
		setSwatchColor();
	}

	/**
	 * Sets the color attribute to a given color
	 * depending on which position the 
	 * currentColorPos is at.
	 */
	public void setSwatchColor()
	{
		//set color palette
		if(currentColorPos < paletteColor.length) {
			color = paletteColor[currentColorPos];
			currentColorPos++;
		}
		//sets default color from colorPalette
		else {
			color = Color.BLACK;
		}
	}

	/**
	 * fills a rectangle at xy with color
	 * @param Graphics g
	 */
	public void drawMe ( Graphics g )
	{
		g.setColor( color );
		g.fillRect( x, y, COLOR_SWATCH_WIDTH, COLOR_SWATCH_HEIGHT);
	}

	/**
	 * set color
	 * @param Color c
	 */
	public void setColor( Color c ) { color = c; }
	
	/**
	 * get color
	 * @return Color color
	 */
	public Color getColor() { return color ; }
}
