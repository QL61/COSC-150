package paint;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 * Line class
 * 
 * author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class Line extends Shape {
	
	//constants
	private static final double MARG_ERROR = 1;
	private static final int LINE_WIDTH = 3;

	//member variables
	private double length = 0;
	private Coordinates v1, v2;
	
	// CONSTRUCTOR
	public Line(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(release);;
		setLength(distanceBetween(getV1(), getV2()));
		this.color = color;
	}

	// METHODS
	/**
	 * get length of line
	 * 
	 * @return double length
	 */	
	public double getLength() { return length; }
	
	/**
	 * get area of line
	 * NOTE: line does not have an area
	 * 
	 * @return 0
	 */	
	@Override public double getArea() { return 0; }
	
	/**
	 * get perimeter of line
	 * NOTE: line does not have perimeter
	 * 
	 * @return 0
	 */	
	@Override public double getPerimeter() { return 0; }
	
	/**
	 * set v1
	 * @param Coordinates c
	 */	
	public void setV1(Coordinates c) {
		v1 = c;
	} // END setV1(Coordinates)

	/**
	 * set v2
	 * @param Coordinates c
	 */	
	public void setV2(Coordinates c) {
		v2 = c;
	} // END setV2(Coordinates)

	/**
	 * get v1
	 * @return v1
	 */	
	public Coordinates getV1() {
		return v1;
	}
	
	/**
	 * get v2
	 * @return v2
	 */		
	public Coordinates getV2() {
		return v2;
	}
	
	/**
	 * set length 
	 * @param double l
	 */	
	public void setLength(double l) {
		length = l;
	}

	/**
	 * determine if given coordinate 
	 * is on the line
	 * 
	 * @param Coordinates c
	 * @return boolean inRange
	 */
	@Override
	public boolean isInRange(Coordinates c) {
		boolean inRange = false;
		//System.out.println("In Line: isInRange() ");
		
		//check to see if the distance between the vertices and the coordinate c
		//add up to the distance between v1 and v2 with a certain error of margin for a press
		if((distanceBetween(v1, c) + distanceBetween(v2, c)) <= distanceBetween(v1, v2) + MARG_ERROR
				&& (distanceBetween(v1, c) + distanceBetween(v2, c)) >= distanceBetween(v1, v2) - MARG_ERROR) {
			//System.out.println("Line:isInRange: line contains point");
			inRange = true;
		}
		return inRange;
	}
	
	/**
	 * resize the shape
	 * 
	 * @param Coordinates press
	 * @param Coordinates release
	 */
	@Override
	public void drawShape(Graphics g) {
		g.setColor(getColor());
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(LINE_WIDTH));	//sets the width of the line to be slightly thicker
		g.drawLine(v1.getX(),v1.getY(), v2.getX(), v2.getY());	
	}

	@Override
	public void resize(Coordinates press, Coordinates release) {
		//check if press is within line range
		if (isInRange(press)) {
			//System.out.println("Line:resize: inRange passed");

			//check to see which vertex the press is closer to
			if (distanceBetween(press, v1) <= distanceBetween(press, v2) ) {
				//System.out.println("Line:resize: first if for distance");
				//System.out.println("press = " + press.getX() + " " + press.getY() + 
						//" v1 = " + v1.getX() + " " + v1.getY() + " v2 = " + v2.getX() + " " + v2.getY());

				setV1(release);
				v1.setX(release.getX());
				v1.setY(release.getY());
			}
			else {
				//System.out.println("Line:resize: else for distance");

				setV2(release);
				v2.setX(release.getX());
				v2.setY(release.getY());
			}
			//set the length after setting the new vertices
			setLength(distanceBetween(v1, v2));
		} // END if
	}	
}
