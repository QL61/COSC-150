
import java.net.*;
import java.util.Scanner;
import java.io.*;


public class ChatterClient {

	int publicPort = 55305;
	String ip = "141.161.88.4";
	public String username = "ALPHA";
	Socket sock;
	ObjectOutputStream oout;
	ObjectInputStream oin;
	BufferedReader bin;
	BufferedWriter bout;
	Listen listenToServer;
	boolean keepGoing = true;

	public static void main(String[] args) {
		try {
			boolean keepGoing = true;
	
			ChatterClient client = new ChatterClient();
			
			Scanner scan = new Scanner(System.in);
			while(keepGoing) {
				
				ChatterMessage msg = new ChatterMessage();
				
				msg.setMessage();
				
				/*
				if (msg != null) {
					System.out.println("about to write: " + msg.getMessage());
					client.bout.write(msg + '\n');
					client.bout.flush();
				}
				*/
			}
			
			client.sock.close();
			scan.close();
		}
		catch(IOException ioe) {
			System.err.println("Caught in main: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	public ChatterClient() {
		System.out.println("chat client starting ...");
		keepGoing = true; 
		
		try
		{
			System.out.println("about to try to call 'localhost' / " + publicPort);

			sock = new Socket("localhost", publicPort);

			InputStream in = sock.getInputStream();
			oin = new ObjectInputStream( in );

			OutputStream out = sock.getOutputStream();
			oout = new ObjectOutputStream( out );
			oout.writeObject(username);
			oout.flush();
			
			Thread t = new Thread(new Listen());
			t.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("caught in ChatterClient(): " + ioe + " from ");
			ioe.printStackTrace();
		}
	}
	
	class Listen implements Runnable {
		@Override
		public void run() {
			while (keepGoing) {
				ChatterMessage msg = new ChatterMessage();
				
				msg.setMessage();
				
				if (msg.getMessage() != null) { System.out.println("from server: " + msg.getMessage()); }	
			}
		}
	}
}