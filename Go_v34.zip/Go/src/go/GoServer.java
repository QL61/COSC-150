package go;


import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import java.io.*;

/**
 * ChatterServer class
 * 
 * 
 * The server is responsible for establishing Socket connections with each client, receiving
 * ChatterMessage objects sent to it by clients, and processing ChatterMessages, including by
 * sending ChatterMessages to their appropriate recipients, or updating the list of client
 * usernames and sending out the updated list in the form of an SArray
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoServer
{

	private static final int DEFAULT_PORT = 11732;
	private ServerSocket sock;
	private boolean keepGoing = true;
	private int publicPort;
	private ArrayList<ChatterClientThread> clientList = new ArrayList<ChatterClientThread>();
	private ArrayList<String> clientNameList = new ArrayList<String>();
	//store gameNumber, player1ThreadID, player2ThreadID,player1Stone,player2Stone, gameWinner in an array
	private int[] gameWait = {0,0};	
	private ArrayList<ServerBoard> gameList = new ArrayList<ServerBoard>();
	private static int gameIdcounter = 0;
	
	// Thread unique ID for easy disconnect & nickname updates
	private static int threadIdcounter = 1;

	// run to start server and make it ready to accept clients
	public static void main( String[] args ) //throws IOException
	{
		if (args.length >= 1) {
			int portArg = Integer.parseInt(args[0]);
			new GoServer(portArg);			
		}
		else new GoServer(DEFAULT_PORT);
	}

	// ChatterServer constructor
	public GoServer(int port)
	{
		System.out.println("chat server started...");
		try
		{
			publicPort = port; //set port to passed port number
			sock = new ServerSocket(publicPort); // open socket

			while (keepGoing)
			{	
				// listen for connections
				Socket client = sock.accept(); // this blocks until a client calls      
				System.out.println("ChatterServer >> accepts client connection ");
				ChatterClientThread threadToAdd = new ChatterClientThread(client);
				
				//set default name for the player
				threadToAdd.username = "player"+ (threadIdcounter-1);
				
				System.out.println("adding ChatterClientThread to ArrayList");
				clientList.add(threadToAdd);
				System.out.println("starting ChatterClientThread");
				threadToAdd.start();
				
				//Put the client into Game wait list and start a game if another player is waiting
				threadToAdd.pairPlayers(threadToAdd.threadID);

			}

			sock.close();
		}
		catch( Exception e ) { 
			System.err.println("Error: Caught in ChatServer(): " + e +" from ");
			e.printStackTrace();
		}      
		System.exit(0);
	}

	// thread that is created once for each new client
	class ChatterClientThread extends Thread {

		private Socket sock;
		private String username = "";

		private PrintWriter outStream;
		private BufferedReader inStream;
		
		
//		protected ObjectInputStream oIn;
//		protected ObjectOutputStream oOut;	
		protected boolean keepGoing = true;
		int threadID;		// Thread unique ID for easy disconnect & nickname updates

		ChatterClientThread(Socket s) {
			System.out.println("ClientThread constructor executing");
			sock = s;
			try {
				//oOut = new ObjectOutputStream(sock.getOutputStream());
				//oOut.writeObject(new ChatterMessage("public", "SERVER >>", "all", WELCOME_MESSAGE));
				//oOut.flush();
				//oIn = new ObjectInputStream(sock.getInputStream());
				
				outStream = new PrintWriter(sock.getOutputStream(), true);
				outStream.flush();
				inStream = new BufferedReader(new InputStreamReader(sock.getInputStream()));

				//assign a unique thread ID		
				threadID = ++threadIdcounter; 
				
				

			}
			catch(IOException ioe) {
				System.err.println("Caught in ClientThread constructor: " + ioe + " from ");
				ioe.printStackTrace();
			} 
		}

		// accepts and delivers messages from associated client
		@Override
		public void run() {
			System.out.println("ClientThread running...");
			try {
				while (keepGoing) {

					String msgReceived = inStream.readLine();
					System.out.println(msgReceived);

					if (msgReceived.equals("EXIT")) {
						keepGoing = false;
						break;
					}

					if (GomokuProtocol.isPlayMessage(msgReceived)) {

						System.out.println("GoServer msgReceived (line129) " + msgReceived);

						int[] detail = GomokuProtocol.getPlayDetail(msgReceived);
						// black is 1 and white is 0
						boolean isBlack = false;
						if (detail[0]==1) isBlack = true;
						System.out.println("color is " + detail[0]);
						System.out.println("row is " + detail[1]);
						System.out.println("col is " + detail[2]);

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1

								//continue if the game does not have a winner already
								if (!sb.getGameWinner()){									
									//send play detail to opponent player2								
									String msgPlay = GomokuProtocol.generatePlayMessage(sb.getPlayer1Color()==1, detail[1], detail[2]);
									sendOut(msgPlay, sb.getPlayer2ThreadID());
									System.out.println("GoServer line 146 generatePlayMessage to player 2 : " + msgPlay);

									//check if the last play finishes the game
									if (sb.isWinner(detail[1], detail[2], sb.getPlayer1Color())){
										//we have a winner!!!
										String msgWinner = GomokuProtocol.generateWinMessage();
										sendOut(msgWinner, sb.getPlayer1ThreadID());

										//send the lose message to the other player
										String msgLoser = GomokuProtocol.generateLoseMessage();
										sendOut(msgLoser, sb.getPlayer2ThreadID());
									}
								}

							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player 2

								//continue if the game does not have a winner already
								if (!sb.getGameWinner()){									

									//send play detail to opponent player1 
									String msgPlay = GomokuProtocol.generatePlayMessage(sb.getPlayer2Color()==1, detail[1], detail[2]);
									sendOut(msgPlay, sb.getPlayer1ThreadID());
									System.out.println("GoServer line 166 generatePlayMessage to player 1 : " + msgPlay);

									//check if the last play finishes the game
									if (sb.isWinner(detail[1], detail[2], sb.getPlayer2Color())){
										//we have a winner!!!
										String msgWinner = GomokuProtocol.generateWinMessage();
										sendOut(msgWinner, sb.getPlayer2ThreadID());

										//send the lose message to the other player
										String msgLoser = GomokuProtocol.generateLoseMessage();
										sendOut(msgLoser, sb.getPlayer1ThreadID());
									}
								} //end if getGameWinner
							}
						} // close for loop 
					} //close if 

					else if (GomokuProtocol.isChatMessage(msgReceived)) {
						String[] detail = GomokuProtocol.getChatDetail(msgReceived);
						System.out.println("sender is " + detail[0]);
						System.out.println("chat message is " + detail[1]);

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								//relay message to player 2
								sendOut(msgReceived, sb.getPlayer2ThreadID());
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player2
								//relay message to player 1
								sendOut(msgReceived, sb.getPlayer1ThreadID());
							}
						}
					}  				

					else if (GomokuProtocol.isChangeNameMessage(msgReceived)) {
						String[] detail = GomokuProtocol.getChangeNameDetail(msgReceived);
						System.out.println("old name is " + detail[0]);
						System.out.println("new name is " + detail[1]);
						changeName(detail[1]);

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								//relay message to player 2
								sendOut(msgReceived, sb.getPlayer2ThreadID());
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player2
								//relay message to player 1
								sendOut(msgReceived, sb.getPlayer1ThreadID());
							}
						}
					}

					else if (GomokuProtocol.isGiveupMessage(msgReceived)) {
						System.out.println("Give up message " + msgReceived );

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								//player 1 gives up
								//player 2 is a winner
								String msgWinner = GomokuProtocol.generateWinMessage();
								sendOut(msgWinner, sb.getPlayer2ThreadID());

								//send the lose message to the player
								String msgLoser = GomokuProtocol.generateLoseMessage();
								sendOut(msgLoser, sb.getPlayer1ThreadID());
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player2
								//player 2 gives up
								// player1 is a winner 
								String msgWinner = GomokuProtocol.generateWinMessage();
								sendOut(msgWinner, sb.getPlayer1ThreadID());

								//send the lose message to the player
								String msgLoser = GomokuProtocol.generateLoseMessage();
								sendOut(msgLoser, sb.getPlayer2ThreadID());
							}
						}

					}

					else if (GomokuProtocol.isResetMessage(msgReceived)) {
						System.out.println("Reset message " + msgReceived );			            
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the game and check if the player has already sent the reset request
							if (sb.getPlayer1ThreadID() == threadID && !sb.getPlayer1Reset() ){
								//player is in this game 
								//send reset message to player 2
								sendOut(msgReceived, sb.getPlayer2ThreadID());

								//Update server board with the reset request
								sb.setPlayer1Reset(true);

							}	
							else if (sb.getPlayer2ThreadID() == threadID && !sb.getPlayer2Reset()){
								//player is in this game 
								//send reset message to player 1
								sendOut(msgReceived, sb.getPlayer1ThreadID());

								//Update server board with the reset request
								sb.setPlayer2Reset(true);
							}		

							if (sb.getPlayer1Reset() && sb.getPlayer2Reset()){
								//Send users their color information again
								//this indicates that both users have been reset
								//black starts first
								if (sb.getPlayer1Color()==1) {
									//send MESSAGE_SET_BLACK to player1				
									String msgB = GomokuProtocol.generateSetBlackColorMessage();
									sendOut(msgB, sb.getPlayer1ThreadID());

									//send MESSAGE_SET_WHITE to player2				
									String msgW = GomokuProtocol.generateSetWhiteColorMessage();
									sendOut(msgW, sb.getPlayer2ThreadID());
								}
								else{
									//send MESSAGE_SET_BLACK to player2				
									String msgB = GomokuProtocol.generateSetBlackColorMessage();
									sendOut(msgB, sb.getPlayer2ThreadID());

									//send MESSAGE_SET_WHITE to player1				
									String msgW = GomokuProtocol.generateSetWhiteColorMessage();
									sendOut(msgW, sb.getPlayer1ThreadID());
								}
							}
						}	
					}			        
				}

				//exit thread
				disconnectClient(threadID);
				disconnectThread();		
			}

			catch (IOException ioe) {
				System.err.println("Error: Caught in ClientThread.run: " + ioe + " from ");
				ioe.printStackTrace();
			} 
		}

		// creates message indicating that user wants to change name
		private void changeName(String newName) {

			boolean nameFound = false;
			if (!clientNameList.isEmpty()) {

				for (int i = 0; (i < clientNameList.size()) && (!nameFound); i++) {
					String nameInList = clientNameList.get(i);
					nameInList.trim();
					//System.out.println(nameInList  + " is the name in list currently"); 

					if (nameInList.equals(username.trim())) {
						clientNameList.set(i, newName);	
						nameFound = true;
						//System.out.println(clientNameList.get(i)  + " is the new name that has been set"); 
					}
				}
				if (!nameFound) {
					clientNameList.add(newName);					
				}
			}
			else if (clientNameList.isEmpty()) {
				//System.out.println("client list is empty in server");
				clientNameList.add(newName);
			}
			this.username = newName;
			updateUserNameList();
		}

		// if a client changes its name, this is called to update the list of client names

		private void updateUserNameList() {
			for (int i = 0; i < clientList.size(); i++) {
				//System.out.println("\tsending to " + clientList.get(i).username);
				ChatterClientThread ccThread = clientList.get(i);
				String toSend = ccThread.username;
				ccThread.outStream.println(toSend);
				ccThread.outStream.flush();
			}
		}

		// exit
		// remove chatter client thread upon user exits
		private synchronized void disconnectClient(int threadID) {
			// update 
			for(int i = 0; i < clientList.size(); ++i) {
				ChatterClientThread ct = clientList.get(i);
				// check to see if client thread matches the passed thread id
				if(ct.threadID == threadID) {
					clientList.remove(i);	
					//remove the name from the client name list
					String nameToRemove = this.username;  			
					int indexToRemove = clientNameList.indexOf(nameToRemove);
					if ( indexToRemove != -1){
						clientNameList.remove(indexToRemove);
						//System.out.println("removed: " + nameToRemove);
					}		
					//Update the Name List in all active threads

					updateUserNameList(); 						
					return;
				}
			}
		}

		// try to disconnect the thread
		private void disconnectThread() {
			// try to close the connection
			try {
				if(!(outStream.equals(null))) outStream.close();
			}
			catch(Exception e) {}
			try {
				if(!(inStream.equals(null))) inStream.close();
			}
			catch(Exception e) {};
			try {
				if(sock != null) sock.close();
			}
			catch (Exception e) {}
		}


	
		public void pairPlayers(int cc1) {
			if (gameWait[0] == 0){
				//put the client in waiting queue
				gameWait[0] = cc1;

			} else if (gameWait[1] == 0){
				//player matches with the waiting player
				gameWait[1] = cc1;
				
				//randomly assign stone color to 2 players
				assignStoneColor(gameWait[0], gameWait[1]);			
				
				//reset the waiting queue			
				gameWait[0] =0;
				gameWait[1] =0;
				
			}
		}
		public void assignStoneColor(int cc1, int cc2) {
			int blackColor = 1;
			int whiteColor = 0 ;
			int randNum = ThreadLocalRandom.current().nextInt(0, 100);	//get random integer between 0 and 100 (inclusive)
			System.out.println("random number:"+ randNum);
			if (randNum < 50) {
				//cc1 is black color
				//start a new game between players
				gameIdcounter++;
				ServerBoard sb = new ServerBoard(gameIdcounter, cc1, blackColor,  cc2, whiteColor ); 
				System.out.println("colors: p1 color" + sb.getPlayer1Color()+ "p2 color: "+ sb.getPlayer2Color());
				
				gameList.add(sb);
				
				//send MESSAGE_SET_BLACK to cc1				
				String msgB = GomokuProtocol.generateSetBlackColorMessage();
				sendOut(msgB, cc1);
				System.out.println("GoServer line 433 assignStoneColor to cc1: " + msgB);
				
				
				//send MESSAGE_SET_WHITE to cc2				
				String msgW = GomokuProtocol.generateSetWhiteColorMessage();
				sendOut(msgW, cc2);
				System.out.println("GoServer line 441 assignStoneColor to cc2: " + msgW);
				
				
			} else {
				//cc2 is black color
				//start a new game between players
				gameIdcounter++;
				ServerBoard sb = new ServerBoard(gameIdcounter, cc2, blackColor,  cc1, whiteColor );  
				System.out.println("colors: p1 color" + sb.getPlayer1Color()+ "p2 color: "+ sb.getPlayer2Color());
				
				gameList.add(sb);
				
				//send MESSAGE_SET_BLACK to cc2
				String msgB = GomokuProtocol.generateSetBlackColorMessage();
				sendOut(msgB, cc2);
				System.out.println("GoServer line 454 assignStoneColor to cc2: " + msgB);

				
				//send MESSAGE_SET_WHITE to cc1
				String msgW = GomokuProtocol.generateSetWhiteColorMessage();
				System.out.println("GoServer line 459 assignStoneColor to cc1: " + msgW);
				sendOut(msgW, cc1);
				

			}
		}
		
		private synchronized void sendOut(String msg, int threadID) {
			System.out.println("sending out a message: '" + msg + "' threadID: " + threadID );

			System.out.println("sendOut" + msg);
			for (int i = 0; i < clientList.size(); i++) {
				if (clientList.get(i).threadID == threadID){
					System.out.println("\tsending to " + clientList.get(i).threadID);
					ChatterClientThread ccThread = clientList.get(i);
					ccThread.outStream.println(msg);
					ccThread.outStream.flush();
				}
			}
		}
	}
}  //END GoServer class