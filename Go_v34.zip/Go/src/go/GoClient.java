package go;

import java.net.*;
import java.util.ArrayList;
import java.io.*;

/**
 * GoClient class
 * 
 * Is used by ChatterClientGUI to process user input; communicates with server through Socket
 * connection to send and receive ChatterMessages and SArrays
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoClient {

	private PrintWriter outStream;
	private BufferedReader inStream;
	
	
	private static final String DEFAULT_PLAYER_TYPE = "ai"; // playerType is ai or human
	//private static final String DEFAULT_PLAYER_TYPE = "human"; // playerType is ai or human
	private static final String DEFAULT_HOST = "10.128.148.78";
	private static final int DEFAULT_PORT = 11732;
	private static final int COLOR_NOT_ASSIGNED = 3;
	private static final int WHITE = 0;
	private static final int BLACK = 1;

	private String username;
	private ArrayList<String> nameList = new ArrayList<String>();
	private int port;
	private String ip;
	private Socket sock;
//	private ObjectOutputStream oOut;
//	private ObjectInputStream oIn;
	private GoClientGUI cGUI;
	private boolean keepGoing = true;
	private int stoneColor = COLOR_NOT_ASSIGNED; //White is 0 and Black is 1 Not assigned color is 3
	private int myLastRow = 0;
	private int myLastColumn = 0;
	private int opponentLastRow = 0;
	private int opponentLastColumn = 0;
	private int opponentStoneColor = COLOR_NOT_ASSIGNED;
	
	
	// ChatterClient constructor
	public GoClient(String server, int portNumber, String clientName, GoClientGUI ccg) {
		this.ip = server;
		this.port = portNumber;
		this.username = clientName;
		this.cGUI = ccg;
	}
	
	// run once for each user who wants to use the chat
	public static void main(String[] args) {
		if ( args.length == 3 ){
			String serverAddress = args[0];
			int portNumber = Integer.parseInt(args[1]);
			String playerType = args[2];
			new GoClientGUI(serverAddress, portNumber, playerType);
		}
		//default player is an ai
		else new GoClientGUI(DEFAULT_HOST, DEFAULT_PORT, DEFAULT_PLAYER_TYPE);			
	}
	
	
	//get my Stone Color
	protected int getStoneColor() {
		return stoneColor;
	}
	
	//get opponent's stone Color
	protected int getOppStoneColor() {
		return opponentStoneColor;
	}
	
	
	//set stone color
	private void setStoneColor(int color) {
		stoneColor = color;
		opponentStoneColor = (1+color) % 2;
	}

	
	//get myLastRow
	protected int getMyLastRow() {
		return myLastRow;
	}
	
	//set myLastRow
	private void setMyLastRow(int r) {
		myLastRow = r;
	}
	
	//get myLastColumn
	protected int getMyLastColumn() {
		return myLastColumn;
	}
	
	//set myLastColumn
	private void setMyLastColumn(int c) {
		myLastColumn = c;
	}
	
	//get opponentLastRow
	protected int getOppLastRow() {
		return opponentLastRow;
	}
	//set opponentLastRow
	private void setOppLastRow(int r) {
		opponentLastRow = r;
	}
	//get opponentLastColumn
	protected int getOppLastColumn() {
		return opponentLastColumn;
	}
	//set opponentLastColumn
	private void setOppLastColumn(int c) {
		opponentLastColumn = c;
	}
	
	


	// connects socket and creates input and output streams
	public boolean start() {
		System.out.println("chat client started...");
		boolean startValue = true;
		keepGoing = true; 

		try
		{
			//System.out.println("about to try to call 'localhost' / " + port);
			sock = new Socket(ip, port);
			//oOut = new ObjectOutputStream(sock.getOutputStream());
			outStream = new PrintWriter(sock.getOutputStream(), true);
			
			
			//System.out.println("setting username: " + cGUI.getUsername());
			setUsername(cGUI.getUsername());
			//oOut.flush();
			outStream.flush();
			
			
			
			//oIn = new ObjectInputStream(sock.getInputStream());
			inStream = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			
			
			//System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();
		}
		catch ( IOException ioe ) {
			System.err.println("Client connection was closed.");
		}

		return startValue;
	}

	// called when user attempts to change username
	protected void setUsername(String newName) {
		//Use the new protocol for the game nickname changes
		if ( !(username.equals(newName)) ) {
			String msg = GomokuProtocol.generateChangeNameMessage(username, newName);
			cGUI.printChatHistory(msg);
				outStream.println(msg);
				outStream.flush();
		}
	}


	// function to send message through output stream
	public void sendMessage(String msg) {
		cGUI.printChatHistory("Sending : " + msg);			
		if (GomokuProtocol.isPlayMessage(msg)) {
			int[] detail = GomokuProtocol.getPlayDetail(msg);
			// black is 1 and white is 0
			System.out.println("sending color " + detail[0]);
			System.out.println("sending row " + detail[1]);
			System.out.println("sending column " + detail[2]);
			setMyLastRow(detail[1]);
			setMyLastColumn(detail[2]);
		}			
			outStream.println(msg);
			outStream.flush();
	}


	//get the list of names
	protected ArrayList<String> getNameList() {
		return nameList;
	}

	//get the current client username
	protected String getClientUsername(){
		return this.username;
	}

	// thread that runs to listen for new messages and add them to chat history list if
	// they are public messages or private messages meant for this client
	class Listen implements Runnable {
		@Override
		public void run() {
			//System.out.println("Listen running...");

			try {
				while (keepGoing) {

					username = cGUI.getUsername();
					String msg = inStream.readLine();
					
					//Print the message on Chat history
					cGUI.printChatHistory("received : " + msg);
					if (GomokuProtocol.isPlayMessage(msg)) {
						int[] detail = GomokuProtocol.getPlayDetail(msg);
						// black is 1 and white is 0
						System.out.println("color is " + detail[0]);
						System.out.println("row is " + detail[1]);
						System.out.println("col is " + detail[2]);

						//check winner for opponent here, if not success, turn on myTurn
						//also server checks for opponent team's client, and does not post the stone here
						cGUI.setMyTurn(true); //enable client to run
						PlayerPosition pp = new PlayerPosition();
						pp.setColumnRow(detail[2]+1, detail[1]+1);
						//CHECK INCOMING HERE
						cGUI.pBoard.board.setPiece(pp, (int)detail[0]);	
						cGUI.pBoard.refreshBoard();

						//use opponent's last move information when calculating next move
						setOppLastRow(detail[1]);
						setOppLastColumn(detail[2]);

						//call the following line only for AI mode
						if (cGUI.getPlayerMode()==1){
							cGUI.pBoard.makeMove(null);
						}

					}			

					else if (GomokuProtocol.isChangeNameMessage(msg)) {
						String[] detail = GomokuProtocol.getChangeNameDetail(msg);
						cGUI.printChatHistory("old name is " + detail[0]);
						cGUI.printChatHistory("new name is " + detail[1]);

					}						

					else if (GomokuProtocol.isChatMessage(msg)) {
						cGUI.printChatHistory(msg);
					}

					else if (GomokuProtocol.isGiveupMessage(msg)) {
						cGUI.setWinCounter(false);  //pass true if win the game 
						cGUI.printChatHistory("You lose!!!!!");
						cGUI.pBoard.board.reset();
					}

					else if (GomokuProtocol.isLoseMessage(msg)) {
						cGUI.setMyTurn(false);
						cGUI.setWinCounter(false);  //pass false if lost the game 
						cGUI.printChatHistory("You lose");
					}

					else if (GomokuProtocol.isWinMessage(msg)) {
						cGUI.setMyTurn(false);
						cGUI.setWinCounter(true);  //pass true if win the game 
						cGUI.printChatHistory("You win!!!!!");
					}

					else if (GomokuProtocol.isResetMessage(msg)) {
						//reset the board
						cGUI.pBoard.board.reset();

					}						
					//send black stone color
					else if (GomokuProtocol.isSetBlackColorMessage(msg)) {
						System.out.println(msg);
						setStoneColor(BLACK);
						cGUI.setPlayer(true);  //set black stone
						cGUI.setPlayer(BLACK);
						cGUI.setMyTurn(true);
						//call the following line only for AI mode
						if (cGUI.getPlayerMode()==1){
							cGUI.pBoard.makeMove(null);
						}

					}
					//send white stone color
					else if (GomokuProtocol.isSetWhiteColorMessage(msg)) {
						System.out.println(msg);
						setStoneColor(WHITE);
						cGUI.setPlayer(false); //set white stone
						cGUI.setPlayer(WHITE);
						cGUI.setMyTurn(false);
					}	
				}
			} // END try 
			catch(SocketException se) {
				System.err.println("caught: " + se + " from ");
				se.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("\n\n\nUser connection was closed");
			} // END catch
		} // END public void run()
	} // END class Listen
} // END public class ChatterClient