package go;


import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;



import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

/**
 * ChatterClientGUI class
 * 
 * Creates GUI for Chatter based on information it receives from ChatterClient, and also
 * acts upon ChatterClient based on user input
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoClientGUI extends JFrame implements ActionListener, KeyListener, MouseListener {

	private static final int HELP_FRAME_WIDTH = 300;
	private static final int HELP_FRAME_HEIGHT = 350;
	
	private static final String HELP_MSG = "Welcome to our cute user manual";
	
	//Go GUI stuff
    private int[] dim = {15,15};                        //Default board width=15 and depth=15
    int boardSize=450;
   
    //private GameBoardUI pBoard;                          //Game drawer
    ////////////////////////////////////////////////////////////////////////////////////////start gameboard ui stuff
	private static final int PLAYER_A = 0;         //piece PLAYER_A
    private static final int PLAYER_B = 1;         //piece PLAYER_B
    private static final int FREE = 3;          //a free place on the board
    private static final String COMPSTRATEGY = "Computer ";
    private static final String HUMAN = "Human";
	private static final String DEFAULT_HOST = "localhost";

	private int[] strategy = {1,1};                     //strategy[1] for PLAYER_A and strategy[1] for PLAYER_B
    //playerType = {0,1}; Human vs Computer
    // playerType = {0,0}; Human vs Human   on the same screen, NOT ON MULTIPLE CLIENT SCREENS -dont use it
    // playerType = {1,1}; Computer vs Computer
    
    private int[] playerType = {0,0};                   //kind of player 0=Human; 1=computer
    private String[] moveGenerator = {"","",""};        //variable to store the version of the move generator
    private String[] host = {DEFAULT_HOST,DEFAULT_HOST};  	//move generator for player One=PLAYER_A and Two=PLAYER_B
    private int[] port = {0,0,3000};                    //default port and port for move generator for player One=PLAYER_A and Two=PLAYER_B
    private int falseMove = 0;                          //counter for wrong moves, if falseMove>5 than brakes the game
    
    private int[] winCounter = {0,0};                   //to store the game score
    private int player = PLAYER_A;                        //player on the turn    
    
	private int cellSize=30;      //size of the representation of a game field
    private int cellSizeSmall= 4; //start point to draw a piece
    private int cellSizeBig= 21;  //size of a piece
    private int moveThread=0;   //if a move move is being calculate 1 otherwise 0
    private boolean reset = false;  //if true the board will be reseted for a new game
    private GameBoardUI pBoard;       //the GameBoard board for this game
    
    
    //////////////////////////////////////////////////////////////////////////////////////////end of gameboard ui stuff
    
    
//    private JButton[][] goBoardSquares = new JButton[15][15];
//    private JPanel goBoard;
	
	private static final long serialVersionUID = 1L;
	private static final String WELCOME_TO_CHAT = "Welcome to the Chatroom\n\n";
	private static final String TYPE_CHAT_MSG = "Type Chat Message Here \n";
	private static final String NICK_NAME_COMMAND = "Type /nick \'name\' to change nickname";
	private static final String SLASH_NICK = "/nick";
	private static final String INVALID_UN = "Invalid Username (cannot contain spaces). Try again.";
	private static final String USER_LOGON_MSG = " logged on! Say hi!\n\n";
	private static final String LOGOUT_MSG = " Logged off :(\n\n";
//	private JLabel usernameLabel;							// label for username
	private JTextField username;							// hold current username
	private JTextField tfServer, tfPort;					// write server address and port number
	private JButton loginBtn, sendBtn, exitBtn, modeBtn, resetBtn, giveUpBtn, userManBtn;				// buttons
	private JComboBox usernameList; 						// list of clients
	private JTextArea taMsgHistory;							// message history text area
	private JTextArea taMessenger;							// text box
	private int defaultPort;								// the default port number
	private String defaultIP;								// the default ip
	private GoClient client;
	
	// Constructor connection receiving a socket number
	GoClientGUI(String host, int port) {		
		//System.out.println("inside clientGUI constructor");
		
		super("Go Client");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		defaultPort = port;
		defaultIP = host;
		
		// The NorthPanel
		JPanel northPanel = new JPanel(new GridLayout(3,2)); // the server name and port number
		JPanel serverAddress = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for server address
		JPanel portNumber = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for port number
		tfServer = new JTextField(defaultIP);
		tfPort = new JTextField("" + defaultPort);
		tfPort.setHorizontalAlignment(SwingConstants.RIGHT);
		serverAddress.add(new JLabel("Server Address:  "));
		serverAddress.add(tfServer);
		portNumber.add(new JLabel("Port Number:  "));
		portNumber.add(tfPort);
		// adds Server port field to GUI
		northPanel.add(serverAddress, BorderLayout.NORTH);
		northPanel.add(portNumber, BorderLayout.NORTH);

		//jpanel to contain buttons for game
		JPanel gameBtns1 = new JPanel(new GridLayout(1, 2));
		JPanel gameBtns2 = new JPanel(new GridLayout(1, 2));
		
		//mode and user manual buttons
		modeBtn = new JButton("Mode");
		modeBtn.addActionListener(this);
		modeBtn.setEnabled(true);
		userManBtn = new JButton("User Manual");
		userManBtn.addActionListener(this);
		userManBtn.setEnabled(true);
		gameBtns1.add(modeBtn);
		gameBtns1.add(userManBtn);
		northPanel.add(gameBtns1);
		
		//username TextField
		username = new JTextField("Enter your username here");
		username.setBackground(Color.WHITE);
		northPanel.add(username, BorderLayout.SOUTH);

		//reset and give up buttons
		resetBtn = new JButton("Reset");
		resetBtn.addActionListener(this);
		resetBtn.setEnabled(true);
		giveUpBtn = new JButton("Give Up");
		giveUpBtn.addActionListener(this);
		giveUpBtn.setEnabled(true);
		gameBtns2.add(resetBtn);
		gameBtns2.add(giveUpBtn);
		northPanel.add(gameBtns2);
		
		// username list creation
		PopupMenuListener pmListener = new PopupMenuListener() {
			boolean initialized = false;
			
			@Override public void popupMenuCanceled(PopupMenuEvent e) {}
			@Override public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				String[] initList = {"G r o u p"};
				if (!initialized) {
					usernameList = (JComboBox) e.getSource();
					ComboBoxModel model = new DefaultComboBoxModel(initList);
					usernameList.setModel(model);
					initialized = true;
				}
				//System.out.println("should remove " + usernameList.getItemCount() + " -1 items");

				for (int i = usernameList.getItemCount()-1; i > 0; i--) {
					//System.out.println("will remove " + usernameList.getItemAt(i));

					usernameList.removeItemAt(i);
				}
				for (int i = 0; i < client.getNameList().size(); i++) {
					//System.out.println("adding " + client.getNameList().get(i));
					usernameList.addItem(client.getNameList().get(i));
				}
			}
		};
		usernameList = new JComboBox();
		usernameList.addItem("G r o u p");
		usernameList.setSelectedItem("G r o u p");
		usernameList.addPopupMenuListener(pmListener);
		usernameList.addActionListener(this);
		usernameList.setEnabled(false);
		northPanel.add(usernameList, BorderLayout.SOUTH);
		//add to frame
		add(northPanel, BorderLayout.NORTH);

		// CenterPanel
		JPanel centerPanel = new JPanel(new GridLayout(1,2));
		
		
		/////////////////////////////go board stuff

		pBoard = new GameBoardUI(15,15);  //Create a new game board

		// add a mouse listener to detect user's mouse clicks on the board
//        addMouseListener(new MouseAdapter(){@Override
//        public void mouseClicked(MouseEvent e){thisMouseClicked(e);}});

		centerPanel.add(pBoard);
		pBoard.addMouseListener(this);
		add(centerPanel, BorderLayout.CENTER);

		System.out.println("added center panel to board");
		
		/////////////////////////////////////////////////////////////////end of board creation
		taMsgHistory = new JTextArea(WELCOME_TO_CHAT, 80, 80);
		centerPanel.add(new JScrollPane(taMsgHistory));
		taMsgHistory.setEditable(false);

		// MessengerPanel
		taMessenger = new JTextArea(TYPE_CHAT_MSG + NICK_NAME_COMMAND);
		taMessenger.setBackground(Color.WHITE);
		taMessenger.setEditable(false);
		taMessenger.addKeyListener(this);
		centerPanel.add(taMessenger);
		//add(centerPanel, BorderLayout.LINE_END);
		
		// button creation
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(this);
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		exitBtn.setEnabled(false);		// must login before being able to exit
		sendBtn = new JButton("Send");
		sendBtn.addActionListener(this);
		sendBtn.setEnabled(false);

		JPanel southPanel = new JPanel();
		southPanel.add(loginBtn);
		southPanel.add(sendBtn);
		southPanel.add(exitBtn);
		add(southPanel, BorderLayout.SOUTH);
		
		//set the word wrap of message history and Messenger
		taMessenger.setWrapStyleWord(true);
		taMessenger.setLineWrap(true);
		taMsgHistory.setWrapStyleWord(true);
		taMsgHistory.setLineWrap(true);


		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				exitBtn.doClick();
			}
		});
		
		
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//setSize(750, 500);
		pack(); //automatically change the size of the frames according to the size of components in it. 
		setVisible(true);
		taMessenger.requestFocus();
	}

	// for enter key being pressed
	//mainly used for when enter key is pressed
	public void keyPressed(KeyEvent e) {
		if(sendBtn.isEnabled()) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER){
				sendBtn.doClick();
			}
		}
	}
	
	//for the key being released
	//mainly used for when enter key is released
	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER && 
				!(taMessenger.getText().trim().equals(INVALID_UN.trim()))) {			
			taMessenger.setText("");
		}
	}
	
	/**
	 * Button or JTextField clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// check for which button is pressed
		if(e.getSource() == exitBtn) {

			//Send exit command to the server
			Map<String, String> messageInfo = new HashMap<String, String>();
			messageInfo.put("type", ChatterMessage.EXIT);
			messageInfo.put("sender", client.getClientUsername());
			messageInfo.put("recipient", client.getClientUsername());
			messageInfo.put("message",client.getClientUsername() + LOGOUT_MSG);
			client.sendMessage(new ChatterMessage(messageInfo));
			
			//disable all buttons
			sendBtn.setEnabled(false);
			exitBtn.setEnabled(false);
			loginBtn.setEnabled(false);
			taMessenger.setEditable(false);
			usernameList.setEnabled(false);
			taMsgHistory.append("Logged off. Goodbye!\n\n");  //display bye to the user
					
		}
		else if (e.getSource() == sendBtn) {
			//System.out.println("click was sendBtn:: in sendBtn:: ");
			
			String msg = taMessenger.getText();
			String messageType = "";
			String nickChangeStr = "";
			
			if (msg.contains(SLASH_NICK)) {
				nickChangeStr = msg.substring(msg.indexOf(SLASH_NICK) + SLASH_NICK.length());
			}
			if ( (msg.indexOf(SLASH_NICK) == 0) && (nickChangeStr.indexOf(" ") == 0) ) {

				//System.out.println("----" + nickChangeStr + "-----");
				nickChangeStr = nickChangeStr.trim();
				if (checkValidUsernameInput(nickChangeStr)) {
					client.setUsername(nickChangeStr);
					username.setText(nickChangeStr);
					taMessenger.setText("");
				}
				else {
					//System.out.println("invalid username put in taMessenger");
					taMessenger.setText(INVALID_UN);
				}
			}			
			else { 
				if (((String) usernameList.getSelectedItem()).equalsIgnoreCase("g r o u p")) {
					messageType = ChatterMessage.PUBLIC;
				}
				else {
					messageType = ChatterMessage.PRIVATE;
				}

				Map<String, String> messageInfo = new HashMap<String, String>();
				messageInfo.put("type", messageType);
				messageInfo.put("sender", client.getClientUsername());
				messageInfo.put("recipient", (String) usernameList.getSelectedItem());
				messageInfo.put("message", msg + "\n\n");

				if ( messageType.equals(ChatterMessage.PRIVATE) 
						&& !( client.getClientUsername().equals((String) usernameList.getSelectedItem()) ) ) {
					taMsgHistory.append(client.getClientUsername() + " to " 
							+ (String) usernameList.getSelectedItem() + ": " + msg + "\n\n");
				}

				client.sendMessage(new ChatterMessage(messageInfo));
				taMessenger.setText("");
			}
		}
		else if(e.getSource() == loginBtn) {
			System.out.println("actionPerformed: in loginBtn");

			// connection requested
			if (checkValidUsernameInput(getUsername())) {
				String username = getUsername().trim();
				String server = tfServer.getText().trim();
				String portNumber = tfPort.getText().trim();

				// create new Client
				client = new GoClient(server, Integer.parseInt(portNumber), username, this);
				// test to start Client
				if(!client.start()) 
					return;

				if (client.getNameList() != null) {
					for (int i = 0; i < client.getNameList().size(); i++) {
						usernameList.addItem(client.getNameList().get(i));
					}
				}
//				usernameLabel.setText(NICK_NAME_COMMAND);
				usernameList.setEnabled(true);
				//enable username List
				this.username.setEditable(false);
				// disable login button
				loginBtn.setEnabled(false);
				// enable the 2 buttons
				exitBtn.setEnabled(true);
				sendBtn.setEnabled(true);
				// disable the Server and Port JTextField
				tfServer.setEditable(false);
				tfPort.setEditable(false);
				taMessenger.setEditable(true);	
				taMessenger.setFocusable(true);
				// Action listener for when the user enter a message
				taMessenger.addFocusListener(new FocusListener() {
					public void focusGained(FocusEvent e) {}
					public void focusLost(FocusEvent e) {}
				});

				
				client.sendMessage(new ChatterMessage(ChatterMessage.PUBLIC, username, 
						(String) usernameList.getSelectedItem(), username + USER_LOGON_MSG));

				//printChatHistory();
			}
			else {
//				usernameLabel.setText(INVALID_UN);
				this.username.setText(INVALID_UN);
			}
						
		}
		else if ( e.getSource() == userManBtn ) {
			//System.out.println(HELP + " selected");
			JFrame helpFrame = new JFrame("User Manual Screen");

			JTextArea helpText = new JTextArea(HELP_MSG); 
			
			helpText.setWrapStyleWord(true);
			helpFrame.add(helpText);
			helpFrame.setSize(HELP_FRAME_HEIGHT,HELP_FRAME_WIDTH);
			helpFrame.setVisible(true);
		}
		if(e.getSource() == resetBtn) {
			pBoard.reset();  //reset the board and start a new game
		}
	}

	// outputs chat messages for the given user/client
	public void printChatHistory(ChatterMessage cm) {		
		String msgSender = cm.getSender();
		String msgReceiver = cm.getRecipient();

		//public message from server
		if (cm.getMessageType().equals(ChatterMessage.PUBLIC) && (cm.getSender().equals("SERVER >>") 
				|| cm.getMessage().equals(msgSender + USER_LOGON_MSG)) ) {
			taMsgHistory.append("SERVER >> " + cm.getMessage());
		}
		//public message from client to all
		else if (cm.getMessageType().equals(ChatterMessage.PUBLIC)) {
			//System.out.println(msgSender + " is the sender of this public message");
			taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
		}
		//private method
		else if ( cm.getMessageType().equals(ChatterMessage.PRIVATE) ) {
			if ( msgReceiver.equals(client.getClientUsername()) ) {
				taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
			}
		}
	}

	//check to see if the user name entered as a param is valid
	private boolean checkValidUsernameInput(String text) {
		boolean validUN = false;
		//check to see if client exists
		if (client != null) {
			for (int i = 0; i < client.getNameList().size(); i++) {
				String nameCompare = client.getNameList().get(i);
				if (text.equals(nameCompare)) {
					validUN = true;
				}
			}
		}
		//passed user name cannot contain spaces or be empty
		if (!(validUN || text.contains(" ") || text.equals(""))) {
			validUN = true;
		}
		return validUN;
	}
	
	//get the username from the client username text field
	protected String getUsername() {
		return username.getText();
	}

	//key typed... no action required for function
	@Override
	public void keyTyped(KeyEvent e) {}
	
	
	//GameBoardUI moved
	
	
	///////////////////////////////////////////////////////////////////////// beg of methods and other stuff from old GameBoardUI

	public class GameBoardUI extends JPanel {
		GameBoard board;
		boolean firstPaint = false;
		int curRow = -1;
		int curCol = -1;
		Color curColor = Color.GREEN;
		
		public GameBoardUI(int size1, int size2){
			System.out.println("inside gameboardUI constructor");

			board = new GameBoard(size1,size2);  //Create a new game board

//			// add a mouse listener to detect user's mouse clicks on the board
//	        addMouseListener(new MouseAdapter(){@Override
//	        public void mouseClicked(MouseEvent e){thisMouseClicked(e);}});

		}
		
		/**
		 * Draws the game board
		 */
		public void paintComponent(Graphics g){
			System.out.println("inside gameboardUI::paintComponent()");

			super.paintComponent(g);													//////////////////////////something wrong with this line
			Graphics2D g2 = (Graphics2D) g;
			g2.addRenderingHints(new RenderingHints(
					RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON)
					);

			this.setSize(boardSize,boardSize);  //this refers to the board , its size is 450x450, all cellSizes are populated with integer numbers of 32 and 3
			this.setPreferredSize(new Dimension(boardSize,boardSize));  //board preferred size is set to 450x450
//not really necessary
			if (!firstPaint) refreshBoard();

			PlayerPosition place = new PlayerPosition(0,0);   //initialize place to (0,0) cellSize
			int x = 0, y = 0;
			while (y < boardSize){    // y less than 30 x 15 = 450  board heigth
				while ( x < boardSize ){    // x is less than 30 x 15 = 450  board width
					place.setColumnRow(1+x/cellSize,1+y/cellSize);   // dividing x by cellSize gives us how many cellSizes x moved like 1,2,3.. . Same for y.
					if (board.getPiece(place)>=4){    // board.getPiece is larger than 4 for frame cellSizes that have 35, and 32 as values
						if (board.getPiece(place)>=8) {   //either a frame or a winning row/column has larger than 8
							//the win fields have special color
							g2.setColor(new Color( 0,255,127)); // Spring Green 0,255,127
							g2.fill3DRect(x, y, cellSize, cellSize,false);
						} else {
							//special colors to show winning row
							g2.setColor(new Color((float)0.2,(float)0.75,(float)0.45));
							g2.fill3DRect(x, y, cellSize, cellSize,true);
						}
					} else {
						if ((board.getPiece(place)&3)!=FREE) {
							//PUT GRID LINES 
							g2.setColor(Color.BLACK);
							g2.setStroke(new BasicStroke(3));  //Set line thickness
							g2.drawLine(x, y+(cellSize/2), x+cellSize, y+(cellSize/2));  //draw a horizontal line in the middle of cell
							g2.drawLine(x+(cellSize/2), y, x+(cellSize/2), y+cellSize);  //draw a vertical line in the middle of cell

							//for cellSizes which contains pieces
							g2.setColor(new Color(65,105,225)); //Royal Blue 65,105,225 
							//g2.fill3DRect(x, y, cellSize, cellSize,true);  //remove the frame from selected cells



						} else {
							//for cellSizes which don't contains pieces
							//g2.setColor(Color.WHITE);  //board color
							g2.setColor(new Color((float)1.0,(float)1.0,(float)1.0,(float)0.0));  // white board color, 100% transparent
							g2.fill3DRect(x, y, cellSize, cellSize,true);
							//PUT GRID LINES 
							g2.setColor(Color.BLACK);
							g2.setStroke(new BasicStroke(3));  //Set line thickness
							g2.drawLine(x, y+(cellSize/2), x+cellSize, y+(cellSize/2));  //draw a horizontal line in the middle of cell
							g2.drawLine(x+(cellSize/2), y, x+(cellSize/2), y+cellSize);  //draw a vertical line in the middle of cell
						}
					}
					if ((board.getPiece(place)&3)==PLAYER_B) {
						//set the color to black
						g2.setColor(Color.white);
						g2.fillOval(x+cellSizeSmall, y+cellSizeSmall , cellSizeBig, cellSizeBig);
					}
					if ((board.getPiece(place)&3)==PLAYER_A) {
						//set the color to PLAYER_A
						g2.setColor(Color.black);
						g2.fillOval(x+cellSizeSmall, y+cellSizeSmall , cellSizeBig, cellSizeBig);

					}
					x += cellSize;
				}
				x = 0;
				y += cellSize;
			}
			curColor = g2.getColor();
		}	

		/**
		 * redraw the board. But wait a time to be sure that the time between
		 * two moves is at least one second.
		 */
		public void refreshBoard(){
			refreshStatus();
			refresh();
			try {
				//Always wait 1s to be sure the moves are not too 
				//quickly redraw
				Thread.sleep(500);
			} catch  ( final Exception e ) {}
		}

		/**
		 * refresh the status lines
		 */
		private void refreshStatus() {
		}



		private void refresh() {
			firstPaint = true;
			repaint();
		}

		/**
		 * Resets the GameBoard board for a new game.
		 */
		public void reset() {
			System.out.println("inside gameboardUI::reset()");
			reset = true;
			player=0;
			falseMove=0;
			board = new GameBoard(dim[0], dim[1]);
			do refreshBoard(); while (moveThread > 0);
			reset = false;
		}

		/**
		 * gets the game status
		 * @return     0 = PLAYER_A was the last player
		 * @return     1 = PLAYER_B was the last player
		 * @return     3 = the board is yet empty
		 * @return     4 = game over and PLAYER_A won
		 * @return     5 = game over and PLAYER_B won
		 * @return     8 = game over without winner
		 * @return     9 = board need to be accepted
		 */
		public int getStatus() {
			return board.getStatus();  //returns 0 at the beginning of the game
		}

		/**
		 * returns the next move. 
		 * @param player   PLAYER_A or PLAYER_B player
		 * @param e         position of mouse click (next move for human player)
		 */
		private PlayerPosition play(final int player,final MouseEvent e) {
			PlayerPosition ret = new PlayerPosition();
			if (playerType[player] == 0  && e!=null ){     //Human player
				ret = new PlayerPosition(1+e.getX()/cellSize,1+e.getY()/cellSize);
				moveGenerator[2] = HUMAN;
			} else{   //Computer Player        	 
				AI aiPlayer = new AI(new GomokuStrategy(board));  
				//Evaluate the best move based on free spaces and potential game states
				ret = aiPlayer.getNextMove();  
				moveGenerator[2] = COMPSTRATEGY;
			}
			// Output on console for log the game
			curCol = ret.getColumn();
			curRow = ret.getRow();
			System.out.print("GameBoardUI PlayerPosition play ret value "+ret.toString() + " row: " + ret.getRow() + " column: " + ret.getColumn() + "\n");
			return ret;
		}

		/**
		 * starts a new game 
		 */
		public void startGame() {
			System.out.println("inside gameboardUI::startGame()");
			makeMove(null);
		}

		
		public void makeMove(MouseEvent e) {
			this.run(e);
		}
		
		
		/**
		 *starts the calculation
		 */
		public void run(MouseEvent e) {
			System.out.println("inside gameboardUI::run()");
			moveThread++;

			if (moveThread==1 ) {
				//if moveThread is bigger than 1 than there are another 
				//calculation on going and this should be stopped
				do {
					if ( board.getStatus() <= FREE && falseMove<5 ){
						//resetSuggestions();
						if ( board.setPiece(play(player,e),(int) player)) {
							moveGenerator[player] = moveGenerator[2];
							player = ( player + 1 ) % 2;
							falseMove = 0;
						} else {
							// move is not allowed
							falseMove++;

						}
					}
					refreshBoard();
				} while ( board.getStatus() <= FREE && falseMove<5 && (playerType[player] != 0 && !reset) );
			}
			moveThread--;
		}
	}

	///////////////////////////////////////////////////////////////////////// end of methods and other stuff from old GameBoardUI
	
	@Override
	public void mouseClicked(MouseEvent e) {
		/////////////////////////////////////////////////////////////////makeMove
		System.out.println("inside mouseclick of goclientGui");
		//pBoard.play(PLAYER_A, e);
		pBoard.makeMove(e);
		client.sendMessage(new ChatterMessage(ChatterMessage.PRIVATE, client.getClientUsername(),
				(String) usernameList.getSelectedItem(), "\\"+player + "/play\\"+player+pBoard.curColor
				+"\\"+player+pBoard.curRow+"\\"+player+pBoard.curCol));
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {}

	@Override
	public void mouseExited(MouseEvent arg0) {}

	@Override
	public void mousePressed(MouseEvent arg0) {}

	@Override
	public void mouseReleased(MouseEvent arg0) {}
	
} // END ChatterClientGui class
