package Paint.src.paint;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

//calculates length of line

public class Line extends Shape {
	//constants 
	private static final double MARG_ERROR = 1;
	
	private double length = 0;
	private Coordinates v1, v2;
	
	// CONSTRUCTOR
	public Line(Coordinates press, Coordinates release, Color color) {
		System.out.println("press = " + press.getX() + " " + press.getY() + " release = " + release.getX() + " " + release.getY() );

		setV1(press);
		setV2(release);;
		setLength(distanceBetween(getV1(), getV2()));
		this.color = color;
	}

	// METHODS
	public double getLength() { return length; }
	
	@Override public double getArea() { return 0; }
	
	@Override public double getPerimeter() { return 0; }
	
	public void setV1(Coordinates c) {
		v1 = c;
	} // END setV1(Coordinates)
	
	public void setV2(Coordinates c) {
		v2 = c;
	} // END setV2(Coordinates)

	public Coordinates getV1() {
		return v1;
	}
	
	public Coordinates getV2() {
		return v2;
	}
	
	public void setLength(double l) {
		length = l;
	}

	@Override
	public boolean isInRange(Coordinates c) {
		boolean inRange = false;
		System.out.println("In Line: isInRange() ");
		Line2D line = new Line2D.Double(v1.getX(), v1.getY(), v2.getX(), v2.getY());


//		if (line.contains(c.getX(), c.getY())) {
		if((distanceBetween(v1, c) + distanceBetween(v2, c)) <= distanceBetween(v1, v2) + MARG_ERROR
				&& (distanceBetween(v1, c) + distanceBetween(v2, c)) >= distanceBetween(v1, v2) - MARG_ERROR) {
			System.out.println("Line:isInRange: line contains point");
			inRange = true;
		}
		return inRange;
	}

	@Override
	public void drawShape(Graphics g) {
		g.setColor(getColor());
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(2));
		g.drawLine(v1.getX(),v1.getY(), v2.getX(), v2.getY());	
	}

	@Override
	public void resize(Coordinates press, Coordinates release) {
		if (isInRange(press)) {
			System.out.println("Line:resize: inRange passed");

			if (distanceBetween(press, v1) <= distanceBetween(press, v2) ) {
				System.out.println("Line:resize: first if for distance");
				System.out.println("press = " + press.getX() + " " + press.getY() + " v1 = " + v1.getX() + " " + v1.getY() + " v2 = " + v2.getX() + " " + v2.getY());

				
				setV1(release);
				v1.setX(release.getX());
				v1.setY(release.getY());
			}
			else {
				System.out.println("Line:resize: else for distance");

				setV2(release);
				v2.setX(release.getX());
				v2.setY(release.getY());
			}
			setLength(distanceBetween(v1, v2));
		} // END if
	}	
}
