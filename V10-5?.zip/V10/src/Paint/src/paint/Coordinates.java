package Paint.src.paint;


//stores a single 2-tuple
public class Coordinates {
	
	// FIELDS
	public int x, y;
	
	// CONSTRUCTOR
	public Coordinates(int xval, int yval) {
		setX(xval);
		setY(yval);
	}
	
	public void setX(int xVal) {
		this.x = xVal;
	}
	
	public void setY(int yVal) {
		this.y = yVal;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}
