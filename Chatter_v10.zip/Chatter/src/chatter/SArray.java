package chatter;

import java.io.Serializable;
import java.util.ArrayList;

public class SArray implements Serializable {
	private static final long serialVersionUID = 1L;
	private ArrayList<String> al = new ArrayList<String>();
	
	public SArray() { al = new ArrayList<String>(); }
	public SArray(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
	public ArrayList<String> getAL() { return al; }
	public void setAL(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
}
