package chatter;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;


public class ChatterClient {
	
	public String username;
	public ArrayList<String> nameList = new ArrayList<String>();
	
	private int port;
	private String ip;
	private Socket sock;
	private ObjectOutputStream oOut;
	private ObjectInputStream oIn;
	
	private ArrayList<ChatterMessage> allHistory = new ArrayList<ChatterMessage>();
	private ClientGUI cGUI;
	
	private boolean keepGoing = true;

	public static void main(String[] args) {
		String serverAddress = "localhost";
		int portNumber = 55305;
		new ClientGUI(serverAddress, portNumber);
	}

	public ChatterClient(String server, int portNumber, String name, ClientGUI cg) {
		this.ip = server;
		this.port = portNumber;
		this.username = name;
		this.cGUI = cg;
	}
	
	public boolean start() {
		System.out.println("chat client starting ...");
		keepGoing = true; 

		try
		{
			System.out.println("about to try to call 'localhost' / " + port);

			sock = new Socket("localhost", port);

			oOut = new ObjectOutputStream(sock.getOutputStream());
			System.out.println("setting username: " + cGUI.getUsername());
			setUsername(cGUI.getUsername());
			oOut.flush();
			oIn = new ObjectInputStream(sock.getInputStream());

			System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("caught in ChatterClient(): " + ioe + " from ");
			ioe.printStackTrace();
		}
		
		return true;
	}

	public void setUsername(String newName) {
		Map<String, String> nameInfo = new HashMap<String, String>();
		nameInfo.put("type", "name change");
		nameInfo.put("sender", username);
		nameInfo.put("recipient", username);
		nameInfo.put("message", newName);
		ChatterMessage nameCM = new ChatterMessage(nameInfo);
		
		//update the chat history
		for (int i = 0; allHistory != null && i < allHistory.size(); i++) {
			if (allHistory.get(i).getSender().equals(this.username)){
				ChatterMessage updatedCM = new ChatterMessage(allHistory.get(i).getMessageType(), newName, 
						allHistory.get(i).getRecipient(), allHistory.get(i).getMessage());
				allHistory.set(i, updatedCM);
			}
			else {
				ChatterMessage updatedCM = new ChatterMessage(allHistory.get(i).getMessageType(), allHistory.get(i).getSender(), 
						newName, allHistory.get(i).getMessage());
				allHistory.set(i, updatedCM);				
			}
		}
		
		try {
			oOut.writeObject(nameCM);
			oOut.flush();
		}
		catch(IOException ioe) { 
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	public ArrayList<ChatterMessage> getAllHistoryList() {
		return allHistory;
	}
	
	class Listen implements Runnable {
		@Override
		public void run() {
			System.out.println("Listen running...");

			try {
				while (keepGoing) {
					System.out.println("reading from oIn");
					Object readObj = oIn.readObject();	
					
					if (readObj instanceof SArray) {
						System.out.println("received updated name list");
						SArray sa = new SArray();
						sa = (SArray) readObj;
						if (nameList != null) {
							for (int i = nameList.size()-1; i > -1; i--) {
								System.out.println("former name: " + nameList.get(i));
								nameList.remove(i);
							}
						}
						for (int i = 0; i < sa.getAL().size(); i++) {
							System.out.println("new name: " + sa.getAL().get(i));
							nameList.add(sa.getAL().get(i));
						}
						
//						for (int i = 0; allHistory != null && i < allHistory.size(); i++) {
//							if (allHistory.get(i).getSender().equals(this.username)){
//								ChatterMessage updatedCM = new ChatterMessage(allHistory.get(i).getMessageType(), newName, 
//										allHistory.get(i).getRecipient(), allHistory.get(i).getMessage());
//								allHistory.set(i, updatedCM);
//							}
//							else {
//								ChatterMessage updatedCM = new ChatterMessage(allHistory.get(i).getMessageType(), allHistory.get(i).getSender(), 
//										newName, allHistory.get(i).getMessage());
//								allHistory.set(i, updatedCM);				
//							}
//						}
						
						
					}
					else if (readObj instanceof ChatterMessage) {
						ChatterMessage cm = (ChatterMessage) readObj;
						allHistory.add(cm);
						cGUI.printChatHistory();
					}
				} // END while
			} // END try 
			catch(ClassNotFoundException cnfe) {
				System.err.println("caught: " + cnfe + " from ");
				cnfe.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("caught: " + ioe + " from ");
				ioe.printStackTrace();
			} // END catch
		} // END public void run()
	} // END class Listen
	
	public void sendMessage(Map<String, String> info) {
		try {
			ChatterMessage cm = new ChatterMessage(info);
			oOut.writeObject(cm);
			oOut.flush();
		}
		catch (IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}	
	}
	
	public ArrayList<String> getNameList() {
		return nameList;
	}
	
	public void disconnect() {
		try {
			if (oIn != null) { oIn.close();	}
			if (oOut != null) { oOut.close(); }
			if (sock != null) { sock.close(); }
			if (cGUI != null) { cGUI.connectionFailed(); }
		}
		catch(IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

} // END public class ChatterClient