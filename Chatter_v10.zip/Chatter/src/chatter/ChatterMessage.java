package chatter;

import java.io.*;
import java.util.Map;

public class ChatterMessage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	static final int PUBLIC_MESSAGE = 0;
//	static final int PRIVATE_MESSAGE = 1;
//	static final int NAME_CHANGE = 2;
	
	protected String message;
	protected String messageType;
	protected String sender;
	protected String recipient;
	
	// Default constructor
	ChatterMessage() {
		this.message = "";
		this.messageType = "public";
		this.sender = "";
		this.recipient = "";
	}
	
	// Constructor with parameters
	ChatterMessage(String type, String s, String r, String msg) {
		this.messageType = type;
		this.sender = s;
		this.recipient = r;
		this.message = msg;
	}
	
	// Constructor with HashMap
	ChatterMessage(Map<String, String> info) {
		this.messageType = info.get("type");
		this.sender = info.get("sender");
		this.recipient = info.get("recipient");
		this.message = info.get("message");
	}

	public String getMessageType() {
		return messageType;
	}
	
	public String getMessage() {
		return message;
	}
	
	public String getSender() {
		return sender;
	}
	
	public String getRecipient() {
		return recipient;
	}
	

} // END ChatMessage class
