package chatter;

import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class ChatterServer
{
	ServerSocket sock;
	boolean keepGoing = true;
	int publicPort = 55305;
	ArrayList<ClientThread> clientList = new ArrayList<ClientThread>();
	int idNumber = 0;

	public static void main( String[] args ) //throws IOException
	{
		new ChatterServer();
	}

	public ChatterServer()
	{
		System.out.println("chat server starting ...");
		try
		{
			sock = new ServerSocket(publicPort); // open socket

			while (keepGoing)
			{
				// listen for connections
				Socket client = sock.accept(); // this blocks until a client calls      
				System.out.println("ChatterServer: accepts client connection ");

				ClientThread threadToAdd = new ClientThread(client, idNumber);
				System.out.println("adding ClientThread to ArrayList");
				clientList.add(threadToAdd);
				System.out.println("starting ClientThread");
				threadToAdd.start();

				idNumber++;
			}

			sock.close();
		}
		catch( Exception e ) { 
			System.err.println("Caught in ChatServer(): " + e +" from ");
			e.printStackTrace();
		}      
		System.exit(0);
	}


	class ClientThread extends Thread {

		public Socket sock;
		public int uniqueID;
		public String username;

		protected ObjectInputStream oIn;
		protected ObjectOutputStream oOut;
		protected boolean keepGoing = true;

		ClientThread(Socket s, int id) {
			System.out.println("ClientThread constructor executing");
			sock = s;
			uniqueID = id;
			try {
				oOut = new ObjectOutputStream(sock.getOutputStream());
				oOut.writeObject(new ChatterMessage("public", "Server", "all", "A new user has joined this chat"));
				oOut.flush();
				oIn = new ObjectInputStream(sock.getInputStream());
			}
			catch(IOException ioe) {
				System.err.println("Caught in ClientThread constructor: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}

		@Override
		public void run() {
			System.out.println("ClientThread running...");
			try {
				while (keepGoing) {
						ChatterMessage cm = (ChatterMessage) oIn.readObject();
						System.out.println("received a message: '" + cm.getMessage() + "'");
						System.out.println("message type: " + cm.getMessageType());
						if (cm.getMessageType().equalsIgnoreCase("name change")) {
							System.out.println("\tchanging username");
							this.username = cm.getMessage();
						}
						else { sendOut(cm); }
				}
			}
			catch (IOException ioe) {
				System.err.println("Caught in ClientThread.run: " + ioe + " from ");
				ioe.printStackTrace();
			} catch (ClassNotFoundException cnfe) {
				System.err.println("Caught in ClientThread.run: " + cnfe + " from ");
				cnfe.printStackTrace();
			}
		}

	}

	public void sendOut(ChatterMessage cm) {
		try {
			System.out.println("sending out a message: '" + cm.getMessage() + "'");
			if (cm.getMessageType().equalsIgnoreCase("public")) {
				System.out.println("\tdetermined that message is public");
				for (int i = 0; i < clientList.size(); i++) {
					System.out.println("\tsending to " + clientList.get(i).username);
					clientList.get(i).oOut.writeObject(cm); // Demeter violation, but using
					clientList.get(i).oOut.flush(); 		// fairly dependable objects
				}
			}
			else {
				System.out.println("\tdetermined that message is private");
				for (int i = 0; i < clientList.size(); i++) {
					if ((clientList.get(i).username.equals(cm.getRecipient()))
							|| (clientList.get(i).username.equals(cm.getSender()))) {
						System.out.println("\tsending to " + clientList.get(i).username);
						clientList.get(i).oOut.writeObject(cm); // Demeter violation, but using
						clientList.get(i).oOut.flush(); 		// fairly dependable objects
					}
				}
			}
		}
		catch(IOException ioe) {
			System.err.println("Caught in ClientThread.run: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}
}