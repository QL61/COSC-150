package go;

import java.awt.Color;

public abstract class Player {

	private int threadID;
	private Color color;
	private String mode;
	
	public abstract String placeMove(int row, int col);
	public void setThreadID(int id) {
		threadID = id;
	}
	public void setColor(Color newColor) {
		color = newColor;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public int getThreadID() {
		return threadID;
	}
	public Color getColor() {
		return color;
	}
	public String getMode() {
		return mode;
	}
}

