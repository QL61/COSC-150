package go;

public class Human extends Player{

	@Override
	public String placeMove(int row, int col) {		
		return "\0" + row + "\0" + col;
	}

}
