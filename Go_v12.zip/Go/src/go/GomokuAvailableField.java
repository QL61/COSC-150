package go;
/**
 * GomokuAvailableField.java
 */


import java.util.Arrays;
import java.util.LinkedList;

//AI Class

/**
 * Create a structure to store the free fields from a GameBoard board. The 
 * field index is used to store the board value, if the board field index[x]
 * is used as next move
 */
public final class GomokuAvailableField extends LinkedList {
    /**
	 * 
	 */
	// Added constants MARK
	static final int PLAYER_A = 0;         //piece PLAYER_A
	static final int PLAYER_B = 1;         //piece PLAYER_B
	static final int UNALLOCATED = -999999;
	static final int ALLOCATED = 999999;
	
	private static final long serialVersionUID = 1L;
	/* index[i] = UNALLOCATED if get(i) == null
     * index[i] = ALLOCATED if get(i) == obj
     * index[i] between -999999 und 999999 if move get(i) has the Value index[i];
     */
    private int[] index;
    
    /** 
     * Creates a new instance of GomokuAvailableField 
     * @param width     board width
     * @param depth     board depth
     */
    public GomokuAvailableField(final int width,final int depth) {
        super();
        index = new int[pairingVal(new PlayerPosition(width,depth))+1];
        Arrays.fill(index,UNALLOCATED);
    }
    
    /**
     * Create a new GomokuAvailableField as copy from another
     * @param ls    a GomokuAvailableField to be copied
     */
    public GomokuAvailableField(GomokuAvailableField ls) {
        super();
        int i;
        index = new int[ls.index.length];
        System.arraycopy(ls.index,0,index,0,index.length);
        for ( i=0 ; i<ls.size() ; i++) super.addLast(ls.get(i));
    }
    
    /**
     * Creates a new GomokuAvailableField where the free fields are (sorted) give
     * @param ls    Sorted list of free board fields
     * @param width GomokuBoard width
     * @param depth GomokuBoard depth
     */
    public GomokuAvailableField(final int[] ls,final int width,final int depth) {
        super();
        index = new int[pairingVal(new PlayerPosition(width,depth))+1];
        Arrays.fill(index,UNALLOCATED);
        for ( int i=0 ; i<ls.length ; i++) addLast(invPairing(ls[i]));
    }
    
    /**
     * Sorts the free board fields in order ascendent for PLAYER_B player
     * and descendent for PLAYER_A player and give back a array of integer 
     * that represents ordered positions.
     * @param   Player to which free will be sorted
     * @return  sorted free
     */
    protected int[] getFreeSorted(final int Player) {
        int i,j,k=0;
        int[] hlp = new int[this.size()]; //stores the position's values
        int[] ret = new int[this.size()]; //stores the ordered positions
        for ( i=0, j=0; i<index.length; i++ )
            if ( index[i] != UNALLOCATED  && index[i] != ALLOCATED) {
                //all calculated values for think level 0 are copied into hlp
                hlp[j++] = index[i];
            }
        Arrays.sort(hlp); //position's values are sorted in ascending order
        for ( i=0; i<index.length ; i++ ) {
            if ( index[i] != UNALLOCATED && index[i] != ALLOCATED ) {
                j=Arrays.binarySearch(hlp, index[i]); //search into help where is the value index[i]
                if( Player == PLAYER_A ) {
                    //if PLAYER_A the last player was, ret should be ascending sorted for PLAYER_B
                    if ( ret[j] != 0 ) {
                        //ret[j] is already occupied
                        k=j;
                        while ( j>=0 && hlp[j] == index[i] && ret[j] != 0) {
                            //seek backward one free ret[j]
                            j--;
                        }
                        if ( ! (j>=0 && hlp[j] == index[i] && ret[j] == 0)) {
                            //backwards was no free ret[i] found
                            j=k;
                            while ( j<hlp.length && hlp[j] == index[i] && ret[j] != 0) {
                                //seek  one free ret[j]
                                j++;
                            }
                        }
                    }
                    ret[j]=i;
                } else {
                    //if PLAYER_B the last player was, ret schould be descending sorted for PLAYER_A
                    int invJ=hlp.length-1-j;
                    if ( ret[invJ] != 0 ) {
                        //ret[j] is already occupied
                        k=j;
                        while ( j>=0 && hlp[j] == index[i] && ret[invJ] != 0) {
                            //seek backward one free ret[invJ]
                            j--;
                            invJ++;
                        }
                        if ( ! (j>=0 && hlp[j] == index[i] && ret[invJ] == 0)) {
                            //backwards was no free ret[i] found
                            j=k;
                            invJ=hlp.length-1-j;
                            while ( j<hlp.length && hlp[j] == index[i] && ret[invJ] != 0) {
                                //seek forward one free ret[j]
                                j++;
                                invJ--;
                            }
                        }
                    }
                    ret[invJ]=i;
                }
            }
        }
        return ret;
    }
    
    /**
     * sets the board value at a position
     * @param pos   position that should be set
     * @param val   board value
     */
    public void setIndex(final int pos,final int val) {
        if ( index[pos] != UNALLOCATED ) {
            index[pos] = val;
        } else {
            System.out.println("Error: GomokuAvailableField :index["+pos+"] ");
            System.exit(1);
        }
    }
    
    /**
     * adds a new free position at the end of the list
     * @param   position to be inserted
     */
    @Override
    public void addLast(final Object obj) {
        final int pos = pairingVal((PlayerPosition) obj);
        if (index[pos] == UNALLOCATED) {
            super.addLast(obj);
            index[pos]= ALLOCATED;
        }
    }
    
    /**
     * gets a position and remove from free list
     * @return  position
     */
    public PlayerPosition getBest() {
        Object ret;
        if (! isEmpty()) {
            ret = super.removeFirst();
            int pos = pairingVal((PlayerPosition) ret);
            index[pos] = UNALLOCATED;
        } else {
            ret = null;
        }
        return (PlayerPosition) ret;
    }

    /**
     * gets the position with max value (for PLAYER_B player) or min value
     * (for PLAYER_A player)
     * @return max/min position
     */
    protected PlayerPosition MaxMin(final int lastPlayer) {
        if ( lastPlayer == PLAYER_B ) { 
            return invPairing(maxIndex());
        } else {
            return invPairing(minIndex());
        }
    }
    
    /**
     * Finds the position with max value and returns a integer that represents
     * this position
     * @returns     position with max value
     */
    private int maxIndex() {
        int maxValue = UNALLOCATED;
        int count = 0;
        int i;
        for ( i=0 ; i<index.length ; i++) {
            if ( index[i] != ALLOCATED && index[i] != UNALLOCATED ) {
                if ( index[i] > maxValue ) {
                    maxValue = index[i];
                    count = 1;
                } else {
                    if ( index[i] == maxValue ) count++;
                }
            }
        }
        if ( maxValue > -100000 ) {
            if ( count > 1) {
                count = 1 + (int) ( Math.random()*count );
            }
            for ( i=0 ; count > 0 ; i++)
                if (index[i] == maxValue ) count--;
            return i-1;
        } else {
            /* the game is probably lost, but I will not surrender */
            Object ret = super.get(0);
            return pairingVal((PlayerPosition) ret);
        }
    }

    /**
     * Finds the position with min value and returns a integer that represents
     * this position
     * @returns     position with min value
     */
    private int minIndex() {
        int minValue = ALLOCATED;
        int count = 0;
        int i;
        for ( i=0 ; i<index.length ; i++) {
            if ( index[i] != ALLOCATED && index[i] != UNALLOCATED ) {
                if ( index[i] < minValue ) {
                    minValue = index[i];
                    count = 1;
                } else {
                    if ( index[i] == minValue ) {
                        count++;
                    }
                }
            }
        }
        if ( minValue < 100000 ) {
            if ( count > 1) {
                count = 1 + (int) ( Math.random()*count );
            }
            for ( i=0 ; count > 0 ; i++)
                if ( index[i] == minValue ) count--;
            return i-1;
        } else {
            /* the game is probably lost, but I will not surrender */
            Object ret = super.get(0);
            return pairingVal((PlayerPosition) ret);
        }
    }

    /**
     * converts a position p into a intger value thats represents
     * @param p     a position to convert
     * @return      a integer representation of p
     */
    protected int pairingVal( PlayerPosition p ) {
        return p.pairingVal();
    }
    
    /**
     * converts a integer pos into a position
     * @param pos   a integer to convert
     * @return      a position represented for pos
     */
    protected PlayerPosition invPairing( int pos ) {
        PlayerPosition p = new PlayerPosition();
        p.invPairing(pos);
        return p;
    }
    
    /**
     * Returns the value of a certain position. 
     * This methode is only for tests
     * @param   position to be checked
     * @return  the value of move into p
     */
    protected int valueOf( final PlayerPosition p ) {
        return index[pairingVal(p)];
    }
}
