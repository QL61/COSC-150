/****************************************************************************
 * Name: Qingyue Li															*
 * NetID: QL61																*
 * Class: COSC 150, Fall 2017												*
 * Project: HW3 - Paint														*
/****************************************************************************/

// calculates area and perimeter for triangles

import java.lang.Math;

public class Triangle extends Shape {

	// FIELDS
	private	Coordinates v3;
	private double side1, side2, side3;

	// CONSTRUCTOR
	public Triangle(Coordinates a, Coordinates b, Coordinates c) {
		this.v1 = a;
		this.v2 = b;
		this.v3 = c;
		this.updateSides();
	}
	
	// METHODS
	public double getArea() {
		double p = (side1 + side2 + side3)/2;
		return Math.sqrt(p * (p-side1) * (p-side2) * (p-side3)); // Heron's Formula
	}
	public double getPerimeter() {
		return side1 + side2 + side3;
	}
	@Override public void setV1(Coordinates newV) {
		this.v1 = newV;
		this.updateSides();
	}
	@Override public void setV2(Coordinates newV) {
		this.v2 = newV;
		this.updateSides();
	}
	public void setV3(Coordinates newV) {
		this.v3 = newV;
		this.updateSides();
	}
	private void updateSides() {
		this.side1 = distanceBetween(this.v1, this.v2);
		this.side2 = distanceBetween(this.v2, this.v3);
		this.side3 = distanceBetween(this.v3, this.v1);
	}
}
