/****************************************************************************
 * Name: Qingyue Li															*
 * NetID: QL61																*
 * Class: COSC 150, Fall 2017												*
 * Project: HW3 - Paint														*
/****************************************************************************/

// contains application main()

public class Paint {

	public static void main(String[] args) {
		
		

	}

}
