/****************************************************************************
 * Name: Qingyue Li															*
 * NetID: QL61																*
 * Class: COSC 150, Fall 2017												*
 * Project: HW3 - Paint														*
/****************************************************************************/

// calculates area and perimeter for ovals

import java.lang.Math;
import java.lang.IllegalArgumentException;

public class Oval extends Shape {
	
	// FIELDS
	private	double maj = 0, min = 0;

	// CONSTRUCTOR
	public Oval(Coordinates press, Coordinates release) {
		this.v1 = press;
		this.v2 = release;
		this.updateAxes();
	}
	
	// METHODS
	@Override public double getArea() {
		return Math.PI * maj * min;
	}
	@Override public double getPerimeter() { // calculated using Ramanujan's Formula 1
		return Math.PI*(3*(maj+min)-Math.sqrt((3*maj+min)*(maj+3*min)));
	}
	@Override public void setV1(Coordinates c) {
		this.v2.x += this.v1.x - c.x;
		this.v2.y += this.v1.y - c.y;
		this.v1 = c;
		this.updateAxes();
	}
	@Override public void setV2(Coordinates c) {
		this.v1.x += this.v2.x - c.x;
		this.v1.y += this.v2.y - c.x;
		this.v2 = c;
		this.updateAxes();
	}
	private void updateAxes() {
		double h = Math.abs((v1.x - v2.x) / 2);
		double v = Math.abs((v1.y - v2.y) / 2);
		if (h >= v) {
			this.maj = h;
			this.min = v;
		}
		else {
			this.maj = v;
			this.min = h;
		}
	}
}