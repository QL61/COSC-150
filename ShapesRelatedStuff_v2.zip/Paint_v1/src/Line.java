/****************************************************************************
 * Name: Qingyue Li															*
 * NetID: QL61																*
 * Class: COSC 150, Fall 2017												*
 * Project: HW3 - Paint														*
/****************************************************************************/

// calculates length of line

public class Line extends Shape {
		
	// CONSTRUCTOR
	public Line(Coordinates press, Coordinates release, Color color) {
		this.v1 = press;
		this.v2 = release;
		this.length = distanceBetween(this.v1, this.v2);
		this.color = color;
	}
	
	// METHODS
	@Override public double getArea() { return 0; }
	@Override public double getPerimeter() { return 0; }
	@Override public void setV1(Coordinates c) {
		v1 = c;
		this.length = distanceBetween(this.v1, this.v2);
	} // END setV1(Coordinates)
	@Override public void setV2(Coordinates c) {
		v2 = c;
		this.length = distanceBetween(this.v1, this.v2);
	} // END setV2(Coordinates)	
}
