package chatter;

import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;


public class ChatterClient {

	int publicPort = 55305;
	String ip = "141.161.88.4";
	public String username = "ALPHA";
	Socket sock;
	ObjectOutputStream oOut;
	ObjectInputStream oIn;

	boolean keepGoing = true;

	public static void main(String[] args) {
		ChatterClient client = new ChatterClient();
	}

	public ChatterClient() {
		System.out.println("chat client starting ...");
		keepGoing = true; 

		try
		{
			System.out.println("about to try to call 'localhost' / " + publicPort);

			sock = new Socket("localhost", publicPort);

			oOut = new ObjectOutputStream(sock.getOutputStream());
			oOut.flush();
			oIn = new ObjectInputStream(sock.getInputStream());

			System.out.println("setting username");
			setUsername("ALPHA");

			System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();

			System.out.println("creating write thread");
			Thread writeThread = new Thread(new Write());
			writeThread.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("caught in ChatterClient(): " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	public void setUsername(String newName) {
		Map<String, String> nameInfo = new HashMap<String, String>();
		nameInfo.put("type", "name change");
		nameInfo.put("sender", newName);
		nameInfo.put("recipient", "");
		nameInfo.put("message", newName);
		ChatterMessage nameCM = new ChatterMessage(nameInfo);
		try {
			oOut.writeObject(nameCM);
			oOut.flush();
		}
		catch(IOException ioe) { 
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	class Listen implements Runnable {
		@Override
		public void run() {
			System.out.println("Listen running...");

			try {
				while (keepGoing) {
					if (oIn != null) { // THIS IS THE PROBLEM -- how to check if input stream is empty
						System.out.println("reading from oIn");
						ChatterMessage cm = (ChatterMessage) oIn.readObject();
						System.out.println(cm.getSender() + ": " + cm.getMessage());
					}
				} // END while
			} // END try 
			catch(ClassNotFoundException cnfe) {
				System.err.println("caught: " + cnfe + " from ");
				cnfe.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("caught: " + ioe + " from ");
				ioe.printStackTrace();
			} // END catch
		} // END public void run()
	} // END class Listen

	class Write implements Runnable {
		@Override
		synchronized public void run() {
			System.out.println("Write running...");

			try {			
				Scanner scan = new Scanner(System.in);
				while(keepGoing) {
					String userInput = scan.nextLine();
					if (userInput != null)
					{
						Map<String, String> cmInfo = new HashMap<String, String>();
						cmInfo.put("type", "public"); // TODO link to GUI
						cmInfo.put("sender", username);
						cmInfo.put("recipient", "all"); // TODO link to GUI
						cmInfo.put("message", userInput);
						System.out.println("creating CM w/ public " + username + " all " + userInput);
						ChatterMessage cm = new ChatterMessage(cmInfo);
						System.out.println("writing CM");
						oOut.writeObject(cm);
					} // END if
				} // END while
				scan.close();
			} // END try
			catch (IOException ioe) {
				System.err.println("caught: " + ioe + " from ");
				ioe.printStackTrace();
			} // END catch
		} // END public void run()
	} // END class Write

} // END public class ChatterClient