/**
 * GomokuServer.java
 */


import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;


/**
 * start a move generator
 */
public class GomokuServer extends Thread implements CONSTANT {
    private static LinkedList<ServerSocket> listenerList = new LinkedList<ServerSocket>(); //List of running server
    private static int counter = 0;     //number of running server
    private int port;                   //port for this server
    private String error="";            //error message
    private boolean started=false;      //is this GomokuServer started
    
    /** 
     * Creates a new instance of GomokuServer 
     * @param port  port where the move generator should runs
     */
    protected GomokuServer(final int port) {
        this.port=port;
    }
    
    /**
     * Gets a list of running servers
     * @return  Port list of the running servers
     */
    protected String[] getServerList() {
        String[] ret = new String[counter];
        for (int i=0; i<ret.length; i++) {
            ret[i] = ""+((ServerSocket)(listenerList.get(i))).getLocalPort();
        }
        return ret;
    }
    
    /**
     * stop a server
     * @param port  Port where the server runs
     */
    protected boolean stopServer(final int port) {
        for (int i=0; i<counter; i++) {
            if ( port==((ServerSocket)(listenerList.get(i))).getLocalPort() )
                try {
                    error="";
                    ((ServerSocket)(listenerList.remove(i))).close();
                    counter--;
                } catch ( Exception e ) {
                    error ="Fehler in GomokuServer/stopServer\n Server (Port:";
                    error += port+" konnte nicht gestoppt werden\n\n";
                    error += e;
                    return false;
                }
        }
        return true;
    }
    
    /**
     * starts a new move generator
     */
    @Override
    public void run() {
        try {
            error="";
            final ServerSocket listener = new ServerSocket(port);
            listenerList.add(listener);
            counter++;
            started=true;
            while (true) {
                final Socket client = listener.accept();
                new GomokuGenerator(client).start();
            }
        } catch ( final Exception e ) {
            error ="Fehler in GomokuServer/run\n Server (Port:";
            error += port+") konnte nicht gestartett werden\n\n";
            error += e;
        }
    }
    
    /**
     * gets the error message
     * @return the error message
     */
    protected String getError() {
        return error;
    }
    
    /**
     * checks if the Server could be started
     * @return  true if the server is started
     */
    protected boolean isStarted() {
        return started;
    }
}
