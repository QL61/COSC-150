/**
 * GomokuGenerator.java
 */


import java.io.*;
import java.net.Socket;


/**
 * implements the move generator
 */
public class GomokuGenerator extends Thread implements CONSTANT {
    /** socket that the move generator listen */
    private Socket toClient;
    /** output stream */
    private PrintWriter out;
    /** input: strategy to use */
    private int strategy;
    /** output: name of the strategies */
    final String[] strategyName = {"defensiv","aggressiv"};
    
    /** 
     * Creates a new instance of GomokuGenerator 
     * @param   Client communication socket
     */
    public GomokuGenerator(final Socket s) {
        toClient = s;
    }
    
    /**
     * starts the move generator
     */
    @Override
    public void run(){
        String line; 
        try {
            final BufferedReader in = new BufferedReader(new InputStreamReader(toClient.getInputStream()));
            out =new PrintWriter(toClient.getOutputStream(),true);
            strategy = Integer.parseInt(in.readLine().trim());
            if ( strategy < 0 | strategy > 1 ) throw new IOException("Strategy:"+strategy+" is not Valid. Please try 0 throw 1");
            final byte player = (byte) Integer.parseInt(in.readLine().trim());
            if ( player < 0 | player > 1 ) throw new IOException("Player:"+player+" is not Valid. Please try 0 or 1");
            final int width = Integer.parseInt(in.readLine().trim());
            if ( width < 8 ) throw new IOException("Width="+width+" not accepted. The board width should be at least 8.");
            final int depth = Integer.parseInt(in.readLine().trim());
            if ( depth < 8 ) throw new IOException("Depth="+depth+" not accepted. The board depth should be at least 8.");
            final int thinkDepth = Integer.parseInt(in.readLine().trim());
            if ( thinkDepth < 1 ) throw new IOException("ThinkDepth="+thinkDepth+" is not valid. Please try a number bigger than 0.");
            Gomoku board = new Gomoku(width,depth);
            for ( int y=1; y<=depth; y++ ) {
                line = in.readLine();
                if ( line.length() != width ) throw new IOException("line "+y+" = "+line+" has false lenght ="+line.length()+". GomokuBoard width is "+width);
                for ( int x=1; x<=width; x++ ) {
                    switch ((byte) (line.charAt(x-1) & 0xff)) {
                        case 111 : board.setPieceTrusted(new PlayerPosition(x,y),WHITE); break; //asc 0
                        case 120 : board.setPieceTrusted(new PlayerPosition(x,y),BLACK); break; //asc x
                        case 46  : break;                                                 //leer
                        default  : throw new IOException("Line "+y+" is not valid. The character on the position "+x+" = "+line.charAt(x-1)+" could not be recognized.");
                    }
                }
            }
            if (board.accept(player)) {
                final PlayerPosition move = new GomokuAlgorithm(new GomokuStrategy(board,thinkDepth,strategy)).getNextMove();
                out.println("OK");
                out.println(" [Strategy " + strategy + " - " + strategyName[strategy]+"]");
                out.println("row: "+ move.getRow());
                out.println("column: " + move.getColumn());
                toClient.close();
            } else {
                switch (board.getError()) {
                    case 1 : throw new IOException("Next player:"+player+" doesn't match with the game state");
                    case 2 : throw new IOException("It is not valid to have pieces concentrate on diferents regions without connection.");
                    case 4 : throw new IOException("Game out - The game has already a winner!");
                    case 8 : throw new IOException("Game out - There are no free field to set a piece!");
                    default: throw new IOException("Unknown Error");
                }
            }
        } catch (Exception e) {
				System.err.println("Error: Caught in GomokuGenerator(): " + e +" from ");
				e.printStackTrace();
            try { if (toClient.isConnected()) toClient.close(); } catch (Exception ex) {};
        }
    }
}
