import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/**
 * The class GomokuGui implements a User Interface for a Gomoku game.
 */ 
public final class GomokuGui extends javax.swing.JFrame implements CONSTANT {
    private int[] dim = {15,15};                        //Default board width=15 and depth=15
    private int[] thinkDepth = {4,4};                   //thinkdepth[4] for WHITE and thinkdepth[4] for BLACK
    private int[] strategy = {1,1};                     //strategy[1] for WHITE and strategy[1] for BLACK
    private int[] playerType = {0,1};                   //kind of player 0=Human; 1=computer; 2=Move generator
    private int[] winCounter = {0,0};                   //to store the game score
    private int player = WHITE;                        //player on the turn
    private String[] moveGenerator = {"","",""};        //variable to store the version of the move generator
    private String[] host = {LOCALHOST,LOCALHOST};  //move generator for player One=WHITE and Two=BLACK
    private int[] port = {0,0,7888};                    //default port and port for move generator for player One=WHITE and Two=BLACK
    private int falseMove = 0;                          //counter for wrong moves, if falseMove>5 than brakes the game
   private static GomokuGui gameGUI;                      //Game window
    private PaintBoard pBoard;                          //Game drawer
    private JTextArea statusLabel;                      //Status lines (3)
    private JMenuItem gamePlayers;                      //Menu to configure the player 
    private boolean returnCode;                         //help variable to return a Value
    private JCheckBox userToggleble= new JCheckBox(ALTERNATING,true); //configure if the users should be toggled after a game
    

    /**
     * Creates a new GomokuGui for a Gomoku game
     */
    public GomokuGui(){
        initGUI();
        pack();
        setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the GUI. 
     */
    private void initGUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle(GAMENAME);
        getContentPane().setLayout(new BorderLayout());
        pBoard = new PaintBoard();
        pBoard.setPreferredSize(new Dimension(460,460));
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((d.width-468)/2, (d.height-607)/2);
        // ***************************************************************  Menu
        ActionListener MenuAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (((JMenuItem)e.getSource()).getText().equals(RESET)) startNewGame();
                if (((JMenuItem)e.getSource()).getText().equals(RULES)) spielRegeln();
                if (((JMenuItem)e.getSource()).getText().equals(END)) System.exit(0);
                if (((JMenuItem)e.getSource()).getText().equals(B15X15)) startNewGame(15,15);
                if (((JMenuItem)e.getSource()).getText().equals(START)) startServer();
                if (((JMenuItem)e.getSource()).getText().equals(STOP)) stopServer();
                if (((JMenuItem)e.getSource()).getText().equals(PLAYER)) configPlayer();
            }
        };
        JMenuBar menuBar = new JMenuBar();
            JMenu menuGame = new JMenu(GAME);
            
            	gamePlayers = new JMenuItem(PLAYER);
            		gamePlayers.addActionListener(MenuAction);
            
                JMenuItem gameRestart = new JMenuItem(RESET);
                    gameRestart.addActionListener(MenuAction);
                JMenuItem gameRule = new JMenuItem(RULES);
                    gameRule.addActionListener(MenuAction);
                JMenuItem gameEnd = new JMenuItem(END);
                    gameEnd.addActionListener(MenuAction);
                    
                       
            JMenu menuServ = new JMenu(SERVER);
                JMenuItem servStart = new JMenuItem(START);
                    servStart.addActionListener(MenuAction);
                JMenuItem servStopp = new JMenuItem(STOP);
                    servStopp.addActionListener(MenuAction);
           
                menuBar.add(menuGame);
                	menuGame.add(gameRestart);
                	menuGame.add(gameRule);
                	menuGame.add(gameEnd); 
                	menuGame.add(gamePlayers);
                                
            menuBar.add(menuServ);
                menuServ.add(servStart);
                menuServ.add(servStopp);
        setJMenuBar(menuBar);
        //********************************************************  Status lines
        statusLabel = new JTextArea(3,40);
        statusLabel.setEditable(false);
        statusLabel.setFont(new Font("Monospaced",java.awt.Font.BOLD,10));
        statusLabel.setBackground(Color.WHITE);
        statusLabel.setText(NEXTPLAYER+":\t"+CWHITE);
        //*************************************************************  Toolbar
        JToolBar toolBar = new javax.swing.JToolBar("JToolBar");
            toolBar.add(new AbstractAction("Neu", new ImageIcon(getClass().getResource("images/checker.gif"))) {
                @Override
                public void actionPerformed(ActionEvent e) {startNewGame();}
            }).setToolTipText(GAMERESET);
           
            
            toolBar.add(new AbstractAction(MGS, new ImageIcon(getClass().getResource("images/network7.gif"))) {
                @Override
                public void actionPerformed(ActionEvent e) {startZGS(7888);}
            }).setToolTipText(STARTSERVER);
            toolBar.add(new AbstractAction(END, new ImageIcon(getClass().getResource("images/door02.gif"))) {
                @Override
                public void actionPerformed(ActionEvent e) {System.exit(0);}
            }).setToolTipText(ENDGAME);
        //**********************************************************
        getContentPane().add(toolBar, BorderLayout.NORTH);
        getContentPane().add(pBoard, BorderLayout.CENTER);
        getContentPane().add(statusLabel, BorderLayout.SOUTH);
    } //initGui
    
    
    
    /**
     * starts a new game with given size
     * @param   new board width
     * @param   new board height
     */
    private void startNewGame(final int width,final int depth) {
        dim[0] = width;
        dim[1] = depth;
        pBoard.reset();
        if ( playerType[0] != 0 ) pBoard.startGame();
    }

    /**
     * starts a new game
     */
    private void startNewGame() {
        if (pBoard.getStatus() < FREE && falseMove<5) {
            pBoard.reset();
        } else {
            pBoard.reset();
            if ( playerType[0] != 0 ) pBoard.startGame();
        }
    }
    
    /**
     * displays the game rules
     */
    private void spielRegeln() {
        String rule = GAMERULES;
        JOptionPane.showMessageDialog(
                    gameGUI,
                    rule,
                    GAMENAME,
                    JOptionPane.INFORMATION_MESSAGE,
                    new ImageIcon(getClass().getResource("images/userManual.jpg"))
        );
    }
    
 
    /**
     * displays a input dialog, where can be selected one ZGS to be stopped
     */
    private void stopServer() {
        String[] ports = (new GomokuServer(99999)).getServerList();
        if (ports.length>0) {
            String port1 = (String) JOptionPane.showInputDialog(
                        gameGUI, 
                        MGSSTOP,
                        MGSSTOP,
                        JOptionPane.QUESTION_MESSAGE,
                        new ImageIcon(getClass().getResource("images/network7.gif")),
                        ports,
                        ports[0]
            );
            if (port1 != null) {
                int port2 = Integer.parseInt(port1.trim());
                GomokuServer server =new GomokuServer(99999);
                if (!server.stopServer(port2)) wrongInput(server.getError());
            }
        } else {
            JOptionPane.showMessageDialog(
                        gameGUI,
                        ERRMGSSTOPPED,
                        MGSSTOP,
                        JOptionPane.INFORMATION_MESSAGE,
                        new ImageIcon(getClass().getResource("images/error.gif"))
            );
        }
    }
    
    /**
     * starts a ZGS
     * @param    Port number where the ZGS should be started
     */
    private void startZGS(int port) {
        GomokuServer ZGS = new GomokuServer(port);
        ZGS.start();
        try {
            Thread.sleep(500);
        } catch  ( Exception e ) {}
        if (ZGS.isStarted()) {
            if (checkZGS(LOCALHOST,port)) {
                JOptionPane.showMessageDialog(
                    gameGUI,
                    MGSONPORT+port+SUCCSTART,
                    MGS,
                    JOptionPane.INFORMATION_MESSAGE,
                    new ImageIcon(getClass().getResource("images/computer30.gif"))
                );
            } else {
                wrongInput(ERRMGSSTART+ port+ERRSTART);
            }
        } else {
            wrongInput(ZGS.getError());
        }
    }

    /**
     * displays a dialog to input the port number for a new ZGS
     */
    private void startServer() {
        String port1 = (String) JOptionPane.showInputDialog(
                    gameGUI, 
                    ENTERPORT1,
                    ENTERPORT2,
                    JOptionPane.QUESTION_MESSAGE
        );
        int port2 = Integer.parseInt(port1.trim());
        if (port2>10 && port2<99999) {
            port[2]=port2;
            startZGS(port[2]);
        } else {
            wrongInput(ERRPORT1);
        }
    }

    /**
     * returns a JPanel with the given image
     * @param    file name of the image to be displayed
     * @return   a JPanel with the given image
     */
    private JPanel displayGif(final String gif) {
        JPanel ret = new JPanel(new BorderLayout());
        JLabel img = new JLabel(new ImageIcon(getClass().getResource(gif)));
        img.setBorder(BorderFactory.createEmptyBorder(-5,-5,5,5));
        ret.add(img,BorderLayout.CENTER);
        return ret;
    }

    /**
     * returns a Jpanel with the buttons ok and cancel
     * @param    the button ok
     * @param    the button cancel
     * @return   a JPanel with the two given buttons
     */
    private JPanel displayOkCancel(JButton ok, JButton cancel) {
        JPanel ret = new JPanel(new GridLayout(1,4));
        JButton dummy1 = new JButton();
        JButton dummy2 = new JButton();
        dummy1.setVisible(false);
        dummy2.setVisible(false);
        ret.add(dummy1);
        ret.add(ok);
        ret.add(cancel);
        ret.add(dummy2);
        return ret;
    }

    /**
     * returns a Jpanel with the button ok 
     * @param    the button ok
     * @return   a JPanel with the two given buttons
     */
    private JPanel displayOk(JButton ok) {
        JPanel ret = new JPanel(new GridLayout(1,3));
        JButton dummy1 = new JButton();
        JButton dummy2 = new JButton();
        dummy1.setVisible(false);
        dummy2.setVisible(false);
        ret.add(dummy1);
        ret.add(ok);
        ret.add(dummy2);
        return ret;
    }

    /**
     * returns a JPanel with a dialog to input the connections informations
     * to a GZS
     * @param    field for hostname or IP-Adress of the GZS
     * @param    field for port where the GZS is running
     * @return   JPanel with the input dialog
     **/
    private JPanel displayGSZinput(JTextField host, JTextField port) {
        final JPanel ret = new JPanel(new GridLayout(0,2));
        int i ;
        JLabel[] dummy = new JLabel[6];
        for ( i=0; i<6; i++) {
            dummy[i]=new JLabel("");
            dummy[i].setVisible(false);
        }
        if ( host.getText().length() == 0 ) {
            host.setText(LOCALHOST);
            host.selectAll();
            port.setText("7888");
        }
        i=0;
        ret.add(dummy[i]); i++;
        ret.add(dummy[i]); i++;
        ret.add(new JLabel(ENTERHOST));
        ret.add(host);
        ret.add(dummy[i]); i++;
        ret.add(dummy[i]); i++;
        ret.add(new JLabel(ENTERPORT3));
        ret.add(port);
        ret.add(dummy[i]); i++;
        ret.add(dummy[i]); i++;
        return ret;
    }

    /**
     * displays a dialog to input the connections informations to a GZS
     * @param    the player which plays with a ZGS
     */
    private void configServer(final int player) {
        final JDialog serverConf = new JDialog(gameGUI, MGSDATA,true);
        final JTextField hostTF = new JTextField(1);
        final JTextField portTF = new JTextField(1);
        serverConf.getContentPane().setLayout(new BorderLayout());
        JButton ok = new JButton("OK");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                host[player] = hostTF.getText();
                port[player] = Integer.parseInt(portTF.getText().trim());
                if (port[player]<10 || port[player]>99999) {
                    wrongInput(ERRPORT2);
                } else {
                    if ( checkZGS(player) ) {
                        returnCode=true;
                        serverConf.dispose(); // Closes the dialog
                    }                                
                }
            }
        });
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                serverConf.dispose(); // Closes the dialog
            }
        });
        serverConf.setLocationRelativeTo(gameGUI);
        serverConf.getContentPane().add(displayGif("images/computer30.gif"),BorderLayout.WEST);
        serverConf.getContentPane().add(displayGSZinput(hostTF,portTF),BorderLayout.CENTER);
        serverConf.getContentPane().add(displayOkCancel(ok,cancel),BorderLayout.SOUTH);
        serverConf.pack();
        serverConf.setVisible(true);
    }

    /**
     * converts the player type Sting into a integer value
     * @param    type of player
     */
    private int convPlayerType(final String type) {
        if (type==HUMAN) return 0;
        if (type==COMPUTER) return 1;
        if (type==MG) return 2;
        return 3; //this is a error
    }

    /**
     * creates a JPanel to input the player type, think level and strategy
     * @return   Jpanel to input the player type, think level and strategy
     */
    private JPanel JPanelconfigPlayer() {
        final JPanel playerConf = new JPanel(new GridLayout(0,3));
        final String[] playerTypes = {HUMAN,COMPUTER,MG};
        final String[] thinkLevel = {"1","2","3","4","5","6","7"};
        final String[] strategies = {"0","1"};
        final JComboBox[] playerTypeCB = {new JComboBox(playerTypes),new JComboBox(playerTypes)};
        final JComboBox[] thinklevelCB = {new JComboBox(thinkLevel),new JComboBox(thinkLevel)};
        final JComboBox[] strategyCB = {new JComboBox(strategies),new JComboBox(strategies)};
        playerTypeCB[0].setSelectedIndex(playerType[0]);
        playerTypeCB[1].setSelectedIndex(playerType[1]);
        thinklevelCB[0].setSelectedIndex(thinkDepth[0]-1);
        thinklevelCB[1].setSelectedIndex(thinkDepth[1]-1);
        strategyCB[0].setSelectedIndex(strategy[0]);
        strategyCB[1].setSelectedIndex(strategy[1]);
        JButton ok = new JButton(APPLY);
        playerConf.add(new JLabel(""));
        playerConf.add(new JLabel(CWHITE));
        playerConf.add(new JLabel(CBLACK));
        playerConf.add(new JLabel(TYPE));
        playerConf.add(playerTypeCB[0]);
        playerConf.add(playerTypeCB[1]);
        playerConf.add(new JLabel(LEVEL1));
        playerConf.add(thinklevelCB[0]);
        playerConf.add(thinklevelCB[1]);
        playerConf.add(new JLabel(STRATEGY));
        playerConf.add(strategyCB[0]);
        playerConf.add(strategyCB[1]);
        playerConf.add(userToggleble);
        playerConf.add(new JLabel(""));
        playerConf.add(new JLabel(""));
        playerConf.add(new JLabel(""));
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                for (int i=0 ; i<2; i++) {
                    thinkDepth[i] = thinklevelCB[i].getSelectedIndex()+1;
                    strategy[i] = strategyCB[i].getSelectedIndex();
                    playerType[i] = convPlayerType((String) playerTypeCB[i].getSelectedItem());
                    winCounter[WHITE] = 0;
                    winCounter[BLACK] = 0;
                }
            }
        });
        playerTypeCB[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                //if player is human than think level is set to 1
                //for image selection on game over
                if (playerTypeCB[0].getSelectedItem()==HUMAN) {
                    thinklevelCB[0].setSelectedItem("1");
                    strategyCB[0].setSelectedIndex(0);
                }
                //if player type is GZS than more information is needed
                if (playerTypeCB[0].getSelectedItem()==MG) {
                    returnCode=false;
                    configServer(0);
                    // if GZS not works set type to human
                    if (! returnCode) playerTypeCB[0].setSelectedItem(HUMAN);
                }
            }
        });
        playerTypeCB[1].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                //if player is human than think level is set to 1
                //for image selection on game over
                if (playerTypeCB[1].getSelectedItem()==HUMAN) {
                    thinklevelCB[1].setSelectedItem("1");
                    strategyCB[1].setSelectedIndex(0);
                }
                //if player type is GZS than more information is needed
                if (playerTypeCB[1].getSelectedItem()==MG) {
                    returnCode=false;
                    configServer(1);
                    // if GZS not works set type to human
                    if (! returnCode) playerTypeCB[1].setSelectedItem(HUMAN);
                }
            }
        });
        playerConf.add(ok);
        return playerConf;
    }

    /**
     * displays a dialog to input the player type, think level and strategy
     */
    private void configPlayer() {
        final JDialog playerConf = new JDialog(gameGUI,GAMECONFIG,true);
        playerConf.getContentPane().setLayout(new BorderLayout());
        playerConf.setLocation(100,100);
        
        JButton ok = new JButton("Close");
        JButton cancel = new JButton("Cancel");
        ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                playerConf.dispose(); // Closes the dialog
            }
        });
        
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                playerConf.dispose(); // Closes the dialog
            }
        });
        
        playerConf.getContentPane().add(JPanelconfigPlayer(),BorderLayout.CENTER);
        playerConf.getContentPane().add(displayOkCancel(ok,cancel),BorderLayout.SOUTH);
        playerConf.setSize(370,190);
        playerConf.setVisible(true);
    }

    /**
     * display a error message
     * @param    message to be displayed
     */
    private void wrongInput(final String message) {
        JOptionPane.showMessageDialog(
            gameGUI,
            message,
            ERRORMSG,
            JOptionPane.INFORMATION_MESSAGE,
            new ImageIcon(getClass().getResource("images/error.gif"))
        );
    }

    /**
     * checks if the GZS from player "player" answers
     * @param    player which the GZS shuold be checked
     */
    private boolean checkZGS(final int player) {
        return checkZGS(host[player],port[player],player);
    }
    
    /**
     * checks if the GZS on give host and port is running
     * @param    host where GZS should be running
     * @param    port where GZS should be running
     */
    private boolean checkZGS(final String host,final int port) {
        return checkZGS(host,port,3);
    }
    
    /**
     * checks if the GZS on give host and port is running. The return string
     * will be set to the given player
     * @param    host where GZS should be running
     * @param    port where GZS should be running
     * @param    player which play with the GZS
     * @return   true if the GZS is running
     */
    private boolean checkZGS(final String host,final int port,final int player) {
        final GomokuClient client = new GomokuClient(0,1,new Gomoku(15,15));
        if (client.send(host,port)) {
            if (player<2) moveGenerator[player] = client.getVersion()+LEVEL3+thinkDepth[player]+")";
        } else {
            wrongInput(ERRNOANSWER+client.getRC()+"\n"+client.getVersion());
            return false;
        }
        return true;
    }
        
    /**
     * display a game over message
     * @param    the winner
     */        
    private void displayGameOver(final int winner) {
        final int nr;
        final String[] announce = {WHITEWIN,BLACKWIN,DRAWN,ERR2MANYERR};
        final String[] images = {"images/winner.gif",
                                 "images/error.gif"};
        if ( winner < 2 ) {
            if ( thinkDepth[winner]<thinkDepth[(winner+1)%2] ) nr=1;
            else nr=0;
        } else {
            nr = winner;
        }
        statusLabel.setText("\t"+ announce[winner] + 
                            "\n Player-1  : " + winCounter[0] + " " + moveGenerator[0] + 
                            "\n Player-2: " + winCounter[1] + " " + moveGenerator[1]);
        JOptionPane.showMessageDialog(
            gameGUI,
            announce[winner],
            GAMEOVER2,
            JOptionPane.INFORMATION_MESSAGE,
            new ImageIcon(getClass().getResource(images[nr]))
        );
    }

    /**
     * refresh the status lines
     */
    private void refreshStatus() {
        final String[] farben = {CWHITE,CBLACK};
        if ( pBoard.getStatus() < FREE && falseMove<5){
            gamePlayers.setEnabled(false);  //player type cannot be changed during a game
            statusLabel.setText("Next player:\t"+ farben[player] + 
                                "\n Player-1  : " + winCounter[0] + " " + moveGenerator[0] + 
                                "\n Player-2: " + winCounter[1] + " " + moveGenerator[1]);
        } else {
            gamePlayers.setEnabled(true);   //player type can be changed again
            switch (pBoard.getStatus()) {
                case 3 : statusLabel.setText(NEXTPLAYERWHITE + 
                        CNLWHITE + winCounter[0] + " " + moveGenerator[0] + 
                        CNLBLACK + winCounter[1] + " " + moveGenerator[1]);break;
                case 4 : winCounter[0]++;
                         displayGameOver(0); //White is the winner
                         if (userToggleble.isSelected()) pBoard.changePlayer();
                         break;
                case 5 : winCounter[1]++;
                         displayGameOver(1); //Black is the winner
                         if (userToggleble.isSelected()) pBoard.changePlayer();
                         break;
                case 8 : displayGameOver(2); //game over without winner
                         break;
                default: displayGameOver(3); //too many errors
                                    break;
            }
        }
    }
    
   
    
    private void refresh() {
        gameGUI.pack();
        gameGUI.repaint();
    }
        


    /**
     * This class draw the game board
     */
    private final class PaintBoard extends JPanel {
        private int cell=23;        //size of the representation of a game field
        private int cell15pct=3;    //start poit to draw a piece
        private int cell70pct=16;   //size of a piece
        private int moveThread=0;   //if a move move is beeing calculate 1 otherwise 0
        private boolean reset = false;  //if true the board will be reseted for a new game
        private Gomoku board;       //the Gomoku board for this game

        /**
         * initialize the game board
         */
        public PaintBoard() {
            board = new Gomoku(dim[0],dim[1]);
            addMouseListener(new MouseAdapter(){@Override
            public void mouseClicked(MouseEvent e){thisMouseClicked(e);}});
        }

        /**
         * Draws the game board
         */
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.addRenderingHints(new RenderingHints(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON)
            );
            /** new cell size */
            final int hpCell = java.lang.Math.min(this.getWidth()/dim[0],(this.getHeight())/dim[1]);
            if (cell != hpCell) {
                cell = hpCell;
                cell15pct=(int)(cell*0.15);
                cell70pct=(int)(cell*0.70);
                this.setSize((dim[0]*cell),(dim[1]*cell));
                this.setPreferredSize(new Dimension((dim[0]*cell),(dim[1]*cell)));
                refreshBoard();
            }
            PlayerPosition place = new PlayerPosition(0,0);
            int x = 0, y = 0;
            while (y < ( cell*dim[1] )){
                while ( x < ( dim[0]*cell ) ){
                    place.setColumnRow(1+x/cell,1+y/cell);
                    if (board.getPiece(place)>=4){
                        if (board.getPiece(place)>=8) {
                            //the win fields have special color
                            g2.setColor(new Color( 0,255,127)); // Spring Green 0,255,127
                            g2.fill3DRect(x, y, cell, cell,false);
                        } else {
                            //special colors to show winning row
                             g2.setColor(new Color((float)0.2,(float)0.75,(float)0.45));
                              g2.fill3DRect(x, y, cell, cell,true);
                            }
                    } else {
                        if ((board.getPiece(place)&3)!=FREE) {
                            //for cells which contains pieces
                        	g2.setColor(new Color(65,105,225)); //Royal Blue 65,105,225                        	 
                            g2.fill3DRect(x, y, cell, cell,true);
                        } else {
                            //for cells which don't contains pieces
                         	g2.setColor(new Color(255,0,0));  //Red
                            g2.fill3DRect(x, y, cell, cell,false);
                        }
                    }
                    if ((board.getPiece(place)&3)==BLACK) {
                        //set the color to black
                        g2.setColor(Color.black);
                    }
                    if ((board.getPiece(place)&3)==WHITE) {
                        //set the color to white
                        g2.setColor(Color.white);
                    }
                    if ((board.getPiece(place)&3)!=FREE) {
                        //draw a piece
                        g2.fillOval(x+cell15pct, y+cell15pct , cell70pct, cell70pct);
                    }
                    x += cell;
                }
                x = 0;
                y += cell;
            }
        }
        
        /**
         * Starts the game with a click on the game board.
         * @param   Mouseclick from human player or null
         */
        public void thisMouseClicked(final MouseEvent e) {
            new MakeMove(e).start();
        }
        
        /**
         * starts a new game 
         */
        public void startGame() {
            new MakeMove(null).start();
        }
        
        /**
         * toggles the player colors to the next game
         */
        private void changePlayer() {
            int help;
            String helpS;
            help = thinkDepth[1];
            thinkDepth[1] = thinkDepth[0];
            thinkDepth[0] = help;
            help = strategy[1];
            strategy[1] = strategy[0];
            strategy[0] = help;
            help = playerType[1];
            playerType[1] = playerType[0];
            playerType[0] = help;
            help = winCounter[1];
            winCounter[1] = winCounter[0];
            winCounter[0] = help;
            help = port[1];
            port[1] = port[0];
            port[0] = help;
            helpS = moveGenerator[1];
            moveGenerator[1] = moveGenerator[0];
            moveGenerator[0] = helpS;
            helpS = host[1];
            host[1] = host[0];
            host[0] = helpS;
        }
            
        
        /**
         * redraw the board. But wait a time to be sure that the time between
         * two moves is at least one second.
         */
        public void refreshBoard(){
            refreshStatus();
            refresh();
            try {
                //Always wait 1s to be sure the moves are not too 
                //quickly redraw
                Thread.sleep(500);
            } catch  ( final Exception e ) {}
        }
        
        
        /**
         * Resets the Gomoku board for a new game.
         */
        public void reset() {
            reset = true;
            player=0;
            falseMove=0;
            board = new Gomoku(dim[0], dim[1]);
            do refreshBoard(); while (moveThread > 0);
            reset = false;
        }

        /**
         * gets the game status
         * @return     0 = WHITE was the last player
         * @return     1 = BLACK was the last player
         * @return     3 = the board is yet empty
         * @return     4 = game over and WHITE won
         * @return     5 = game over and BLACK won
         * @return     8 = game over without winner
         * @return     9 = board need to be accepted
         */
        public byte getStatus() {
            return board.getStatus();
        }
        
        /**
         * returns the next move. The variable moveGenerator will be set with the
         * version text from move generator or "Mensch" for a human player or 
         * "Computer" for a computer player.
         * @param player   WHITE or BLACK player
         * @param e         position of mouse click (next move for human player)
         */
        private PlayerPosition play(final int player,final MouseEvent e) {
            PlayerPosition ret = new PlayerPosition();
            switch (playerType[player]) {
                //human
                case 0 : if (e==null) break;
                         ret = new PlayerPosition(1+e.getX()/cell,1+e.getY()/cell);
                         moveGenerator[2] = HUMAN;
                         break;
                //Computer
                case 1 : ret = new GomokuAlgorithm(new GomokuStrategy( board,thinkDepth[player],strategy[player])).getNextMove();
                         moveGenerator[2] = COMPSTRATEGY;
                         break;
                //ZGS
                case 2 : GomokuClient client = new GomokuClient(strategy[player],thinkDepth[player],board);
                         if (client.send(host[player],port[player])) {
                             ret = client.getnextMove();
                             String dummy = client.getVersion();
                             if (dummy.length()>53)
                                moveGenerator[2] = client.getVersion().substring(0,53);
                             else
                                moveGenerator[2] = client.getVersion();                                 
                         } else {
                             wrongInput(client.getRC());
                             falseMove=9;
                             ret = null;
                         }
                         break;
            }
            // Output on console for log the game
            //System.out.print(" "+ret.toString());
            return ret;
        }
        
        /**
         *class to starts the move calculation into a thread
         */
        private final class MakeMove extends Thread {
            private final MouseEvent e; //position where the human player clicked
            
            /**
             *creates a new MakeMove to calculate a move
             **/
            public MakeMove(final MouseEvent e) {
                this.e = e;
                moveThread++;
            }
            
            /**
             *starts the calculation
             */
            @Override
            public void run() {
                if (moveThread==1 ) {
                    //if moveThread is bigger than 1 than there are another 
                    //calculation on going and this should be stopped
                    do {
                        if ( board.getStatus() <= FREE && falseMove<5 ){
                            //resetSuggestions();
                            if ( board.setPiece(play(player,e),(byte) player)) {
                                moveGenerator[player] = moveGenerator[2];
                                player = ( player + 1 ) % 2;
                                falseMove = 0;
                            } else {
                                // move is not allowed
                                falseMove++;
                                if (falseMove>1 && falseMove<5) {
                                    JOptionPane.showMessageDialog(
                                        gameGUI,
                                        ERRMOVE+player+"\n"+falseMove+"/4",
                                        ERRMOVE2,
                                        JOptionPane.INFORMATION_MESSAGE,
                                        new ImageIcon(getClass().getResource("yellowcard2.gif"))
                                    );
                                }
                            }
                        }
                        refreshBoard();
                    } while ( board.getStatus() <= FREE && falseMove<5 && (playerType[player] != 0 && !reset) );
                }
                moveThread--;
            }
        } //class MakeMove
    } //class PaintBoard

    /**
     * Main class, starts the GomokuGui
     */
    public static void main(String[] args) {
        gameGUI = new GomokuGui();
    }
}
