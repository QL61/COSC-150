/**
 * GomokuStrategy.java
 */


import java.util.Arrays;


/**
 * The Class GomokuStrategy has the calculation structure for the
 * implementation of MiniMax and ALPHA-BETA algorithms, each think
 * level needs a new GomokuStrategy object.  
 */
public class GomokuStrategy implements CONSTANT {
    /**board to be analyzed*/
    Gomoku board;          
    /**next move to be simulated*/
    PlayerPosition move;      
    /**sorted set with all Free valid places*/
    GomokuAvailableField free;         
    /**value of the actual board*/
    int value = 0;          
    /**Intermediate values of a think level for the position*/
    int intValue;           
    /**player that set the last piece*/
    byte TDPlayer;          
    /**think level to be used*/
    byte maxTD;             
    /**strategy to be used*/
    byte strategy;          
    /**for the ALPHA-BETA algorithms*/
    int alpha = -INFINIT;   
    /**for the ALPHA-BETA algorithms*/
    int beta = INFINIT;     
    /** 
     * expPat is a two dimension array to stores for each Player the number
     * of some special patterns. With this information is possible to cancel
     * a calculation if is obviously that with this move the game will be lost
     * expPat[WHITE][TREE] # of six-patterns with tree white pieces
     * expPat[WHITE][FOURFIVE] # of five-patterns with four white pieces
     * expPat[WHITE][FOURSIX] # of six-patterns with four white pieces
     * expPat[WHITE][FIVE] # of six-patterns with tree white pieces
     * there are corresponding fields for BLACK
     */
    byte[][] expPat = {{0,0,0,0},{0,0,0,0}};
    /** Structure for line evaluation */
    Eval lineEvalStruc;

    /**
     * Creates a new empty <code>GomokuStrategy</code> structure.
     * @param b             the board to be evaluated
     * @param maxTD         the think depth to use
     * @param strategy      the evaluation method to use
     */
    protected GomokuStrategy(final Gomoku b,final int maxTD,final int strategy) {
        this.maxTD = (byte) maxTD;        
        this.strategy = (byte) strategy;
        TDPlayer = b.getStatus();
        lineEvalStruc = new Eval(TDPlayer,expPat);
        board = new Gomoku(b);
        free = new GomokuAvailableField(b.getWidth(),b.getDepth());
        // if the board is not free, initialize some values:
        if (board.getStatus() < FREE) {
            calcFreeList();
            calcBoardValue();
            if (maxTD>1) sortFreeList();
        }
    }
    
    /**
     * Creates a new <code>GomokuStrategy</code> structure as a copy from another.
     * @param es            the evaluation structure to be copied
     */
    protected GomokuStrategy(final GomokuStrategy es) {
        value = es.value;
        alpha = es.alpha;
        beta = es.beta;
        maxTD = es.maxTD;
        strategy = es.strategy;
        TDPlayer = es.TDPlayer;
        board = new Gomoku(es.board);
        free = new GomokuAvailableField(es.free);
        if (es.move != null) 
            move = (PlayerPosition) free.get(es.free.indexOf(es.move));
        for (int i=WHITE;i<=BLACK;i++) 
            System.arraycopy(es.expPat[i],0,expPat[i],0,expPat[i].length);
        lineEvalStruc = new Eval(es.lineEvalStruc.lastPiece,expPat);
    }
    
    /**
     * Copy a <code>GomokuStrategy</code> structure into another. This Method will
     * be called to initialize the GomokuStrategy structure before the calculation
     * for a new think level started and TDPlayer is already set for this
     * new think level
     * @param es            the evaluation structure to be copied
     */
    protected void copyEvaluation(final GomokuStrategy es) {
        value = es.value;
        alpha = es.alpha;
        beta = es.beta;
        maxTD = es.maxTD;
        TDPlayer = (byte) ((es.TDPlayer+1)%2);
        strategy = es.strategy;
        board.boardcopy(es.board);
        free = new GomokuAvailableField(es.free);
        if (es.move != null) 
            move = (PlayerPosition) free.get(es.free.indexOf(es.move));
        for (int i=WHITE;i<=BLACK;i++) 
            System.arraycopy(es.expPat[i],0,expPat[i],0,expPat[i].length);
    }

    /**
     * set into free all fields that can be used to set the 
     * next piece.
     */
    protected void calcFreeList() {
        addFreeRound(board.getOccupList());
    }
       
    /**
     * set all free fields, around the position p, into free
     * @param p     the position which should be analyzed
     */
    protected void addFreeRound(final PlayerPosition p) {
        final PlayerPosition[] freeCoord = board.getFreeRound(p);
        for (int i=0; freeCoord != null && i < freeCoord.length;i++ ) {
            free.addLast(freeCoord[i]);
        }
    }
    
    /**
     * set all free fields, around all position of the list p, into free
     * @param p     the position list which should be analyzed
     */
    protected void addFreeRound(final PlayerPosition[] p) {
        for (int i=0; i < p.length; i++ ) addFreeRound(p[i]);
    }

    /**
     * Sort free with the best moves at first, to accelerate the algorithm to 
     * find the next best move. With a sorted free the ALPHA-BETA algorithm will
     * cut early a calculation.
     * This method use think depth 1 to sort free.
     **/
    protected void sortFreeList() {
        GomokuStrategy hlpEval = new GomokuStrategy(this);  // create hlpeval as copy
        hlpEval.maxTD = (byte) 1;                   // change think depth to 1
        GomokuAlgorithm hlpMM = new GomokuAlgorithm(hlpEval);         // calculate the moves
        free = new GomokuAvailableField(hlpMM.getFreeSorted(), board.getWidth(), board.getDepth());
    }
    
   

    /**
     * set a piece into a board, calculate the new board value and add into 
     * free the new free fields.
     * @param lp        player that set the last piece before the calculations
     */
    protected void setPiece(){
        // expPat will be changed into this method
        value += lineEvalStruc.subLineValue(board.getRow(move));
        value += lineEvalStruc.subLineValue(board.getColumn(move));
        value += lineEvalStruc.subLineValue(board.getDiagUp(move));
        value += lineEvalStruc.subLineValue(board.getDiagDown(move));
        board.setPieceTrusted(move,TDPlayer);
        addFreeRound(move);
        value += lineEvalStruc.addLineValue(board.getRow(move));
        value += lineEvalStruc.addLineValue(board.getColumn(move));
        value += lineEvalStruc.addLineValue(board.getDiagUp(move));
        value += lineEvalStruc.addLineValue(board.getDiagDown(move));
        intValue = (1-2*TDPlayer)*INFINIT;
    }
    
    /**
     * Calculates the value of the game situation. This is only used to
     * Initialize a new GomokuStrategy.
     */
    protected void calcBoardValue(){
        int i;
        for ( i=1; i <= board.getDepth(); i++) 
            value += lineEvalStruc.addLineValue(board.getRow(i));
        for ( i=1; i <= board.getWidth(); i++) 
            value += lineEvalStruc.addLineValue(board.getColumn(i));
        for ( i=5; i < board.getWidth()+board.getDepth()-4; i++) 
            value += lineEvalStruc.addLineValue(board.getDiagUp(i));
        for ( i=5; i < board.getWidth()+board.getDepth()-4; i++) 
            value += lineEvalStruc.addLineValue(board.getDiagDown(i));
    }
    
    /*
     * The subclass Eval has a structure and methods to calculate the value
     * of each line on a board
     */
    private final class Eval {
        /**player that set the last piece before the calculations*/
        private byte lastPiece;         
        /**max intermediate value. Is reseted if a pattern is recognized*/
        private int intValMax;  
        /**intermediate value. Is reseted on each new analyzed position*/
        private int intVal;     
        /**store the pattern that are found*/
        private int pattern;
        /**the length of the pattern*/
        private int count;      
        /**color of the pattern*/
        private byte color;
        /**recognized value for WHITE and BLACK*/
        private int[] value = new int[2];  
        /**Intermediate value for eP (extPat)*/
        private byte[] ss = new byte[4];  
        /**how extPat*/
        private byte[][] eP;            
        
        /**
         * crates a new Eval structure
         * @param lastPiece     player that set the last piece before the calculations
         * @param extPat        Extended Patterns
         **/
        protected Eval(final byte lastPiece, byte[][] extPat) {
            this.lastPiece=lastPiece;
            eP=extPat;
        }
        
        /*
         * accept values of patterns and counts the number of special patterns
         */
        private void recognize() {
            int i;
            if (color!=FREE) {
                if ( maxTD == 1 || ( strategy==1 && lastPiece==WHITE) ) {
                    /**
                     * If the pattern belongs the last player the pattern value will
                     * be doubled if the think level is odd or for strategy 1
                     * for the move generation for BLACK
                     */
                    if ( lastPiece == color ) {
                        intValMax <<= 1;
                    }
                }
                value[color] += intValMax;
                //the number of special patterns for extPat will be counted
                for (i=3; i>=0; i--) {
                    if (ss[i]>0) {
                        eP[color][i]++;
                        break;
                    }
                }
                for (i=0;i<ss.length;i++) ss[i]=0;
                intValMax = 0;
            }
        }
        
        /**
         * calculates a negative value of a move
         * @param    line to calculate
         * @return   negative value of line
         */
        protected int subLineValue( final byte[] line ) {
            for (int i=0; i<eP[0].length; i++) eP[WHITE][i] *= (-1);
            for (int i=0; i<eP[1].length; i++) eP[BLACK][i] *= (-1);
            final int ret = addLineValue(line);
            for (int i=0; i<eP[0].length; i++) eP[WHITE][i] *= (-1);
            for (int i=0; i<eP[1].length; i++) eP[BLACK][i] *= (-1);
            return -ret;
        }            
        
        /**
         * Calculate the value of a line. Pattern with length 6 and 5 are analyzed
         * to evaluate a line.
         * @param line          line which will be evaluated
         * @param TDPlayer    color from last player
         * @param maxthinkDepth think depth to be used
         * @param strategy      strategy to be used
         * @return  line value.
         * @return  if line value > 0, WHITE is in advantage.
         * @return  if line value < 0, BLACK is in advantage.
         */
        protected int addLineValue( final byte[] line ) {
            Arrays.fill(value,(byte) 0);
            if ( line != EMPTY ) {
                //Initialization of EVAL-Variables
                intValMax = 0;
                pattern = 0;
                color = FREE;
                Arrays.fill(ss,(byte) 0);
                int pos;     //actual position into line
                //seek the first piece into line
                for ( pos=1 ; line[pos] == FREE && pos < line.length-1 ; pos++);
                count = java.lang.Math.min(pos,6)-1;
                for ( ; pos < line.length-1 ; pos++){
                    intVal = 0;
                    if ( line[pos] == FREE ) {
                        pattern <<= 1;
                        if (count<6) count ++;
                    } else {
                        if ( color == FREE ) color=line[pos];
                        if ( color == line[pos] ) {
                            pattern <<= 1;
                            pattern |= 1;
                            count ++;
                        } else {
                            // here a color change is recognized, therefore the intMaxValue
                            // must be saved and a new pattern started.
                            recognize();
                            color = line[pos];
                            // Pattern rollback. The FREE cells on pattern ending should be added to the next pattern
                            for ( count = 0; pattern % 2 == 0 ; count++ ) pattern >>= 1;
                            pattern = 1;
                            count++;
                        }
                    }
                    if ( count == 6 ) {
                        if ( pattern != 0) {
                            switch (strategy) {
                                case 0 : intVal = getValue60(pattern); break;
                                case 1 : intVal = getValue61(pattern); break;
                                default: intVal = getValue60(pattern); break;
                            }
                            if ( intVal != 0 && intValMax < intVal ){
                                intValMax = intVal;
                            }
                        }
                        // reduces the pattern to the least four bits
                        pattern &= 31;
                        count--;
                        if ( pattern == 0 ) {
                            // the line is finished or five free cells are recognized.
                            recognize();
                            color = line[pos];
                        }
                    }
                    if ( count == 5 && intVal == 0 && pattern != 0) {
                        switch (strategy) {
                            case 0 : intVal = getValue50(pattern); break;
                            case 1 : intVal = getValue51(pattern); break;
                            default: intVal = getValue50(pattern); break;
                        }
                        if ( intVal != 0 && intValMax < intVal ) {
                            intValMax = intVal;
                        }
                    }
                    if ( pos==(line.length-2)) {
                        // the line is finished or five free cells are recognized.
                        recognize();
                    }
                } 
            } // If line is empty is nothing to do
            return (value[WHITE] - value[BLACK]);
        }

        /**
         * Gets the value a pattern with five positions.
         * @param  a pattern to evaluate
         * @return  the pattern value
         */
        private int getValue51(final int pattern) {
            switch (pattern){
                case 0 : return 0;
                case 1 : return 1;
                case 2 : return 1;
                case 3 : return 9;
                case 4 : return 1;
                case 5 : return 8;
                case 6 : return 10;
                case 7 : return 90;
                case 8 : return 1;
                case 9 : return 7;
                case 10 : return 9;
                case 11 : return 80;
                case 12 : return 10;
                case 13 : return 80;
                case 14 : return 100;
                case 15 : ss[1]++;return 450;
                case 16 : return 1;
                case 17 : return 5;
                case 18 : return 7;
                case 19 : return 60;
                case 20 : return 8;
                case 21 : return 60;
                case 22 : return 80;
                case 23 : ss[1]++;return 350;
                case 24 : return 9;
                case 25 : return 60;
                case 26 : return 80;
                case 27 : ss[1]++;return 350;
                case 28 : return 90;
                case 29 : ss[1]++;return 350;
                case 30 : ss[1]++;return 450;
                case 31 : ss[3]++;return 200000;
                default : return 0;
            }
        }

        /**
         * Gets the value a pattern with five positions.
         * @param  a pattern to evaluate
         * @return  the pattern value
         */
        private int getValue50(final int pattern) {
            switch (pattern){
                case 0 : return 0;
                case 1 : return 1;
                case 2 : return 1;
                case 3 : return 9;
                case 4 : return 1;
                case 5 : return 8;
                case 6 : return 10;
                case 7 : return 45;
                case 8 : return 1;
                case 9 : return 7;
                case 10 : return 9;
                case 11 : return 40;
                case 12 : return 10;
                case 13 : return 40;
                case 14 : return 50;
                case 15 : ss[1]++;return 90;
                case 16 : return 1;
                case 17 : return 5;
                case 18 : return 7;
                case 19 : return 30;
                case 20 : return 8;
                case 21 : return 30;
                case 22 : return 40;
                case 23 : ss[1]++;return 70;
                case 24 : return 9;
                case 25 : return 30;
                case 26 : return 40;
                case 27 : ss[1]++;return 70;
                case 28 : return 45;
                case 29 : ss[1]++;return 70;
                case 30 : ss[1]++;return 90;
                case 31 : ss[3]++;return 200000;
                default : return 0;
            }
        }

        /**
         * Gets the value a pattern with six positions.
         * @param  a pattern to evaluate
         * @return  the pattern value
         */
        private int getValue61(final int pattern) {
            switch (pattern){
                case 2 : return 20;
                case 4 : return 20;
                case 6 : return 200;
                case 8 : return 20;
                case 10 : return 180;
                case 12 : return 200;
                case 14 : ss[0]++;return 1000;
                case 16 : return 20;
                case 18 : return 160;
                case 20 : return 180;
                case 22 : ss[0]++;return 900;
                case 24 : return 200;
                case 26 : ss[0]++;return 900;
                case 28 : ss[0]++;return 1000;
                case 30 : ss[2]++;return 50000;
                default : return 0;
            }
        }

        /**
         * Gets the value a pattern with six positions.
         * @param  a pattern to evaluate
         * @return  the pattern value
         */
        private int getValue60(final int pattern) {
            switch (pattern){
                case 2 : return 12;
                case 4 : return 12;
                case 6 : return 60;
                case 8 : return 12;
                case 10 : return 48;
                case 12 : return 60;
                case 14 : ss[0]++;return 120;
                case 16 : return 12;
                case 18 : return 36;
                case 20 : return 48;
                case 22 : ss[0]++;return 108;
                case 24 : return 60;
                case 26 : ss[0]++;return 108;
                case 28 : ss[0]++;return 120;
                case 30 : ss[2]++;return 1200;
                default : return 0;
            }
        }
    } //inner class Eval
}
