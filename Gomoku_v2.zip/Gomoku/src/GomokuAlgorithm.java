/**
 * GomokuAlgorithm.java
 */



/**
 * GomokuAlgorithm implements the GomokuAlgorithm and Alpha-Beta algorithms to play Gomoku
 */
public class GomokuAlgorithm implements CONSTANT {
    private GomokuStrategy[] GS;    //think depth +1 GomokuStrategy structures are needed
    private int TD;             //actual think level
    private long timer;         //timer to force a early stop
    private boolean foundBest=false; //found a move where the player wins?
    
    /** 
     * Creates a new instance of GomokuAlgorithm
     * @param e    initial GomokuStrategy structure
     */
    public GomokuAlgorithm(final GomokuStrategy e) {
        //array of Evaluations for all "think levels"
        GS = new GomokuStrategy[e.maxTD+1];
        for (int i=0; i<GS.length;i++) {
            GS[i] = new GomokuStrategy(e);
            //set the correct player on each think level
            if (i>0) GS[i].TDPlayer = (byte)((GS[i-1].TDPlayer + 1) % 2);
        }
        TD = 0;
    }
    
    /**
     *checks if any special win pattern is on board. If there 
     *is any, is possible to predict that a specific player will win and 
     *the move calculation can be stopped early.
     *@return   true if the calculation can be canceled
     */
    private boolean cancelCalc() {
        final int pA=GS[TD].TDPlayer;   //pA laid the actual piece on board.
        final int pB=GS[TD-1].TDPlayer; //pB will make the next move
        if (GS[TD].expPat[pA][FIVE]>0 || GS[TD].expPat[pB][FIVE]>0) {
            //there are a five on board (probably from pA), therefore game over
            return true;
        }
        if (GS[TD].maxTD>1) {
            if ((GS[TD-1].expPat[pA][FOURSIX]>0||
                 GS[TD-1].expPat[pA][FOURFIVE]>0)){
                //no FIVEs are on board (checked already before).
                //pA had already, on the last think level, four stones in a row 
                //but with the current movement pA does not win.
                //Therefore, we suppose this move will never be executed
                //and we can cancel the calculation.
                GS[TD].intValue = (1-2*pB)*180000-TD;
                return true;
            }
            if ((GS[TD].expPat[pB][FOURSIX]>0 ||
                 GS[TD].expPat[pB][FOURFIVE]>0)) {
                //no FIVEs are on board (checked already before).
                //pB has at least one four in a row and can win now.
                //Therefore, we suppose that pA would never had executed
                //the last move and we cancel the calculation
                GS[TD].intValue = (1-2*pB)*180000-TD;
                return true;
            }
            if ( GS[TD].expPat[pA][FOURSIX]>0 ){
                //no FIVEs are on board (checked already before).
                //pB has no FOURSIXes or FOURFIVEs (checked already before).
                //with the current move pA got a four on six-pattern,
                //and pB has no way to avoid that pA win on his next move.
                GS[TD].intValue = (1-2*pA)*180000-TD;
                return true;
            }
            if ( GS[TD].expPat[pB][TREE]>0 && 
                    GS[TD].expPat[pA][FOURFIVE]==0 ){
                //no FIVEs are on board.
                //pB has no FOURSIXes nor FOURFIVEs
                //pA has no FOURSIXes nor FOURFIVEs  
                //with the last move pA didn't block the TREE from pB 
                //and pA is not able to avoid that pB win.
                //Therefore, we suppose that pA would never had executed
                //the last move and we cancel the calculation
                GS[TD].intValue = (1-2*pB)*180000-TD;
                return true;
            }
            if ( GS[TD-1].expPat[pA][TREE]>0 && GS[TD-1].expPat[pB][FOURFIVE]==0 ){
                //idea: allow the calculation to continue if other win pattern
                //idea: for pA are created with the current move
                //no FIVEs are on board.
                //pB has no FOURSIXes nor FOURFIVEs
                //pA has no FOURSIXes nor FOURFIVEs  
                //pA had on the last think level at least one tree on 
                //six pattern and with this move pA gets no four on six pattern
                //and no fours from pB were blocked. Therefore, is not a good
                //move for pA and the calculation can be canceled.
                GS[TD].intValue = (1-2*pB)*180000-TD;
                return true;
            }
        }
        return false;
    }
        
    
    /**
     * calculates the GomokuAlgorithm and alpha-beta algorithms for think depth = 0
     * @return  best position for the next move
     */
    public PlayerPosition getNextMove() {
        // for this method is TD always zero
        timer = System.currentTimeMillis(); //start time
        if (GS[TD].board.getStatus() == FREE) {
            // if this is the first move, than give back a middle position
            return new PlayerPosition(GS[TD].board.getWidth()>>1,GS[TD].board.getDepth()>>1);
        }
        for (int i=0; i<GS[TD].free.size() ; i++){
            //only continue to calculate if there is enough time or no
            //win position is found
            if (System.currentTimeMillis()-timer > COMPTIMELIMIT && foundBest) break;
            // calculate for all valid free position
            GS[TD].move = ((PlayerPosition) GS[TD].free.get(i));
            calcMoveValue(); //recursion - calculate the next think level
            // returned value (of the next think level) is the value for this move
            GS[TD].free.setIndex(GS[TD].move.pairingVal(), GS[TD+1].value);
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>170000) foundBest=true;
            if ( GS[TD].TDPlayer == BLACK ) {
                if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
            } else {
                if ( GS[TD+1].value < GS[TD].beta ) GS[TD].beta = GS[TD+1].value;
            }
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>170000) foundBest=true;
        }
        //If the final calculation time is needed, can be calculated in this way:
        //timer=System.currentTimeMillis()-timer;
        return GS[TD].free.MaxMin(GS[TD].TDPlayer);
    }
    
    /**
     * calculates the GomokuAlgorithm and alpha-beta algorithms for think depth > 0
     */
    private void calcMoveValue() {
        TD++;
        GS[TD].copyEvaluation(GS[TD-1]); //Initialize GS
        GS[TD].free.remove(GS[TD].move); //remove actual move from free list
        GS[TD].setPiece(); //set actual move into the board
        if (!cancelCalc() && TD < GS[TD].maxTD) {
            for (int i=0; i<GS[TD].free.size() ; i++){
                // calculate for all valid free position
                GS[TD].move = ((PlayerPosition) GS[TD].free.get(i));
                calcMoveValue(); //recursion - calculate the next think level
                if ( GS[TD].TDPlayer == BLACK ) {
                    if ( GS[TD+1].value > GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
                } else {
                    if ( GS[TD+1].value < GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value < GS[TD].beta ) GS[TD].beta = GS[TD+1].value;
                }
                if ( GS[TD].beta < GS[TD].alpha ) {
                    break;
                }
            }
        }
        if ( GS[TD].intValue!=INFINIT && GS[TD].intValue!=-INFINIT) {
            GS[TD].value = GS[TD].intValue;
        }
        TD--;
    }
    
    /**
     * Calculates with think depth = 1 and give back a sorted array with the
     * best positions to the next move
     * @return  array with the best positions for the next move
     */
    public int[] getFreeSorted() {
        getNextMove();
        return GS[0].free.getFreeSorted(GS[0].TDPlayer);
    }
    
    /**
     * Displays values of some given positions.
     * This method is only for tests
     * @param   positions list to be checked
     * @return  to standard output the wanted values
     */
    public String valuesOf(final PlayerPosition[] p) {
        String ret = "";
        for (int i=0; i<p.length; i++)
            ret += p[i]+"\t"+GS[0].free.valueOf(p[i])+"\n";
        return ret;
    }
}
