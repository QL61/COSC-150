/**
 * GomokuBoard.java
 */


/**
 * The class GomokuBoard create a two dimensional field as base for a 
 * board game for two player. The play field starts on position (1,1) and ending
 * on (width,depth). The cells (0,0) and (width+1,depth+1) can be used for a game
 * status. The other cells (0,y) and (x,0) are used to keep if the corresponding
 * row, column or diagonal is empty or in use.
 *
 * The cells (0,y) and (x,0) have bit informations to inform the number of pieces:
 *      bit 1 = row has at least one piece
 *      bit 2 = column has at least one piece
 *      bit 4 = diagonal down has at least one piece
 *      bit 8 = diagonal up has at least one piece
 *      bit 32 = column is valid
 * 
 */ 
public class GomokuBoard implements CONSTANT {
    /**field for the board*/
    protected byte[][] board; 
    /**width of board*/
    private int width;      
    /**Number of free fields on the board*/
    private int places;     

    /**
     * Creates a new empty <code>GomokuBoard</code>.
     * @param width     the board width
     * @param depth     the board depth
     */
    protected GomokuBoard(final int width,final int depth ) {
        board = new byte[width+2][depth+2];
        this.width = width;
        places = width*depth;
        reset();
    }
    
    /**
     * Create a new board as copy of a <code>GomokuBoard</code> b.
     * @param b         the board which should be copied.
     */
    protected GomokuBoard( final GomokuBoard b ) {
        board = new byte[b.width+2][b.board[0].length];
        this.boardcopy(b);
    }

    /**
     * Copies a <code>GomokuBoard</code> b on this <code>GomokuBoard</code>..
     * @param b         the <code>GomokuBoard</code> which should be copied.
     */
    protected void boardcopy( final GomokuBoard b ) {
        this.width = b.width;
        this.places = b.places;
        for ( int i=0; i<width+2 ; i++)
            System.arraycopy(b.board[i],0,board[i],0,b.board[0].length);
    }
    
    /**
     * Resets the <code>GomokuBoard</code> for a new game.
     */
    protected void reset() {
        places = width*getDepth();
        for ( int i=0; i < width+2; i++)
            for ( int j=0; j < board[0].length; j++)
                if ( i==0 | j==0 | i==width+1 | j==board[0].length-1 ) { 
                    // status frame
                    board[i][j] = VALID;
                } else {
                    // valid board positions
                    board[i][j] = FREE;
                }
    }

    /**
     * Sets a piece on the <code>GomokuBoard</code>.
     * @param   position p where to set the piece
     * @param   piece to set
     * @return  true if the piece could be set
     */
    protected boolean setPiece(final PlayerPosition p, final byte piece) {
        boolean ret = false;       //return value
        final int x = p.getColumn();    //Column position of p
        final int y = p.getRow();    //Row position of p
        if ( x>0 && y>0 && x<=width && y<=getDepth() ) {
            // set piece on the board:
            board[x][y] = piece;
            // set vertical as used:
            board[x][0] = (byte)(board[x][0] | 1);
            // set horizontal as used:
            board[0][y] = (byte)(board[0][y] | 2);
            // set diagonal down as used:
            if ( y-x >= 0 )
                board[0][y-x+1] = (byte)(board[0][y-x+1] | 4);
            else
                board[x-y+1][0] = (byte)(board[x-y+1][0] | 4);
            // set DiagUp as used:
            if ( x+y-1 <= getDepth() ) 
                board[0][x+y-1] = (byte)(board[0][x+y-1] | 8);
            else
                board[x+y-getDepth()][0] = (byte)(board[x+y-getDepth()][0] | 8);
            // reduce the number of free places:
            places--;
            // all was ok!
            ret = true;
        }
        return ret;
    }
    
    /**
     * Gets the piece on the position p.
     * @param   position
     * @return  the piece on the position
     */
    protected byte getPiece(final PlayerPosition p) {
        return board[p.getColumn()][p.getRow()];
    }
    
    /**
     * Gets the depth of this board.
     * @return  depth of this board.
     */
    protected int getDepth() {
        return board[0].length-2;
    }
    
    /**
     * Gets the width of this board.
     * @return  width of this board.
     */
    protected int getWidth() {
        return width;
    }
    
    /**
     * Gets the number of free places of this board.
     * @return  Number of free fields.
     */
    protected int freePlaces() {
        return places;
    }
    
    /**
     * Gets a list with free position round of position p.
     * @param   position p
     * @return  array with all free positions arround p.
     */
    protected PlayerPosition[] getFreeRound(final PlayerPosition p) {
        final int x = p.getColumn();   // coordinate x of p
        final int y = p.getRow();   // coordinate y of p
        int i,j,counter=0;
        byte[] column;      // column of board to check
        PlayerPosition[] ret;     // return value
        PlayerPosition[] retHelp = new PlayerPosition[8];   // help variable for return value
        // check the values around p:
        for ( i=-1; i<2 ; i++ ) {
            if ( x+i > 0 && x+i <= width ) {
                column = board[x+i];
                for ( j=-1; j<2 ; j++ )
                    // y+j can be out of board but in this case column[y+j]!=FREE
                    if ( column[y+j]==FREE ) retHelp[counter++] = new PlayerPosition(x+i,y+j);
            }
        }
        // copy only the free places to ret
        if ( counter > 0 ) {
            ret = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,ret,0,counter);
            return ret;
        }
        // no places are free around p
        return null;
    }
    
    /**
     * Gets a list with all occupied positions on this board.
     * @return  array with all occupied positions on this board.
     */
    protected PlayerPosition[] getOccupList() {
        int counter=0;
        PlayerPosition[] ret;
        PlayerPosition[] retHelp = new PlayerPosition[width*getDepth()];
        for ( int x=1; x<=width; x++){
            // > VALID means the column exists and is not empty:
            if ( board[x][0] > VALID ) 
                for ( int y=1; y<=getDepth(); y++ )
                    // < FREE means the field is occupied:
                    if ( board[x][y] < FREE ) 
                        retHelp[counter++] = new PlayerPosition(x,y);
        }
        // copy only the used places of retHelp:
        if ( counter > 0 ) {
            ret = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,ret,0,counter);
            return ret;
        }
        // the board has no pieces:
        return null;
    }

    /**
     * Gets the column number which contain the position p.
     * @param   position p
     * @return  coordinate x of position p.
     */
    protected int getColumnNr(final PlayerPosition p) {
        return p.getColumn();
    }
    
    /**
     * Gets the row number which contain the position p.
     * @param   position p
     * @return  coordinate y of position p.
     */
    protected int getRowNr(final PlayerPosition p) {
        return p.getRow();
    }
    
    /**
     * Gets the number of the diagonal Up which contain the position p.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(width,depth)}
     * @param   position p
     * @return  diagonal Up number.
     */
    protected int getDiagUpNr(final PlayerPosition p) {
        return p.getColumn()+p.getRow()-1;
    }
    
    /**
     * Gets the number of the diagonal Down which contain the position p.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(width,1)}
     * @param   position p
     * @return  diagonal Down number.
     */
    protected int getDiagDownNr(final PlayerPosition p) {
        return getDepth()-p.getRow()+p.getColumn();
    }
    
    /**
     * Gets the column which contain the position p.
     * @param   position p
     * @return  array with the column number i.
     * @return  EMPTY if the column is empty.
     * @return  NOTEXIST if the column not exists.
     */
    protected byte[] getColumn(final PlayerPosition p) {
        return getColumn(getColumnNr(p));
    }
    
    /**
     * Gets the column with number i.
     * @param   column number
     * @return  array with the column which contain the position p.
     * @return  EMPTY if the column is empty.
     * @return  NOTEXIST if the column not exists.
     */
    protected byte[] getColumn(final int x) {
        byte[] ret;
        if ( x > 0 && x<=width ) {
            // if there are pieces on the column x
            if ( (board[x][0] & 1) > 0 ) {
                ret = board[x];
            } else {
                ret = EMPTY;
            }
        } else {
            ret = NOTEXIST;
        }
        return ret;
    }

    /**
     * Gets the row which contain the position p.
     * @param   PlayerPosition p
     * @return  array with the row number i.
     * @return  EMPTY if the row is empty.
     * @return  NOTEXIST if the row not exists.
     */
    protected byte[] getRow( final PlayerPosition p ) {
        return getRow( getRowNr(p) );
    }

    /**
     * Gets the row with number i.
     * @param   row number y
     * @return  array with the row which contain the position p.
     * @return  EMPTY if the row is empty.
     * @return  NOTEXIST if the row not exists.
     */
    protected byte[] getRow( final int y ) {
        byte[] ret;
        if ( y > 0 | y<=getDepth() ) {
            // if the row is not empty
            if ( (board[0][y] & 2) > 0 ) {
                byte[] help = new byte[width+2];
                for ( int i=0; i < help.length; i++)
                    help[i] = board[i][y];
                ret = help;
            } else {
                ret = EMPTY;
            }
        } else {
            ret = NOTEXIST;
        }
        return ret;
    }

    /**
     * Gets the diagonal down which contain the position p.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(width,1)}
     * @param   position p
     * @return  array with the diagonal down which contain the position p.
     * @return  EMPTY if the diagonal is empty.
     * @return  NOTEXIST if the diagonal not exists or has less than five cells.
     */
    protected byte[] getDiagDown(final PlayerPosition p) {
        return getDiagDown(getDiagDownNr(p));
    }
    
    /**
     * Gets the diagonal down with number c.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(width,1)}
     * @param   Diagonal number c
     * @return  array with the diagonal down number c.
     * @return  EMPTY if the diagonal is empty.
     * @return  NOTEXIST if the diagonal not exists or has less than five cells.
     */
    protected byte[] getDiagDown( final int c ) {
        byte[] help;
        byte[] ret;
        if ( c > 0 | c < getDepth()+width ) {
            if (c <= getDepth()) {
                // if there are pieces on the diagonal
                if ( (board[0][getDepth()-c+1] & 4) > 0 ) {
                    // create help with proper lenght
                    if ( c <= width ) {
                        help = new byte[c+2];
                    } else {
                        help = new byte[width+2];
                    }
                    for ( int i=1; i < help.length-1; i++)
                        // set help array
                        help[i] = board[i][getDepth()-c+i];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            } else {
                // if there are pieces on the diagonal
                if ( (board[c-getDepth()+1][0] & 4) > 0 ) {
                    // create help with proper lenght
                    if ( c <= width ) {
                        help = new byte[getDepth()+2];
                    } else {
                        help = new byte[getDepth()+width-c+2];
                    }
                    for ( int i=1; i < help.length-1; i++)
                        // set help array
                        help[i] = board[c-getDepth()+i][i];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            }
        } else {
            // c is not valid
            ret = NOTEXIST;
        }
        return ret;
    }
    
    /**
     * Gets the diagonal up which contain the position p.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(width,depth)}
     * @param   position p
     * @return  array with the diagonal up which contain the position p.
     * @return  EMPTY if the diagonal is empty or has less than five cells.
     * @return  NOTEXIST if the diagonal not exists.
     */
    protected byte[] getDiagUp(final PlayerPosition p) {
        return getDiagUp(getDiagUpNr(p));
    }

    /**
     * Gets the diagonal up with number c.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(width,depth)}
     * @param   DiagUp number c
     * @return  array with the diagonal up which contain the position p.
     * @return  EMPTY if the diagonal is empty or has less than five cells.
     * @return  NOTEXIST if the diagonal not exists.
     */
    protected byte[] getDiagUp(final int c) {
        byte[] help;
        byte[] ret = NOTEXIST;
        // check if c is valid:
        if ( c > 0 && c < getDepth()+width ) {
            if (c <= getDepth()) {
                 if ( (board[0][c] & 8) > 0 ) {
                    if ( c <= width ) {
                        help = new byte[c+2];
                    } else {
                        help = new byte[width+2];
                    }
                    for ( int i=1; i <= help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[i][c-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            } else {
                if ( (board[c-getDepth()+1][0] & 8) > 0 ) {
                    if ( c <= width ) {
                        help = new byte[getDepth()+2];
                    } else {
                        help = new byte[width+getDepth()-c+2];
                    }
                    for ( int i=1; i < help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[c-getDepth()+i][getDepth()-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            }
        }
        return ret;
    }

    /**
     * transforms this board into a sequence of strings to print.
     * @return  the symbols "o", "x" and "." in a sequence of lines with fixed length to represent the board.
     */
    @Override
    public String toString() {
        String ret = "";
        for ( int y=1; y <= getDepth(); y++ ) {
            for ( int x=1; x <= width; x++ )
                switch (board[x][y]) {
                    case WHITE : ret += "o"; break;
                    case BLACK : ret += "x"; break;
                    case FREE  : ret += "."; break;
                }
            ret += "\n";
        }
        return ret;
    }
}
