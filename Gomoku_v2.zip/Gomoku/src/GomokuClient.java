/**
 * GomokuClient.java
 */


import java.io.*;
import java.net.InetAddress;
import java.net.Socket;


/**
 * client for move generators
 */
public final class GomokuClient {
    /** strategy to use. At least 0 and 1 should be implemented */
    private int strategy;
    /** player whom move is to be generate */
    private byte player;
    /** board width */
    private int width;
    /** board height */
    private int depth;
    /** think level to be used */
    private int thinkDepth;
    /** the Gogang board which the move should be generated */
    private Gomoku board;
    /** The return code from move generator */
    private String rc;
    /** Version of the move generator */
    private String version;
    /** X move coordinate */
    private int x;
    /** Y move coordinate */
    private int y;
    
    /**
     * Creates a new GomokuClient
     * @param strategy      the strategy to use (0 or 1)
     * @param thinkDepth    the think depth to use (1 to 4)
     * @param b             the Gomoku board
     */
    public GomokuClient(final int strategy,final int thinkDepth,final Gomoku b) {
        this.strategy = strategy;
        player = b.getNextPlayer();
        width = b.getWidth();
        depth = b.getDepth();
        this.thinkDepth = thinkDepth;
        board = b;
    }
    
    /**
     * send the ZugAnfrageNachricht
     * @param adress  the TCP/IP address of the move generator
     * @param port    the port of the move generator
     */
    protected boolean send(final String address,final int port) {
        try {
            // Initialize the communication
            final InetAddress addr = InetAddress.getByName(address);
            final Socket socket = new Socket(addr, port);
            final BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            final PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
            
            out.print(strategy+"\n");
            out.print(player+"\n");
            out.print(width+"\n");
            out.print(depth+"\n");
            out.print(thinkDepth+"\n");
            out.println(board);
            // Receive the ZugNachricht
            rc = in.readLine();
            version = in.readLine();
            if (rc.equals("OK")) {
                // if the Connection returns a value
                y = Integer.parseInt(in.readLine().trim());
                x = Integer.parseInt(in.readLine().trim());
            }
            // close the communication
            socket.close();
        } catch (IOException e) {
            rc="The connection "+address+" Port: "+port+" not working!\n"+e;
			System.err.println("IOException Error: Caught in GomokuClient: " + e +" from ");
			e.printStackTrace();
            return false;
        } catch (NumberFormatException e){
			System.err.println("NumberFormatException Error: Caught in GomokuClient: " + e +" from ");
			e.printStackTrace();
            rc="Error!\n "+rc+"\n\n"+e;
            return false;
        }
        return rc.equals("OK");
    }
    
    /**
     * Gets the next move
     * @return      the calculated move
     */
    protected PlayerPosition getnextMove() {
        return new PlayerPosition(x,y);
    }
    
    /**
     * Gets the version string from move generator
     * @return      the version string
     */
    protected String getVersion() {
        return version;
    }
    
    /**
     * Gets the return code from move generator
     * @return      the return code
     */
    protected String getRC() {
        return rc;
    }
}
