/**
 * CONSTANT.java
 */



public interface CONSTANT {        
    static final String GAMENAME = "Gomoku";
	static final byte WHITE = 0;         //piece white
    static final byte BLACK = 1;         //piece black
    static final byte FREE = 3;          //a free place on the board
    static final byte WIN = 6;           //game over with a winner
    static final byte GAMEOVER = 8;      //the game is over
    
    static final byte VALID = 32;        //a free line on a board
    static final byte INVALID = 16;      //a line that not exist 
    static final byte[] EMPTY = {32};    //no lines are found
    static final byte[] NOTEXIST = {16}; //not possible

    static final int TREE = 0;           //# of six-patterns with tree pieces
    static final int FOURFIVE = 1;       //# of five-patterns with four pieces
    static final int FOURSIX = 2;        //# of six-patterns with four pieces
    static final int FIVE = 3;           //# of six-patterns with tree pieces

    static final int UNALLOCATED = -999999;
    static final int ALLOCATED = 999999;
    static final int INFINIT = 999999;
    
    /**
     * time limit to find the best move in ms
     */
    static final int COMPTIMELIMIT=1000;
    
    // strings for the GUI English
    static final String ALTERNATING="alternating";
    static final String RESET="reset";
    static final String RULES="manual";
    static final String END="end";

    static final String B15X15="15x15";
    static final String BOARD="Gomoku Board";
    static final String CWHITE="white";
    static final String CBLACK="black";
    static final String START="start";
    static final String STOP="stop";
    static final String PLAYER="player";
    static final String NEXTPLAYER="next player";
    static final String NEXTPLAYERWHITE="next player:\twhite";
    static final String GAME="game";
    static final String CONFIGURATION="configuration";
    static final String SERVER="server";
    static final String GAMERESET="<html>Game <i>reset</i></html>";
    static final String ENDGAME="<html>End the game</html>";
    static final String MGS="Move Generator Server";
    static final String STARTSERVER="<html>Start move generator server on port 7888</html>";
    static final String DEFAULTSIZE = "Default size:";
    static final String ERRSIZE2 = "Valid values for width and high are numbers from 8 to 99!";
    static final String SELECT = "Select an option";
    static final String APPLY = "Apply";
    static final String ERRNUMONLY = "Only numbers allowed!\n";
    static final String GAMERULES = "<HTML><BODY>"+
                       "<DIV align=center><STRONG> "+
                       "User Manual</STRONG></DIV>"+
                       "<DIV align=left>Gomoku is a played by two "+
                       "persons on a board with size NxM. On each <BR>"+
                       "round set a player one stone of his colour on one field of "+
                       "the board. The game <BR> is played according the following rules:</DIV>"+
                       "<UL>"+
                       "  <LI>"+
                       "  <DIV align=left>The game starts with an empty "+
                       "  board</DIV></LI>"+
                       "  <LI>"+
                       "  <DIV align=left>The players execute moves in alternating "+
                       "  order. The player with black <BR>Stones (Player A) "+
                       "  starts.</DIV></LI>"+
                       "  <LI>"+
                       "  <DIV align=left>Stones can only be set on "+
                       "  empty fields of the board</DIV></LI>"+
                       "  <LI>"+
                       "  <DIV align=left>Player A must set only black stones, "+
                       "  and player B only white stones on the board</DIV></LI>"+
                       "  <LI>"+
                       "  <DIV align=left>Is not allowed to  "+
                       "  remove stones from the board.</DIV></LI></UL>"+
                       "<DIV align=left>As soon as, in one line ( vertical, horizontal "+
                       "or any diagonal) five stones of one colour <BR> are contiguos the "+
                       "game is over, and the player of that colour won. <BR>Are "+
                       "all fields accupied and there is no win sequence, then the "+
                       "game ends <BR>with a drawn.</DIV></BODY></HTML>";


    static final String MGSSTOP = "Stop move generator";
    static final String ERRMGSSTOPPED = "No move generator active!";
    static final String LOCALHOST = "localhost";
    static final String MGSONPORT = "MGS on port:";
    static final String SUCCSTART = "\nsuccessfuly started";
    static final String ERRMGSSTART = "MGS on port:";
    static final String ERRSTART = "\n not started!";
    static final String ENTERPORT1 = "Enter port (Valid are numbers from 1000 to 99999)";
    static final String ENTERPORT2 = "Enter port number";
    static final String ERRPORT1 = "Invalid port number!";
    static final String ENTERHOST = "Enter hostname/IP-Adresse: ";
    static final String ENTERPORT3 = "Enter port :";
    static final String MGSDATA = "Move generator data";
    static final String ERRPORT2 = "Invalid port number! \nValid are numbers from 1000 to 99999";
    static final String HUMAN = "Human";
    static final String COMPUTER = "Computer";
    static final String MG = "Move generator";
    static final String TYPE = "Type";
    static final String LEVEL1 = "Level: ";
    static final String STRATEGY = "Strategy: ";
    static final String GAMECONFIG = "Game configuration";
    static final String ERRORMSG = "Error";
    static final String ERRNOANSWER = "Wrong server answer!\n";
    static final String WHITEWIN = "White win!";
    static final String BLACKWIN = "Black win!";
    static final String DRAWN = "Drawn!";
    static final String ERR2MANYERR = "To many wrong moves";
    static final String CNLWHITE = "\n White  : ";
    static final String CNLBLACK = "\n Black  : ";
    static final String GAMEOVER2 = "Game Over";
    static final String COMPSTRATEGY = "Computer ";
    static final String LEVEL2 = " - Level: ";
    static final String LEVEL3 = " (Level: ";
    static final String ERRMOVE = "Move not allowed!\nPlayer ";
    static final String ERRMOVE2 = "Move not allowed!";

}