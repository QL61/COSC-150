/**
 * Gomoku.java
 */



public class Gomoku extends GomokuBoard implements CONSTANT {
    /**
     * Creates a new empty Gomoku board.
     * @param width     the board width
     * @param depth     the board depth
     */
    public Gomoku(final int width,final int depth) {
        super(width,depth);
    }
    
    /**
     * Creates a new Gomoku as copy from other
     * @param g     Gomoku to be copied
     **/
    public Gomoku( final Gomoku g ) {
        super(g);
    }
    
    /**
     * Resets the Gomoku board for a new game.
     */
    @Override
    public void reset() {
        super.reset();
        // game status
        setStatus(FREE);
    }
    
    /**
     * checks if the Gomoku board is consistent
     * @param player    last player (color)
     */
    protected boolean accept(final byte player) {
        boolean ret = true;
        int[] counter={0,0};   //counter for pieces
        int x,y;
        for ( x=1; x<=getWidth(); x++)
            for ( y=1; y<=getDepth(); y++){
                //the number of WHITE pieces are counted into counter[WHITE] and
                //the number of BLACK pieces are counted into counter[BLACK] and
                if (board[x][y]==WHITE || board[x][y]==BLACK)
                    counter[board[x][y]]++;
            }
        // checks if no rows are used or the used rows are in sequence
        int vertical = 0;
        for ( x=1; x<=getWidth() & ret; x++)
            if ( (board[x][0] | 1) == 0 ) {
                if (vertical==1) vertical=2;
            } else {
                if (vertical==0) vertical=1;
                if (vertical==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        // checks if no columns are used or the used columns are in sequence
        int horizontal = 0;
        for ( y=1; y<=getDepth() & ret; y++)
            if ( (board[0][y] | 2) == 0 ) {
                if (horizontal==1) horizontal=2;
            } else {
                if (horizontal==0) horizontal=1;
                if (horizontal==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        // checks the diagonals down
        int diagonalDown = 0;
        for ( y=getDepth(); y>1 && ret; y--)
            if ( (board[0][y] | 4) == 0 ) {
                if (diagonalDown==1) diagonalDown=2;
            } else {
                if (diagonalDown==0) diagonalDown=1;
                if (diagonalDown==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        for ( x=2; x<=getWidth() && ret; x++)
            if ( (board[x][0] | 4) == 0 ) {
                if (diagonalDown==1) diagonalDown=2;
            } else {
                if (diagonalDown==0) diagonalDown=1;
                if (diagonalDown==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        // checks the diagonals up
        int diagonalUp = 0;
        for ( y=1; y<=getDepth() && ret; y++)
            if ( (board[0][y] | 8) == 0 ) {
                if (diagonalUp==1) diagonalUp=2;
            } else {
                if (diagonalUp==0) diagonalUp=1;
                if (diagonalUp==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        for ( x=2; x<=getWidth() & ret; x++)
            if ( (board[x][0] | 8) == 0 ) {
                if (diagonalUp==1) diagonalUp=2;
            } else {
                if (diagonalUp==0) diagonalUp=1;
                if (diagonalUp==2) {
                    ret = false;
                    board[getWidth()+1][getDepth()+1] = 2;
                }
            }
        // checks if the player is consistent
        if ( ret && (counter[WHITE]-counter[BLACK]) != player ) {
            board[getWidth()+1][getDepth()+1] = 1;
            ret = false;
        }
        // checks if there are free fields. This is the last check and the
        // game status will be set.
        if ( ret ) {
            if ( (counter[WHITE]+counter[BLACK]) < (getWidth()*getDepth()) ) {
                if (counter[WHITE]+counter[BLACK] == 0){
                    setStatus(FREE);
                } else {
                    setStatus((byte)((player+1) % 2));
                }
            } else {
                board[getWidth()+1][getDepth()+1] = 8;
                ret = false;
            }
        }
        return ret;
    }
    
    /**
     * gets a error code from accept()
     * @returns     error code from accept()
     */
    protected int getError() {
        return board[getWidth()+1][getDepth()+1];
    }
   
    /**
     * Sets a piece without checks on the game board.
     * @param      position where the piece should be set
     * @param      piece color
     * @return     true if was valid the piece on the position to set
     */
    protected void setPieceTrusted(final PlayerPosition p,final byte piece) {
        super.setPiece(p,piece);
        setStatus((byte)9);
    }
    
    /**
     * Checks the Gomoku rules to prove if a move is valid.
     * @param      position where the piece should be set
     * @param      piece color
     * @return     true if it is a valid move.
     */
    @Override
    public boolean setPiece(final PlayerPosition p, byte piece) {
        if (p==null) return false; //error on the move generator!!
        int x = p.getColumn();
        int y = p.getRow();
        boolean ok = true;
        /**
         * Piece can not be set on the border or outside the board.
         */
        if ( x > getWidth() ) return false;
        if ( y > getDepth() ) return false;
        if ( x < 1 ) return false;
        if ( y < 1 ) return false;
        /**
         * At the first move can the player a white piece on each position into
         * the board (Not into the border!)
         */
        if ( getStatus() == FREE && piece == WHITE) {
            setStatus(piece);
            ok = super.setPiece(p,piece);
            return ok;
        }
        /**
         * Piece can only be put on a free position into the board.
         */
        if ( board[x][y] != FREE ) return false;
        /**
         * after the first move, is only valid to put a piece on a position
         * which has at least one of the eight neighbors positions occupied
         * by another piece.
        */
        /*
        for (int dx=-1; dx < 2 & ! ok; dx++)
            for (int dy=-1; dy < 2 & ! ok; dy++)
                if ( board[x+dx][y+dy]<FREE ) {
                    ok=true;
                }
         
        */
        /**
         * The game is over when on a column, row or a diagonal five 
         * pieces from one color form a sequence without interruption. The
         * player with the corresponding color won.
         */
        byte count, countOp;
        for (int dx=-1; dx < 2; dx++)
            for (int dy=-1; dy < 1; dy++) {
                count = countOp = 1;
                if ( dy!=0 || dx==-1 ) {
                    while ( board[x+count*dx][y+count*dy] == piece ) count++;
                    while ( board[x-countOp*dx][y-countOp*dy] == piece ) countOp++;
                    countOp--;
                }
                if ( count + countOp >= 5 ) {
                    markWinner(x,y,dx,dy,piece);
                    piece += 4;
                }
            }
        if (ok) {
            ok = super.setPiece(p,piece);
            if (getStatus() < FREE) setStatus(piece);
            if (super.freePlaces()==0) setStatus(GAMEOVER); //game ending without winner
        }
        
        generatePlayMessage(p,piece == BLACK);
        return ok;
    }
    
    
    
    /**
     * Create a protocol message to communicate across teams
     * @param      position where the piece is set
     * @param      true if piece color is black
     * @return     Play Message
     */

    public String generatePlayMessage(final PlayerPosition p, boolean isBlack) {

	    String msg = GomokuProtocol.generatePlayMessage(isBlack, p.getColumn()-1, p.getRow()-1);  // offset row and column
	    if (GomokuProtocol.isPlayMessage(msg)) {
	        int[] detail = GomokuProtocol.getPlayDetail(msg);
	        // black is 1 and white is 0
	        System.out.println("color is " + detail[0]);
	        System.out.println("row is " + detail[1]);
	        System.out.println("col is " + detail[2]);
	    }  
	    return msg;
    }
    
    
    
    
    
    /**
     * marks the fields where the 5 pieces of the winner are
     * @param x     coordinate where the last piece of the winner is placed
     * @param y     coordinate where the last piece of the winner is placed
     * @param dx    direction where the winner pieces are
     * @param dy    direction where the winner pieces are
     * @param piece color from winner
     */
    private void markWinner(final int x,final  int y,final  int dx,final  int dy,final  byte piece) {
        int count=1,countOp=1;
        while ( board[x+count*dx][y+count*dy] == piece ) {
            board[x+count*dx][y+count*dy] |= 4;
            count++;
        }
        while ( board[x-countOp*dx][y-countOp*dy] == piece ) {
            board[x-countOp*dx][y-countOp*dy] |= 4;
            countOp++;
        }
    }
    
    /**
     * marks the PlayerPosition p as a good next move
     * @param p     field that were a good next move
     */
    public void setTip(final PlayerPosition p) {
        final int x = p.getColumn();
        final int y = p.getRow();
        board[x][y] |= 8;
    }

    /**
     * delete the mark from position p
     * @param p     field to delete a mark
     */
    public void resetTip(PlayerPosition p) {
        final int x = p.getColumn();
        final int y = p.getRow();
        board[x][y] &= 7;
    }
    
    /**
     * Gets the next player.
     * @return  WHITE when BLACK was the last player.
     * @return  WHITE when board is FREE.
     * @return  BLACK when WHITE was the last player.
     */
    public byte getNextPlayer() {
        return (byte) ( (getStatus()+1) % 2 );
    }

    /**
     * Gets the game status.
     * @return     0 = WHITE was the last player
     * @return     1 = BLACK was the last player
     * @return     3 = the board is yet empty
     * @return     4 = game over and WHITE won
     * @return     5 = game over and BLACK won
     * @return     8 = game over without winner
     * @return     9 = board need to be accepted
     */
    public byte getStatus() {
        return (byte)(board[0][0]&31);
    }
    
    /**
     * Gets the game status.
     * @param     status to be set
     */
    private void setStatus(byte status) {
        board[0][0]=(byte)(status|VALID);
    }
}
