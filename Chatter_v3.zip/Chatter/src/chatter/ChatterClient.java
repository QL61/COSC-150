package chatter;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.io.*;


public class ChatterClient {

	private int publicPort;
	private String ip;
	private String username;
	Socket sock;
	BufferedReader bin;
	BufferedWriter bout;
	Listen listenToServer;
	static ClientGUI clientGUI;
	boolean keepGoing = true;
	
	private HashMap<String, ArrayList<String>> allHistory = new HashMap<String, ArrayList<String>>();
	private static String recMsgAdded = "";
	private ArrayList<String> clientsOnline = new ArrayList<String>();

	public static void main(String[] args) {
		try {
			System.out.println("enter main in ChatterClient");
			clientGUI = new ClientGUI("141.161.88.4", 55305);
			
			boolean keepGoing = true;
	
			int publicPort = 55305;
			String ip = "141.161.88.4";
			String username = "ALPHA";
			ChatterClient client = new ChatterClient(ip, publicPort, username);
			

			while(keepGoing) {

				if (!recMsgAdded.isEmpty()) {
					String msg = recMsgAdded;
					if (msg != null) {
						System.out.println("about to write: " + msg);
						client.bout.write(msg + '\n');
						client.bout.flush();
					}
				}
			}
			
			client.disconnect();
		}
		catch(IOException ioe) {
			System.err.println("Caught in main: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	public ChatterClient(String server, int port, String username) {
		this(server, port, username, null);
	}

	public ChatterClient(String server, int port, String username, ClientGUI clientGUI) {
		System.out.println("chat client starting ...");
		keepGoing = true; 
		
		setIPAddress(server);
		setPortNumber(port);
		setUsername(username);
		setClientGUI(clientGUI);
		
		try
		{
			System.out.println("about to try to call 'localhost' / " + publicPort);

			sock = new Socket("localhost", publicPort);

			InputStream in = sock.getInputStream();
			bin = new BufferedReader( new InputStreamReader(in) );

			OutputStream out = sock.getOutputStream();
			bout = new BufferedWriter( new OutputStreamWriter( out ) );
			bout.write(username + "\n");
			bout.flush();
			
			Thread t = new Thread(new Listen());
			t.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("caught in ChatterClient(): " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	class Listen implements Runnable {
		@Override
		public void run() {
			try {
				while (keepGoing) {
					String msg = bin.readLine();
					if (msg != null) { System.out.println("from server: " + msg); }	
				}
			}
			catch (IOException ioe) {
				System.err.println("Caught in Listen.run(): " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
	}

	/*
	 * To send a message to the server
	 */
	void sendMessage(ChatMessage msg) {
		try {
			bout.write(msg.getMessage());
		}
		catch(IOException e) {
			display("Exception writing to server: " + e);
		}
	}

	/*
	 * To send message to console or GUI
	 */
	private void display(String msg) {
		if(clientGUI == null)
			System.out.println(msg);      // println in console mode
		else
			clientGUI.append(msg);      // append to the ClientGUI JTextArea
	}

	/*
	 * When something goes wrong
	 * Close the Input/Output streams and disconnect not much to do in the catch clause
	 */
	private void disconnect() {
		try {
			if(bin != null) bin.close();;
		}
		catch(Exception e) {} // not much else I can do
		try {
			if(bout != null) bout.close();
		}
		catch(Exception e) {} // not much else I can do
		try{
			if(sock != null) sock.close();
		}
		catch(Exception e) {} // not much else I can do

		// inform the GUI
		if(clientGUI != null)
			clientGUI.connectionFailed();
	}

	public void addToHistory(String key, String msg) {
		System.out.println("in addToHistory");
		if (allHistory.isEmpty()) {
			System.out.println("in if");
			allHistory = new HashMap<String, ArrayList<String>>();
			ArrayList<String> tempKey = new ArrayList<String>();
			tempKey = allHistory.get(key);
			tempKey.add(msg);
			allHistory.put(key, tempKey);
		}
		else {
			System.out.println("in else");
			allHistory.get(key).add(msg);
		}
		System.out.println("after all statements before assignemnt");
		recMsgAdded = msg;
	}

	public HashMap<String, ArrayList<String>> getAllHistoryList() {
		return allHistory;
	}
	
	/*
	 * setter methods
	 */
	public void setPortNumber(int portNum) {
		publicPort = portNum;
	}
	
	public void setIPAddress(String ip) {
		this.ip = ip;
	}
	
	public void setUsername(String nickname) {
		username = nickname;
	}

	private void setClientGUI(ClientGUI clientGUI) {
		this.clientGUI = clientGUI;
	}
}