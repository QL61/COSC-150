package chatter;

import java.io.*;
import java.util.Scanner;

public class ChatterMessage {
	
	static final int PUBLIC_MESSAGE = 0;
	static final int PRIVATE_MESSAGE = 1;
	
	private String message;
	private int messageType;
	private String sender;
	
	// Default constructor
	ChatterMessage() {
		this.message = "";
		this.messageType = PUBLIC_MESSAGE;
		this.sender = "";
	}
	
	// Constructor with parameters
	ChatterMessage(int type, String s) {
		setMessage();
		setMessageType(type);
		this.sender = s;
	}
	
	void setMessageType( int type ) {
		if ( type == 0 ) {
			messageType = PUBLIC_MESSAGE;
		}
		else {
			messageType = PRIVATE_MESSAGE;
		}
	}
	
	void setMessage() {
		
	    Scanner scanner = new Scanner(System.in);
	    
	    String readString = scanner.nextLine();
	    
	    while(readString!=null) {
	    	
	    		message += readString;

	    	    readString = null;
            scanner.close();

	    }
	    
	}
	
	int getMessageType() {
		return messageType;
	}
	
	String getMessage() {
		return message;
	}
	
	String getSender() {
		return sender;
	}
	

} // END ChatMessage class
