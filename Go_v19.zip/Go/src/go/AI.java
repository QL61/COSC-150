package go;

/**
 * AI.java
 */

//AI Class

/**
 * AI implements the AI and Alpha-Beta algorithms to play GameBoard
 * It creates a GomokuStrategy array
 * GS[1] evaluates the best move
 * GS[2] evaluates the following move if the move is made as per GS[1]
 * GS[3] evaluates the following move if the move is made as per GS[2] 
 * GS[i] evaluates the following move if the move is made as per GS[i-1] 
 */
public class AI  {
	
	// Added constants MARK
	static final int PLAYER_B = 1;       //piece PLAYER_B
    static final int FREE = 3;          //a free place on the board
	static final int INFINIT = 999999;
	
	
    private GomokuStrategy[] GS;    //think depth +1 GomokuStrategy structures are needed
    private int TD;             //actual think level
    private boolean foundBest=false; //found a move where the player wins?
    
    /** 
     * Creates a new instance of AI
     * @param e    initial GomokuStrategy structure
     */
    public AI(final GomokuStrategy e) {
        //array of Evaluations for the next potential game states ("think levels")
        GS = new GomokuStrategy[e.maxTD+1];    	
        for (int i=0; i<GS.length;i++) {
            GS[i] = new GomokuStrategy(e);
            //set the correct player on each think level
            if (i>0) GS[i].TDPlayer = (int)((GS[i-1].TDPlayer + 1) % 2);
        }
        TD = 0;
    }
    
    
	
	
    
        
    
    /**
     * calculates the AI and alpha-beta algorithms 
     * @return  best position for the next move
     */
    public PlayerPosition getNextMove() {
        // if this is the first move, than give back a middle position
        if (GS[TD].board.getStatus() == FREE) {
            return new PlayerPosition(7,7);
        }
        for (int i=0; i<GS[TD].free.size() ; i++){
            // calculate for all valid free position
            GS[TD].move = ((PlayerPosition) GS[TD].free.get(i));
            calcMoveValue(); //recursion - calculate the next think level
            // returned value (of the next think level) is the value for this move
            GS[TD].free.setIndex(GS[TD].move.pairingVal(), GS[TD+1].value);
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>1000) foundBest=true;
            if ( GS[TD].TDPlayer == PLAYER_B ) {
                if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
            } else {
                if ( GS[TD+1].value < GS[TD].beta ) GS[TD].beta = GS[TD+1].value;
            }
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>1000) foundBest=true;
        }
        
        PlayerPosition nextPlayerPosition = new PlayerPosition();
        nextPlayerPosition = GS[TD].free.MaxMin(GS[TD].TDPlayer); //best move
        
        //Send the move message to the server via GoClient
        //placeMove(nextPlayerPosition.getRow(), nextPlayerPosition.getColumn());
        
        //Update the game board on this client
        return nextPlayerPosition;
    }
    
    /**
     * calculates the AI and alpha-beta algorithms for think depth > 0
     */
    private void calcMoveValue() {
        TD++;
        GS[TD].copyEvaluation(GS[TD-1]); //Initialize GS
        GS[TD].free.remove(GS[TD].move); //remove actual move from free list
        GS[TD].setPiece(); //set actual move into the board
        if (TD < GS[TD].maxTD) {
            for (int i=0; i<GS[TD].free.size() ; i++){
                // calculate for all valid free position
                GS[TD].move = ((PlayerPosition) GS[TD].free.get(i));
                calcMoveValue(); //recursion - calculate the next think level
                if ( GS[TD].TDPlayer == PLAYER_B ) {
                    if ( GS[TD+1].value > GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
                } else {
                    if ( GS[TD+1].value < GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value < GS[TD].beta ) GS[TD].beta = GS[TD+1].value;
                }
                if ( GS[TD].beta < GS[TD].alpha ) {
                    break;
                }
            }
        }
        if ( GS[TD].intValue!=INFINIT && GS[TD].intValue!=-INFINIT) {
            GS[TD].value = GS[TD].intValue;
        }
        TD--;
    }
    
    /**
     * Calculates with think depth = 1 and give back a sorted array with the
     * best positions to the next move
     * @return  array with the best positions for the next move
     */
    public int[] getFreeSorted() {
        getNextMove();
        return GS[0].free.getFreeSorted(GS[0].TDPlayer);
    }
    
    /**
     * Displays values of some given positions.
     * This method is only for tests
     * @param   positions list to be checked
     * @return  to standard output the wanted values
     */
    public String valuesOf(final PlayerPosition[] p) {
        String ret = "";
        for (int i=0; i<p.length; i++)
            ret += p[i]+"\t"+GS[0].free.valueOf(p[i])+"\n";
        return ret;
    }
}
