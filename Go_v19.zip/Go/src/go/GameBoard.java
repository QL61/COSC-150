package go;

import java.util.Arrays;

import javax.swing.JPanel;

/**
 * GameBoard.java
 */
														//////////////////////////////////////client sends incorrect stone color to server

// DO NOT UPDATE IT 
// AI Class


public class GameBoard extends JPanel {
	
	private static final long serialVersionUID = 1L;
	/**
     * Creates a new empty GameBoard board.
     * @param totalColumns     the board totalColumns
     * @param width     the board width
     * 
    */
     
    // Added constants MARK
	static final int PLAYER_A = 0;         //piece PLAYER_A
	static final int PLAYER_B = 1;         //piece PLAYER_B
	static final int FREE = 3;          //a free place on the board
	static final int GAMEOVER = 8;      //the game is over
    static final int VALID = 32;        //a free line on a board
    static  int[] EMPTY = {32};    //no lines are found
    static final int[] NOTEXIST = {16}; //not possible
    static final int SIZE = 15;         //size of a square board
    
    
    /**field for the board*/
    protected int[][] board; 
    /**total columns of board*/
    private int totalColumns = SIZE;
    /**total rows of board*/
    private int totalRows = SIZE;   
    
    /**Number of free spaces on the board*/
    private int freeSpaces;     
    
    
  
    public GameBoard( int totalColumns, int totalRows) {
        board = new int[totalRows+2][totalColumns+2]; //add 2 extra rows and columns to store position information
        this.totalColumns = totalColumns;
        freeSpaces = totalRows*totalColumns;  //calculate total number of freeSpaces on the board 15 x 15
        reset();

    }
    
    /**
     * Creates a new GameBoard as copy from other
     * @param g     GameBoard to be copied
     **/
    public GameBoard(  GameBoard g ) {
        //board = new int[g.totalColumns+2][g.board[0].length];
    	board = new int[g.totalRows+2][g.totalColumns+2];
        this.boardcopy(g);
    }
    
    protected void boardcopy(GameBoard b) {
        this.totalColumns = b.totalColumns;
        this.freeSpaces = b.freeSpaces;
        for ( int i=0; i<totalColumns+2 ; i++)
            System.arraycopy(b.board[i],0,board[i],0,totalColumns+2);		
	}

    
    /**
     * Create a protocol message to communicate across teams
     * @param      position where the piece is set
     * @param      true if piece color is black
     * @return     Play Message
     */

    public String generatePlayMessage( PlayerPosition p, boolean isBlack) {

	    String msg = GomokuProtocol.generatePlayMessage(isBlack, p.getRow()-1, p.getColumn()-1);  // offset row and column
	    if (GomokuProtocol.isPlayMessage(msg)) {
	        int[] detail = GomokuProtocol.getPlayDetail(msg);
	        // PLAYER_B is 1 and PLAYER_A is 0
	        System.out.println("color is " + detail[0]);
	        System.out.println("row is " + detail[1]);
	        System.out.println("col is " + detail[2]);
	    }
	    System.out.println("GameBoard line 92generatePlayMessage " + msg );
	    return msg;
    }
    
    
	/**
     * Resets the GameBoard board for a new game.
     */
  
    public void reset() {
        freeSpaces = totalRows*totalColumns;
        board[0][0] = VALID; //first cell value is set to 32        
        
        for ( int i=0; i < totalRows+2; i++)  //rows
            for ( int j=0; j < totalColumns+2; j++)  //columns
                if ( i==0 || j==0 || i==totalRows+1 || j==totalColumns+1 ) { 
                    // status frame
                    board[i][j] = VALID;    //update frame cells values
                } else {
                    // valid board positions
                    board[i][j] = FREE;
                }
        // game status
        setStatus(FREE);
    }
    
    
    /**
     * Gets the depth of this board.
     * @return  total Rows of this board.
     */ 
    protected int getTotalRows() {
        return totalRows;
	}

    
    
    /**
     * Gets the number of columns of this board.
     * @return  width of this board.
     */   
    protected int getTotalColumns() {
        return totalColumns;
	}


   
    /**
     * AI to place a stone on the game board.
     * @param      position where the stone should be placed
     * @param      stone color 1-Black, 0-White
     * @return     true if was valid the stone on the position to set
     */
    //  protected void placeAIStone( PlayerPosition p, int PLAYER_A) {
    protected void placeAIStone(PlayerPosition p,int stone) {

    	int xCoordinate = p.getColumn();    //Column position of p
    	int yCoordinate = p.getRow();    //Row position of p
    	if ( xCoordinate>0 && yCoordinate>0 && xCoordinate<=totalColumns && yCoordinate<=getTotalRows() ) {
    		// set stone on the board:
    		board[xCoordinate][yCoordinate] = stone;
    		// set vertical as used:
    		board[xCoordinate][0] = (int)(board[xCoordinate][0] | 1);
            // set horizontal as used:
            board[0][yCoordinate] = (int)(board[0][yCoordinate] | 2);
            // set diagonal down as used:
            if ( yCoordinate-xCoordinate >= 0 )
                board[0][yCoordinate-xCoordinate+1] = (int)(board[0][yCoordinate-xCoordinate+1] | 4);
            else
                board[xCoordinate-yCoordinate+1][0] = (int)(board[xCoordinate-yCoordinate+1][0] | 4);
            // set DiagUp as used:
            if ( xCoordinate+yCoordinate-1 <= getTotalRows() ) 
                board[0][xCoordinate+yCoordinate-1] = (int)(board[0][xCoordinate+yCoordinate-1] | 8);
            else
                board[xCoordinate+yCoordinate-getTotalRows()][0] = (int)(board[xCoordinate+yCoordinate-getTotalRows()][0] | 8);
            // reduce the number of free freeSpaces:
            freeSpaces--;
        }
        boolean isBlack ;
        if (stone == 1) isBlack = true;
        else isBlack = false;
        System.out.println("GameBoard::placeAIStone() : isBlack is " + isBlack);
        generatePlayMessage(p,isBlack);						//////////////////////////////////////client sends incorrect stone color to server
        setStatus((int)1);
    }
 
    
    											/////////////////////////////////////////////////////only works with ai v ai, should work with pvp
    /**
     * Checks the GameBoard rules to prove if a move is valid.
     * @param      position where the stone should be set
     * @param      stone color
     * @return     true if it is a valid move.
     */
    public boolean setPiece( PlayerPosition p, int piece) {
        if (p==null) return false; //error on the move generator!!
        int x = p.getColumn();
        int y = p.getRow();
        boolean ok = true;
        /**
         * Piece can not be set on the border or outside the board.
         */
        if ( x > getTotalColumns() ) return false;
        if ( y > getTotalRows() ) return false;
        if ( x < 1 ) return false;
        if ( y < 1 ) return false;
        /**
         * At the first move can the player a white piece on each position into
         * the board (Not into the border!)
         */
        if ( getStatus() == FREE ) {  //&& piece == PLAYER_A
            setStatus(piece);
            ok = performSetPiece(p,piece);
            return ok;
        }
        /**
         * Piece can only be put on a free position into the board.
         */
        if ( board[x][y] != FREE ) return false;

        /**
         * The game is over when on a column, row or a diagonal five 
         * pieces from one color form a sequence without interruption. The
         * player with the corresponding color wins.
         */
        int count, countOp;
        for (int dx=-1; dx < 2; dx++)
            for (int dy=-1; dy < 1; dy++) {
                count = countOp = 1;
                if ( dy!=0 || dx==-1 ) {
                    while ( board[x+count*dx][y+count*dy] == piece ) count++;
                    while ( board[x-countOp*dx][y-countOp*dy] == piece ) countOp++;
                    countOp--;
                }
                if ( count + countOp >= 5 ) {
                    markWinner(x,y,dx,dy,piece);
                    piece += 4;
                }
            }
        if (ok) {
            ok = performSetPiece(p,piece);
            if (getStatus() < FREE) setStatus(piece);
            if (getFreeSpaces()==0) setStatus(GAMEOVER); //game ending without winner
        }
        boolean isBlack ;
        if (piece == 1) { isBlack = true;} else {isBlack = false;}
        generatePlayMessage(p,isBlack);
        return ok;
    }
    
    
    
    /**
     * Gets the number of free freeSpaces of this board.
     * @return  Number of free spaces.
     */
    protected int getFreeSpaces() {
        return freeSpaces;
    }

	/**
     * Sets a piece on the GomokuBoard
     * @param   position p where to set the piece
     * @param   piece to set
     * @return  true if the piece could be set
     */
    protected boolean performSetPiece(PlayerPosition p, int piece) {
    	System.out.println("in GameBoard class performSetPiece method piece is the player A or B definition: "+piece);
        boolean ret = false;       //return value
         int col = p.getColumn();    //Column position of p
         int row = p.getRow();    //Row position of p
        if ( col>0 && row>0 && col<=totalColumns && row<=getTotalRows() ) {
            // set piece on the board:
            board[col][row] = piece;
            // set vertical as used:
            board[col][0] = (int)(board[col][0] | 1);
            // set horizontal as used:
            board[0][row] = (int)(board[0][row] | 2);
            // set diagonal down as used:
            if ( row-col >= 0 )
                board[0][row-col+1] = (int)(board[0][row-col+1] | 4);
            else
                board[col-row+1][0] = (int)(board[col-row+1][0] | 4);
            // set DiagUp as used:
            if ( col+row-1 <= getTotalRows() ) 
                board[0][col+row-1] = (int)(board[0][col+row-1] | 8);
            else
                board[col+row-getTotalRows()][0] = (int)(board[col+row-getTotalRows()][0] | 8);
            // reduce the number of free freeSpaces:
            freeSpaces--;
            // all was ok!
            ret = true;
        }
        return ret;
    }
    
    
    
    
     
    
    
    
    /**
     * marks the fields where the 5 pieces of the winner are
     * @param x     coordinate where the last piece of the winner is placed
     * @param y     coordinate where the last piece of the winner is placed
     * @param dx    direction where the winner pieces are
     * @param dy    direction where the winner pieces are
     * @param piece color from winner
     */
    private void markWinner( int x,  int y,  int dx,  int dy,  int piece) {
        int count=1,countOp=1;
        while ( board[x+count*dx][y+count*dy] == piece ) {
            board[x+count*dx][y+count*dy] |= 4;
            count++;
        }
        while ( board[x-countOp*dx][y-countOp*dy] == piece ) {
            board[x-countOp*dx][y-countOp*dy] |= 4;
            countOp++;
        }
        
    }
    
 
    //////////////////////////////////////////////////////////////not necessarily needed anymore because this was for same screen gameplay
    /**
     * Gets the next player.
     * @return  PLAYER_A when PLAYER_B was the last player.
     * @return  PLAYER_A when board is FREE.
     * @return  PLAYER_B when PLAYER_A was the last player.
     */
    public int getNextPlayer() {
        return (int) ( (getStatus()+1) % 2 );
    }

    /**
     * Gets the game status.
     * @return     0 = PLAYER_A was the last player
     * @return     1 = PLAYER_B was the last player
     * @return     3 = the board is yet empty
     * @return     4 = game over and PLAYER_A won
     * @return     5 = game over and PLAYER_B won
     * @return     8 = game over without winner
     * @return     9 = board accepted
     */
    public int getStatus() {
        return (int)(board[0][0]-32);  //return the first cell of the frame (32 at the beginning) to GUI.refreshboard -> refreshStatus
    }
    
    /**
     * Gets the game status.
     * @param     free to be set
     */
    private void setStatus(int free) {
        board[0][0]=(int)(free|VALID);
    }
    
    /**
     * Gets a list with all occupied positions on this board.
     * @return  array with all occupied positions on this board.
     */
    protected PlayerPosition[] getOccupList() {
        int counter=0;
        PlayerPosition[] ret;
        PlayerPosition[] retHelp = new PlayerPosition[totalColumns*getTotalRows()];
        for ( int col=1; col<=totalColumns; col++){
            // > VALID means the column exists and is not empty:
            if ( board[col][0] > VALID ) 
                for ( int row=1; row<=getTotalRows(); row++ )
                    // < FREE means the field is occupied:
                    if ( board[col][row] < FREE ) 
                        retHelp[counter++] = new PlayerPosition(col,row);  //count how many cells are full
        }
        // copy only the used freeSpaces of retHelp:
        if ( counter > 0 ) {
            ret = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,ret,0,counter);
            return ret;
        }
        // the board has no pieces:
        return null;
    }
    
    /**
     * Gets a list with free position round of position p.
     * @param   position p
     * @return  array with all free positions arround p.
     */
    protected PlayerPosition[] getFreeRound( PlayerPosition p) {
         int col = p.getColumn();   // coordinate col of p
         int row = p.getRow();   // coordinate row of p
        int i,j,counter=0;
        int[] column;      // column of board to check
        PlayerPosition[] ret;     // return value
        PlayerPosition[] retHelp = new PlayerPosition[8];   // help variable for return value  //4 PLAYER_A, 4 PLAYER_B max
        // check the values around p:
        for ( i=-1; i<2 ; i++ ) {
            if ( col+i > 0 && col+i <= totalColumns ) {
                column = board[col+i];
                for ( j=-1; j<2 ; j++ )
                    // row +j can be out of board but in this case column[y+j]!=FREE
                    if ( column[row+j]==FREE ) retHelp[counter++] = new PlayerPosition(col+i,row+j);
            }
        }
        // copy only the free freeSpaces to ret
        if ( counter > 0 ) {
            ret = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,ret,0,counter);
            return ret;
        }
        // no freeSpaces around p
        return null;
    }

    /**
     * Gets the row which contain the position p.
     * @param   PlayerPosition p
     * @return  array with the row number i.
     * @return  EMPTY if the row is empty.
     * @return  NOTEXIST if the row not exists.
     */
    protected int[] getRow( PlayerPosition p ) {
        return getRow( getRowNr(p) );
    }
    
    /**
     * Gets the row number which contain the position p.
     * @param   position p
     * @return  coordinate y of position p.
     */
    protected int getRowNr(PlayerPosition p) {
        return p.getRow();
    }
    

    /**
     * Gets the row with number i.
     * @param   row number y
     * @return  array with the row which contain the position p.
     * @return  EMPTY if the row is empty.
     * @return  NOTEXIST if the row not exists.
     */
    protected int[] getRow(  int row ) {
        int[] ret;
        if ( row > 0 | row<=getTotalRows() ) {
            // if the row is not empty
            if ( (board[0][row] & 2) > 0 ) {
                int[] help = new int[totalColumns+2];
                for ( int col=0; col < help.length; col++)
                    help[col] = board[col][row];
                ret = help;
            } else {
                ret = EMPTY;
            }
        } else {
            ret = NOTEXIST;
        }
        return ret;
    } 

    /**
     * Gets the column with number i.
     * @param   column number
     * @return  array with the column which contain the position p.
     * @return  EMPTY if the column is empty.
     * @return  NOTEXIST if the column not exists.
     */
    protected int[] getColumn( int col) {
        int[] ret;
        if ( col > 0 && col<=totalColumns ) {
            // if there are pieces on the column col
        	 if ( (Arrays.asList(board[col][0]).contains(0))  ) {
                ret = board[col];  //return the column
            } else {
                ret = EMPTY;
            }
        } else {
            ret = NOTEXIST;
        }
        return ret;
    }

    
    /**
     * Gets the column which contain the position p.
     * @param   position p
     * @return  array with the column number i.
     * @return  EMPTY if the column is empty.
     * @return  NOTEXIST if the column not exists.
     */
    protected int[] getColumn( PlayerPosition p) {
        return getColumn(getColumnNr(p));
    }
 
    /**
     * Gets the column number which contain the position p.
     * @param   position p
     * @return  coordinate col of position p.
     */
    protected int getColumnNr( PlayerPosition p) {
        return p.getColumn();
    }
    
    
    /**
     * Gets the diagonal up which contain the position p.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(totalColumns,depth)}
     * @param   position p
     * @return  array with the diagonal up which contain the position p.
     * @return  EMPTY if the diagonal is empty or has less than five cells.
     * @return  NOTEXIST if the diagonal not exists.
     */
    protected int[] getDiagUp(PlayerPosition p) {
        return getDiagUp(getDiagUpNr(p));
    }
    
    /**
     * Gets the number of the diagonal Up which contain the position p.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(totalColumns,depth)}
     * @param   position p
     * @return  diagonal Up number.
     */
    protected int getDiagUpNr( PlayerPosition p) {
        return p.getColumn()+p.getRow()-1;
    }

    /**
     * Gets the diagonal up with number c.
     * Diagonal Up means, a diagonal where the y-values are in ascending order.
     * The first diagonal Up is {(1,1)} and the last is {(totalColumns,depth)}
     * @param   DiagUp number c
     * @return  array with the diagonal up which contain the position p.
     * @return  EMPTY if the diagonal is empty or has less than five cells.
     * @return  NOTEXIST if the diagonal not exists.
     */
    protected int[] getDiagUp( int c) {
        int[] help;
        int[] ret = NOTEXIST;
        // check if c is valid:
        if ( c > 0 && c < getTotalRows()+totalColumns ) {
            if (c <= getTotalRows()) {
                 if ( (board[0][c] & 8) > 0 ) {
                    if ( c <= totalColumns ) {
                        help = new int[c+2];
                    } else {
                        help = new int[totalColumns+2];
                    }
                    for ( int i=1; i <= help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[i][c-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            } else {
                if ( (board[c-getTotalRows()+1][0] & 8) > 0 ) {
                    if ( c <= totalColumns ) {
                        help = new int[getTotalRows()+2];
                    } else {
                        help = new int[totalColumns+getTotalRows()-c+2];
                    }
                    for ( int i=1; i < help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[c-getTotalRows()+i][getTotalRows()-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            }
        }
        return ret;
    }


    
    
    /**
     * Gets the diagonal down which contain the position p.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(totalColumns,1)}
     * @param   position p
     * @return  array with the diagonal down which contain the position p.
     * @return  EMPTY if the diagonal is empty.
     * @return  NOTEXIST if the diagonal not exists or has less than five cells.
     */
    protected int[] getDiagDown( PlayerPosition p) {
        return getDiagDown(getDiagDownNr(p));
    }
    
    /**
     * Gets the number of the diagonal Down which contain the position p.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(totalColumns,1)}
     * @param   position p
     * @return  diagonal Down number.
     */
    protected int getDiagDownNr( PlayerPosition p) {
        return getTotalRows()-p.getRow()+p.getColumn();
    }

    
    /**
     * Gets the diagonal down with number c.
     * Diagonal Down means, a diagonal where the y-values are in descending order
     * The first diagonal Down is {(1,depth)} and the last is {(width,1)}
     * @param   Diagonal number c
     * @return  array with the diagonal down number c.
     * @return  EMPTY if the diagonal is empty.
     * @return  NOTEXIST if the diagonal not exists or has less than five cells.
     */
    protected int[] getDiagDown(  int c ) {
        int[] help;
        int[] ret;
        if ( c > 0 | c < getTotalRows()+totalColumns ) {
            if (c <= getTotalRows()) {
                // if there are pieces on the diagonal
                if ( (board[0][getTotalRows()-c+1] & 4) > 0 ) {
                    // create help with proper length
                    if ( c <= totalColumns ) {
                        help = new int[c+2];
                    } else {
                        help = new int[totalColumns+2];
                    }
                    for ( int col=1; col < help.length-1; col++)
                        // set help array
                        help[col] = board[col][getTotalRows()-c+col];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            } else {
                // if there are pieces on the diagonal
                if ( (board[c-getTotalRows()+1][0] & 4) > 0 ) {
                    // create help with proper length
                    if ( c <= totalColumns ) {
                        help = new int[getTotalRows()+2];
                    } else {
                        help = new int[getTotalRows()+totalColumns-c+2];
                    }
                    for ( int col=1; col < help.length-1; col++)
                        // set help array
                        help[col] = board[c-getTotalRows()+col][col];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            }
        } else {
            // c is not valid
            ret = NOTEXIST;
        }
        return ret;
    }
        
    /**
     * Gets the piece on the position p.
     * @param   position
     * @return  the piece on the position
     */
    protected int getPiece( PlayerPosition p) {
        return board[p.getColumn()][p.getRow()];
    }
    
}
