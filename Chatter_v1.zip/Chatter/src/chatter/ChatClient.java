package chatter;

import java.net.*;
import java.io.*;

public class ChatClient {
	// for I/O
	private ObjectInputStream sInput;		// to read from the socket
	private ObjectOutputStream sOutput;		// to write on the socket
	
	Socket sock;
	int publicPort = 51550;
	String username = "ALPHA";
	
	
	public static void main(String args[]) {

		new ChatClient();
		
	}
	
	public ChatClient() {
		System.out.println("chat client starting");
		
		try {
			sock = new Socket("localhost", publicPort);
			
			InputStream in = sock.getInputStream();
			BufferedReader bin = new BufferedReader (new InputStreamReader(in));
			
			OutputStream out = sock.getOutputStream();
			BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(out));
			
			bout.write(username);
			bout.flush();
		}
		catch (IOException ioe) {
			System.err.println(ioe);
		}
		catch (Exception e) {
			System.err.println("ERROR: exception '" + e + "' caught in ChatClient()");
		}
	}
	
	
	
	/*
	 * To start the dialog
	 */
	public boolean start() {
		// try to connect to the server
		try {
			sock = new Socket("localhost", publicPort);
		} 
		// if it failed not much I can so
		catch(Exception e) {
			System.out.println("Error connectiong to server:" + e);
			return false;
		}
		
		String msg = "Connection accepted " + sock.getInetAddress() + ":" + sock.getPort();
		System.out.println(msg);
	
		/* Creating both Data Stream */
		try
		{
			sInput  = new ObjectInputStream(sock.getInputStream());
			sOutput = new ObjectOutputStream(sock.getOutputStream());
		}
		catch (IOException eIO) {
			System.out.println("Exception creating new Input/output Streams: " + eIO);
			return false;
		}

		// creates the Thread to listen from the server 
//		new ListenFromServer().start();
		// Send our username to the server this is the only message that we
		// will send as a String. All other messages will be ChatMessage objects
		try
		{
			sOutput.writeObject(username);
		}
		catch (IOException eIO) {
			System.out.println("Exception doing login : " + eIO);
//			disconnect();
			return false;
		}
		// success we inform the caller that it worked
		return true;
	}
	
	
}