package go;


/**
 * PlayerPosition.java
 */



/**
 * Class to represent a board field
 */
public final class PlayerPosition  {
    private int col;
    private int row;
    
    /** 
     * Creates a new instance of PlayerPosition
     */
    public PlayerPosition() {
    }

    /** 
     * Creates a new instance of PlayerPosition
     * @param col     column coordinate for the new position
     * @param row     rcoordinate for the new position
     */
    public PlayerPosition(final int col,final int row) {
        this.col = col;    //GUI paintComponent initializes with 0,0 when game starts
        this.row = row;
    }
    
    /** 
     * Change the coordinates of a variable of type PlayerPosition
     * @param col   column  coordinate for the new position
     * @param row   row coordinate for the new position
     */
    public void setColumnRow(final int col,final int row) {
        this.col = col;
        this.row = row;
    }
    
    /** 
     * Gets the column value of this PlayerPosition
     * @return column coordinate of this position
     */
    public int getColumn() {
        return col;
    }
    
    /** 
     * Gets the row of this PlayerPosition
     * @return  row value of this position
     */
    public int getRow() {
        return row;
    }
    
    /**
     * calculates a integer value that represents this position
     * @return  integer representation of this position
     */
    protected int pairingVal() {
        return row+(col+row-2)*(col+row-1)/2;
    }
    
    /**
     * calculate and set the coordinate as is represented with h
     * @param h     integer that represent a position
     */
    protected void invPairing( final int h ) {
        int c = (int) (Math.sqrt(2*h)-0.5);
        row = (int) (h - c*(c+1)/2);
        col = c - row + 2;
    }
    
    /**
     * Checks if two positions are the same
     * This Method is only for test.
     * @param   position to be compared
     * @return  true is p is equal to this
     */
    public boolean equals ( final PlayerPosition p ) {
        return p.col==col && p.row==row;
    }
    
    /**
     * converts the position as String to be printed
     * @return  a String that represents this position
     */
    @Override
    public String toString() {
        return ""+this.pairingVal();
    }
}
