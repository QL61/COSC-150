package go;


import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import java.awt.Color;
import java.io.*;

/**
 * ChatterServer class
 * 
 * 
 * The server is responsible for establishing Socket connections with each client, receiving
 * ChatterMessage objects sent to it by clients, and processing ChatterMessages, including by
 * sending ChatterMessages to their appropriate recipients, or updating the list of client
 * usernames and sending out the updated list in the form of an SArray
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoServer
{

	private static final String WELCOME_MESSAGE = "Welcome to Chatter. Messages from other users will appear below. "
			+ "Select a username from the drop-down menu on the top right to begin a private chat with another user.\n\n";
	private static final int DEFAULT_PORT = 11732;
	private ServerSocket sock;
	private boolean keepGoing = true;
	private int publicPort;
	private ArrayList<ChatterClientThread> clientList = new ArrayList<ChatterClientThread>();
	private ArrayList<String> clientNameList = new ArrayList<String>();
	//store gameNumber, player1ThreadID, player2ThreadID,player1Stone,player2Stone, gameWinner in an array
	private int[] gameWait = {0,0};	
	private ArrayList<ServerBoard> gameList = new ArrayList<ServerBoard>();
	private static int gameIdcounter = 0;
	
	// Thread unique ID for easy disconnect & nickname updates
	private static int threadIdcounter = 1;

	// run to start server and make it ready to accept clients
	public static void main( String[] args ) //throws IOException
	{
		if (args.length >= 1) {
			int portArg = Integer.parseInt(args[0]);
			new GoServer(portArg);			
		}
		else new GoServer(DEFAULT_PORT);
	}

	// ChatterServer constructor
	public GoServer(int port)
	{
		System.out.println("chat server started...");
		try
		{
			publicPort = port; //set port to passed port number
			sock = new ServerSocket(publicPort); // open socket

			while (keepGoing)
			{	
				// listen for connections
				Socket client = sock.accept(); // this blocks until a client calls      
				System.out.println("ChatterServer >> accepts client connection ");
				ChatterClientThread threadToAdd = new ChatterClientThread(client);
				System.out.println("adding ChatterClientThread to ArrayList");
				clientList.add(threadToAdd);
				System.out.println("starting ChatterClientThread");
				threadToAdd.start();
				
				//Put the client into Game wait list and start a game if another player is waiting
				threadToAdd.pairPlayers(threadToAdd.threadID);

			}

			sock.close();
		}
		catch( Exception e ) { 
			System.err.println("Error: Caught in ChatServer(): " + e +" from ");
			e.printStackTrace();
		}      
		System.exit(0);
	}

	// thread that is created once for each new client
	class ChatterClientThread extends Thread {

		private Socket sock;
		private String username = "";

		protected ObjectInputStream oIn;
		protected ObjectOutputStream oOut;	
		protected boolean keepGoing = true;
		int threadID;		// Thread unique ID for easy disconnect & nickname updates

		ChatterClientThread(Socket s) {
			System.out.println("ClientThread constructor executing");
			sock = s;
			try {
				oOut = new ObjectOutputStream(sock.getOutputStream());
				//oOut.writeObject(new ChatterMessage("public", "SERVER >>", "all", WELCOME_MESSAGE));
				//oOut.flush();
				oIn = new ObjectInputStream(sock.getInputStream());
				//assign a unique thread ID		
				threadID = ++threadIdcounter; 
				
				

			}
			catch(IOException ioe) {
				System.err.println("Caught in ClientThread constructor: " + ioe + " from ");
				ioe.printStackTrace();
			} 
		}

		// accepts and delivers messages from associated client
		@Override
		public void run() {
			System.out.println("ClientThread running...");
			try {
				while (keepGoing) {
										
					//remove ChatterMessage for the game
					//ChatterMessage cm = (ChatterMessage) oIn.readObject();
					String msgReceived = (String) oIn.readObject();
					System.out.println(msgReceived);
					
					if (GomokuProtocol.isPlayMessage(msgReceived)) {
						int[] detail = GomokuProtocol.getPlayDetail(msgReceived);
						// black is 1 and white is 0
						boolean isBlack = false;
						if (detail[0]==1) isBlack = true;
						System.out.println("color is " + detail[0]);
						System.out.println("row is " + detail[1]);
						System.out.println("col is " + detail[2]);

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								
								//send play detail to opponent player2								
								 String msgPlay = GomokuProtocol.generatePlayMessage(sb.getPlayer1Color()==1, detail[1], detail[2]);
								 sendOut(msgPlay, sb.getPlayer2ThreadID());
								 System.out.println("GoServer line 146 generatePlayMessage to player 2 : " + msgPlay);
								
								
								//check if the last play finishes the game
								if (sb.isWinner(detail[1], detail[2], sb.getPlayer1Color())){
									//we have a winner!!!
									String msgWinner = GomokuProtocol.generateWinMessage();
									sendOut(msgWinner, sb.getPlayer1ThreadID());

									//send the lose message to the other player
									String msgLoser = GomokuProtocol.generateWinMessage();
									sendOut(msgLoser, sb.getPlayer2ThreadID());
								}
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player 2
								
								//send play detail to opponent player1 
								 String msgPlay = GomokuProtocol.generatePlayMessage(sb.getPlayer2Color()==1, detail[1], detail[2]);
								 sendOut(msgPlay, sb.getPlayer1ThreadID());
								 System.out.println("GoServer line 166 generatePlayMessage to player 1 : " + msgPlay);
								 
								 
								 
								//check if the last play finishes the game
								if (sb.isWinner(detail[1], detail[2], sb.getPlayer2Color())){
									//we have a winner!!!
									String msgWinner = GomokuProtocol.generateWinMessage();
									sendOut(msgWinner, sb.getPlayer2ThreadID());

									//send the lose message to the other player
									String msgLoser = GomokuProtocol.generateWinMessage();
									sendOut(msgLoser, sb.getPlayer1ThreadID());
								}
							}
						} // close for loop 
					} //close if 
			        
					else if (GomokuProtocol.isChatMessage(msgReceived)) {
						String[] detail = GomokuProtocol.getChatDetail(msgReceived);
						System.out.println("sender is " + detail[0]);
						System.out.println("chat message is " + detail[1]);

						//check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								//relay message to player 2
								sendOut(msgReceived, sb.getPlayer2ThreadID());
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player2
								//relay message to player 1
								sendOut(msgReceived, sb.getPlayer1ThreadID());
							}
						}
					}  
				

			        else if (GomokuProtocol.isChangeNameMessage(msgReceived)) {
			            String[] detail = GomokuProtocol.getChangeNameDetail(msgReceived);
			            System.out.println("old name is " + detail[0]);
			            System.out.println("new name is " + detail[1]);
			            changeName(detail[1]);
			        }
			        
			        else if (GomokuProtocol.isGiveupMessage(msgReceived)) {
			            System.out.println("Give up message " + msgReceived );
			            
			          //check which game player is in
						for (int i = 0; i < gameList.size(); i++) {
							ServerBoard sb = gameList.get(i);	
							//find the gameID
							//find the gameID
							if (sb.getPlayer1ThreadID() == threadID ){
								//player is in this game as player1
								//player 1 is a winner as player 2 gives up
								String msgWinner = GomokuProtocol.generateWinMessage();
								sendOut(msgWinner, sb.getPlayer1ThreadID());

								//send the lose message to the other player
								String msgLoser = GomokuProtocol.generateWinMessage();
								sendOut(msgLoser, sb.getPlayer2ThreadID());
							}
							else if (sb.getPlayer2ThreadID() == threadID ){
								//player is in this game as player2
								//player 2 is a winner as player 1 gives up
								String msgWinner = GomokuProtocol.generateWinMessage();
								sendOut(msgWinner, sb.getPlayer2ThreadID());

								//send the lose message to the other player
								String msgLoser = GomokuProtocol.generateWinMessage();
								sendOut(msgLoser, sb.getPlayer1ThreadID());
							}
						}
			            
			        }
			        
			        else if (GomokuProtocol.isResetMessage(msgReceived)) {
			            System.out.println("Reset message " + msgReceived );

			        }
			        
			        


					// exit thread
					// If client exits, terminate the thread
			        /*
					else if (cm.getMessageType().equalsIgnoreCase(ChatterMessage.EXIT)) {
						//Create a notification message for the log off event
						ChatterMessage cmExit = new ChatterMessage("public", "SERVER >>", "", username + " left the chat\n\n");
						sendOut(cmExit);
						keepGoing = false;
						break;
					}
					*/
					//else { sendOut(cm); }
				}

				//exit thread
				disconnectClient(threadID);
				disconnectThread();		
			}

			catch (IOException ioe) {
				System.err.println("Error: Caught in ClientThread.run: " + ioe + " from ");
				ioe.printStackTrace();
			} catch (ClassNotFoundException cnfe) {
				System.err.println("Error: Caught in ClientThread.run: " + cnfe + " from ");
				cnfe.printStackTrace();
			}
		}

		// creates message indicating that user wants to change name
		private void changeName(String newName) {
			//System.out.println("\tchanging username");

			boolean nameFound = false;
			if (!clientNameList.isEmpty()) {

				for (int i = 0; (i < clientNameList.size()) && (!nameFound); i++) {
					String nameInList = clientNameList.get(i);
					nameInList.trim();
					//System.out.println(nameInList  + " is the name in list currently"); 

					if (nameInList.equals(username.trim())) {
						clientNameList.set(i, newName);	
						nameFound = true;
						//System.out.println(clientNameList.get(i)  + " is the new name that has been set"); 
					}
				}
				if (!nameFound) {
					clientNameList.add(newName);					
				}
			}
			else if (clientNameList.isEmpty()) {
				//System.out.println("client list is empty in server");
				clientNameList.add(newName);
			}
			this.username = newName;
			updateUserNameList();
		}

		// if a client changes its name, this is called to update the list of client names

		private void updateUserNameList() {
			try {
				for (int i = 0; i < clientList.size(); i++) {
					//System.out.println("\tsending to " + clientList.get(i).username);
					ChatterClientThread ccThread = clientList.get(i);
					String toSend = ccThread.username;
					ccThread.oOut.writeObject(toSend); 	// Demeter violation, but using	
					ccThread.oOut.flush(); 					// fairly dependable objects
				}
			}
			catch(IOException ioe) {
				System.err.println("Error: Caught: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}

		// exit
		// remove chatter client thread upon user exits
		private synchronized void disconnectClient(int threadID) {
			// update 
			for(int i = 0; i < clientList.size(); ++i) {
				ChatterClientThread ct = clientList.get(i);
				// check to see if client thread matches the passed thread id
				if(ct.threadID == threadID) {
					clientList.remove(i);	
					//remove the name from the client name list
					String nameToRemove = this.username;  			
					int indexToRemove = clientNameList.indexOf(nameToRemove);
					if ( indexToRemove != -1){
						clientNameList.remove(indexToRemove);
						//System.out.println("removed: " + nameToRemove);
					}		
					//Update the Name List in all active threads

					updateUserNameList(); 						
					return;
				}
			}
		}

		// try to disconnect the thread
		private void disconnectThread() {
			// try to close the connection
			try {
				if(oOut != null) oOut.close();
			}
			catch(Exception e) {}
			try {
				if(oIn != null) oIn.close();
			}
			catch(Exception e) {};
			try {
				if(sock != null) sock.close();
			}
			catch (Exception e) {}
		}

		//sends out message to the clients
	/*	
		private synchronized void sendOut(ChatterMessage cm) {
			try {
				//System.out.println("sending out a message: '" + cm.getMessage() + "'");
				if (cm.getMessageType().equalsIgnoreCase("public")) {
					//System.out.println("\tdetermined that message is public");
					for (int i = 0; i < clientList.size(); i++) {
						//System.out.println("\tsending to " + clientList.get(i).username);
						ChatterClientThread ccThread = clientList.get(i);
						ccThread.oOut.writeObject(cm); // Demeter violation, but using
						ccThread.oOut.flush(); 		// fairly dependable objects
					}
				}
				else {
					//System.out.println("\tdetermined that message is private");
					for (int i = 0; i < clientList.size(); i++) {
						if ((clientList.get(i).username.equals(cm.getRecipient()))
								|| (clientList.get(i).username.equals(cm.getSender()))) {
							//System.out.println("\tsending to " + clientList.get(i).username);
							ChatterClientThread ccThread = clientList.get(i);
							ccThread.oOut.writeObject(cm); // Demeter violation, but using
							ccThread.oOut.flush(); 		// fairly dependable objects
						}
					}
				}
			}
			catch(IOException ioe) {
				System.err.println("Error: Caught in ClientThread.run(): " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
	*/
	
		public void pairPlayers(int cc1) {
			if (gameWait[0] == 0){
				//put the client in waiting queue
				gameWait[0] = cc1;

			} else if (gameWait[1] == 0){
				//player matches with the waiting player
				gameWait[1] = cc1;
				
				//randomly assign stone color to 2 players
				assignStoneColor(gameWait[0], gameWait[1]);			
				
				//reset the waiting queue			
				gameWait[0] =0;
				gameWait[1] =0;
				
			}
		}
		public void assignStoneColor(int cc1, int cc2) {
			int blackColor = 1;
			int whiteColor = 0 ;
			int randNum = ThreadLocalRandom.current().nextInt(0, 100);	//get random integer between 0 and 100 (inclusive)
			System.out.println("random number:"+ randNum);
			if (randNum < 50) {
				//cc1 is black color
				//start a new game between players
				gameIdcounter++;
				ServerBoard sb = new ServerBoard(gameIdcounter, cc1, blackColor,  cc2, whiteColor ); 
				System.out.println("colors: p1 color" + sb.getPlayer1Color()+ "p2 color: "+ sb.getPlayer2Color());
				
				gameList.add(sb);
				
				//send MESSAGE_SET_BLACK to cc1				
				String msgB = GomokuProtocol.generateSetBlackColorMessage();
				sendOut(msgB, cc1);
				System.out.println("GoServer line 433 assignStoneColor to cc1: " + msgB);
				
				
				//send MESSAGE_SET_WHITE to cc2				
				String msgW = GomokuProtocol.generateSetWhiteColorMessage();
				sendOut(msgW, cc2);
				System.out.println("GoServer line 441 assignStoneColor to cc2: " + msgW);
				
				
			} else {
				//cc2 is black color
				//start a new game between players
				gameIdcounter++;
				ServerBoard sb = new ServerBoard(gameIdcounter, cc2, blackColor,  cc1, whiteColor );  
				System.out.println("colors: p1 color" + sb.getPlayer1Color()+ "p2 color: "+ sb.getPlayer2Color());
				
				gameList.add(sb);
				
				//send MESSAGE_SET_BLACK to cc2
				String msgB = GomokuProtocol.generateSetBlackColorMessage();
				sendOut(msgB, cc2);
				System.out.println("GoServer line 454 assignStoneColor to cc2: " + msgB);

				
				//send MESSAGE_SET_WHITE to cc1
				String msgW = GomokuProtocol.generateSetWhiteColorMessage();
				System.out.println("GoServer line 459 assignStoneColor to cc1: " + msgW);
				sendOut(msgW, cc1);
				

			}
		}
		
		
		
		private synchronized void sendOut(String msg, int threadID) {
			try {
				System.out.println("sending out a message: '" + msg + "' threadID: " + threadID );

				System.out.println("sendOut" + msg);
				for (int i = 0; i < clientList.size(); i++) {
					if (clientList.get(i).threadID == threadID){
						System.out.println("\tsending to " + clientList.get(i).threadID);
						ChatterClientThread ccThread = clientList.get(i);
						ccThread.oOut.writeObject(msg); 
						ccThread.oOut.flush(); 								
					}
				}
			}
			catch(IOException ioe) {
				System.err.println("Error: Caught in ClientThread.run(): " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
		

	}
	
	

}  //END GoServer class