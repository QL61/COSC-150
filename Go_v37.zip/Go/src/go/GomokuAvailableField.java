package go;
/**
 * GomokuAvailableField.java
 */


import java.util.Arrays;
import java.util.LinkedList;

//AI Class

/**
 * List of available fields
 */
public class GomokuAvailableField extends LinkedList {

	// Added constants MARK
	static final int PLAYER_A = 0;         //piece PLAYER_A
	static final int PLAYER_B = 1;         //piece PLAYER_B
	static final int UNOCCUPIED = -999999;
	static final int OCCUPIED = 999999;
	
	private static final long serialVersionUID = 1L;
    private int[] index;
    private int player;
    
    /** 
     * Creates a new instance of GomokuAvailableField 
     * @param width     board width
     * @param depth     board depth
     */
    public GomokuAvailableField(int width, int depth) {
        super();
        index = new int[positionValue(new PlayerPosition(width,depth))+1];
        Arrays.fill(index,UNOCCUPIED);
    }
    
    /**
     * constructor
     */
    public GomokuAvailableField(GomokuAvailableField ls) {
        super();
        int i;
        index = new int[ls.index.length];
        System.arraycopy(ls.index,0,index,0,index.length);
        for ( i=0 ; i<ls.size() ; i++) {
        	super.addLast(ls.get(i));
        }
    }
    
    /**
     * constructor
     */
    public GomokuAvailableField( int[] ls, int width, int depth) {
        super();
        index = new int[positionValue(new PlayerPosition(width,depth))+1];
        Arrays.fill(index,UNOCCUPIED);
        for ( int i=0 ; i<ls.length ; i++) addLast(positionAddress(ls[i]));
    }
    
	//set player
    protected void setPlayer(int p){
		player=p;
	}
	
    
    /**
     * Sort available fields in ascending order 
     */
    protected int[] getAscendOrder( int player) {
        int i,j,k=0;
        int[] hlp = new int[this.size()]; //stores the position's values
        int[] sortedPositions = new int[this.size()]; //stores the ordered positions
        for ( i=0, j=0; i<index.length; i++ )
            if ( index[i] != UNOCCUPIED  && index[i] != OCCUPIED) {
                //all calculated values 
                hlp[j++] = index[i];
            }
        Arrays.sort(hlp); //position's values are sorted in ascending order
        for ( i=0; i<index.length ; i++ ) {
            if ( index[i] != UNOCCUPIED && index[i] != OCCUPIED ) {
                j=Arrays.binarySearch(hlp, index[i]); //search into help where is the value index[i]
                if( player == PLAYER_A ) {
                    if ( sortedPositions[j] != 0 ) {
                        k=j;
                        while ( j>=0 && hlp[j] == index[i] && sortedPositions[j] != 0) {
                            j--;
                        }
                        if ( ! (j>=0 && hlp[j] == index[i] && sortedPositions[j] == 0)) {
                            j=k;
                            while ( j<hlp.length && hlp[j] == index[i] && sortedPositions[j] != 0) {
                                j++;
                            }
                        }
                    }
                    sortedPositions[j]=i;
                } else {
                    int invJ=hlp.length-1-j;
                    if ( sortedPositions[invJ] != 0 ) {
                        k=j;
                        while ( j>=0 && hlp[j] == index[i] && sortedPositions[invJ] != 0) {
                            j--;
                            invJ++;
                        }
                        if ( ! (j>=0 && hlp[j] == index[i] && sortedPositions[invJ] == 0)) {
                            j=k;
                            invJ=hlp.length-1-j;
                            while ( j<hlp.length && hlp[j] == index[i] && sortedPositions[invJ] != 0) {
                                j++;
                                invJ--;
                            }
                        }
                    }
                    sortedPositions[invJ]=i;
                }
            }
        }
        return sortedPositions;
    }
    
//index position values
    public void setIndex(int pos,int val) {
        if ( index[pos] != UNOCCUPIED ) {
            index[pos] = val;
        } else {
            System.exit(1);
        }
    }
    
    /**
     * adds a new free position at the end of the list
     * @param   position to be inserted
     */
    @Override
    public void addLast(Object obj) {
        int pos = positionValue((PlayerPosition) obj);
        if (index[pos] == UNOCCUPIED) {
            super.addLast(obj);
            index[pos]= OCCUPIED;
        }
    }
    
//find best position
    public PlayerPosition findBestPosition() {
    	PlayerPosition retPos;
        if (! isEmpty()) {
        	retPos = (PlayerPosition) super.removeFirst();
            int pos = positionValue((PlayerPosition) retPos);
            index[pos] = UNOCCUPIED;
        } else {
        	retPos = null;
        }
        return  retPos;
    }

    //max value for AI
    //min value for opponent
    protected PlayerPosition MaxMin( int lastPlayer) {
        if ( lastPlayer == PLAYER_B ) { 
            return positionAddress(maxIndex());
        } else {
            return positionAddress(minIndex());
        }
    }
    
//Find the position with max value and returns its position
    private int maxIndex() {
        int maxValue = UNOCCUPIED;
        int count = 0;
        int i;
        for ( i=0 ; i<index.length ; i++) {
            if ( index[i] != OCCUPIED && index[i] != UNOCCUPIED ) {
                if ( index[i] > maxValue ) {
                    maxValue = index[i];
                    count = 1;
                } else {
                    if ( index[i] == maxValue ) count++;
                }
            }
        }
        if ( maxValue > -100000 ) {
            if ( count > 1) {
                count = 1 + (int) ( Math.random()*count );
            }
            for ( i=0 ; count > 0 ; i++)
                if (index[i] == maxValue ) count--;
            return i-1;
        } else {
            return 0;
        }
    }


    // Find the position with min value and return its position
    private int minIndex() {
        int minValue = OCCUPIED;
        int count = 0;
        int i;
        for ( i=0 ; i<index.length ; i++) {
            if ( index[i] != OCCUPIED && index[i] != UNOCCUPIED ) {
                if ( index[i] < minValue ) {
                    minValue = index[i];
                    count = 1;
                } else {
                    if ( index[i] == minValue ) {
                        count++;
                    }
                }
            }
        }
        if ( minValue < 100000 ) {
            if ( count > 1) {
                count = 1 + (int) ( Math.random()*count );
            }
            for ( i=0 ; count > 0 ; i++)
                if ( index[i] == minValue ) count--;
            return i-1;
        } else {
        	return 0;
        }
    }

    /**
     * converts a position p into a intger value thats represents
     * @param p     a position to convert
     * @return      a integer representation of p
     */
    protected int positionValue( PlayerPosition p ) {
        return p.positionValue();
    }
    
    /**
     * converts a integer pos into a position
     * @param pos   a integer to convert
     * @return      a position represented for pos
     */
    protected PlayerPosition positionAddress( int pos ) {
        PlayerPosition p = new PlayerPosition();
        p.positionAddress(pos);
        return p;
    }
    
    /**
     * Returns the value of a certain position. 
     * This methode is only for tests
     * @param   position to be checked
     * @return  the value of move into p
     */
    protected int valueOf( PlayerPosition p ) {
        return index[positionValue(p)];
    }
}
