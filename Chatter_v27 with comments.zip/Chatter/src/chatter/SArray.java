package chatter;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * SArray class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 * 
 * This is one of two object classes that travel along the input and output streams of the
 * sockets between server and clients. This is a serializable version of the ArrayList, and is
 * used by the server to deliver updated version of the list of client usernames to each client
 * when there has been a username change, when a user leaves the chat, or when a new user joins
 * the chat.
 * 
 */
public class SArray implements Serializable {
	private static final long serialVersionUID = 1L;
	private ArrayList<String> al = new ArrayList<String>();
	
	public SArray() { al = new ArrayList<String>(); }
	public SArray(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
	public ArrayList<String> getAL() { return al; }
	public void setAL(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
}
