/****************************************************************************
 * Name: Qingyue Li															*
 * NetID: QL61																*
 * Class: COSC 150, Fall 2017												*
 * Project: HW3 - Paint														*
/****************************************************************************/

// stores a single 2-tuple
public class Coordinates {
	
	// FIELDS
	public int x, y;
	
	// CONSTRUCTOR
	public Coordinates(int xval, int yval) {
		this.x = xval;
		this.y = yval;
	}
}
