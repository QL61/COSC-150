import java.io.*;

public class ChatterMessage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final int PUBLIC_MESSAGE = 0;
	static final int PRIVATE_MESSAGE = 1;
	
	private String message;
	private int messageType;
	private String sender;
	private String recipient;
	
	// Default constructor
	ChatterMessage() {
		this.message = "";
		this.messageType = PUBLIC_MESSAGE;
		this.sender = "";
		this.recipient = "";
	}
	
	// Constructor with parameters
	ChatterMessage(int type, String s, String r) {
		setMessage();
		setMessageType(type);
		this.sender = s;
		this.recipient = r;
	}
	
	void setMessageType( int type ) {
		if ( type == 0 ) {
			messageType = PUBLIC_MESSAGE;
		}
		else {
			messageType = PRIVATE_MESSAGE;
		}
	}
	
	void setMessage() {
		
		InputStreamReader isr = new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(isr);
	    
	    String msg = "";
	    
		try {
			msg = br.readLine();
			message += msg;
			
			isr.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	    
	}
	
	int getMessageType() {
		return messageType;
	}
	
	String getMessage() {
		return message;
	}
	
	String getSender() {
		return sender;
	}
	
	String getRecipient() {
		return recipient;
	}
	

} // END ChatMessage class
