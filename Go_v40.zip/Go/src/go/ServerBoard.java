package go;

/**
 * ServerBoard Class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 * 
 */
public class ServerBoard  {

     
    static final int SIZE = 15;         //size of a square board
	static final int FREE = 3;          //a free place on the board
    private int[][] board;    //game board to track the play between two players    
    private boolean gameWinner = false; // game has a winner
    private int gameID = 0;       //server generated unique ID for a game   
    private int player1TID = 0;   		//ThreadID of the first player
    private boolean player1Reset = false;  //player 1 sends reset req
    private int p1Color = 0;       //stone color of the first player
    private int player2TID = 0;			//ThreadID of the second player
    private int p2Color = 0;       //stone color of the second player
    private boolean player2Reset = false;  //player 2 sends reset req  
    
    /**
     * ServerBoard keeps track of the games between two players on the server.
     * @param gameNumber     server generated unique ID for a game 
     * @param player1ThreadID     ThreadID of the first player
     * @param player1Color     stone color of the first player
     * @param player2ThreadID     ThreadID of the second player
     * @param player2Color     stone color of the second player
     * 
    */
    
    public ServerBoard(int gameNumber, int player1ThreadID, int player1Color,  int player2ThreadID, int player2Color ) {
        board = new int[SIZE][SIZE]; 
        gameID = gameNumber;
        player1TID = player1ThreadID;
        p1Color = player1Color;
        player2TID = player2ThreadID;
        p2Color = player2Color; 
        for(int i = 0; i<SIZE; i++) {
            for(int j = 0; j<SIZE; j++) {
            	board[i][j] = FREE; 	
            }       	
        }
    }
    
    public void resetServerBoard() {
        for(int i = 0; i<SIZE; i++) {
            for(int j = 0; j<SIZE; j++) {
            	board[i][j] = FREE; 	
            }       	
        }
        setPlayer1Reset(false);
        setPlayer2Reset(false);
    }
    
    
    /**
     * isWinner is based on the last played stone and checking the surrounding stones in all directions
     * it assumes that the board Array on the server is updated every time a stone is placed.
     * @param stoneLastPlayedRow     server generated unique ID for a game 
     * @param stoneLastPlayedColumn     ThreadID of the first player
     * @param stoneColor     stone color of the last player
     * @return true     if the last play wins the game
     * 
    */
    protected boolean isWinner(int stoneLastPlayedRow, int stoneLastPlayedColumn, int stoneColor){
    	//update the game board with the last move
    	setBoard(stoneLastPlayedRow, stoneLastPlayedColumn, stoneColor);
    	

    	System.out.println("in serverBoard class isWinner method- after setting last stone to board - color, row, column  " + stoneColor + stoneLastPlayedRow + stoneLastPlayedColumn);
    	
    	//get color, row, and column of stone
    	int stoneLastPlayedColor = stoneColor;
    	int lastRow= stoneLastPlayedRow;
    	int lastColumn = stoneLastPlayedColumn;    	

    	//set stone color comparison variable
    	//necessary in while loop logic
    	 int stoneCurrent = -1;

    	//set stone and row and column counters
    	 int winStoneCount = 0;  
    	 int i = 0;
    	 int j = 0;

    	 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// horizontal checks towards right and left of the last played stone are considered as a single overall check
    	// and that is why winStoneCount initialized to 1 ONLY at the beginning of 2 checks.
    	// Also, winStoneCount is 1 because the last played stone is considered as the first winning stone in the winning pattern
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------

    	 //begin horizontal check towards right
    	 stoneCurrent = stoneLastPlayedColor;
    	 winStoneCount = 1;   
    	 j = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastColumn+j < 15 ) {
    		 //board[] in the server is where we keep played stone colors as 0 and 1
    		 if (board[lastRow][lastColumn+j] == stoneLastPlayedColor){
    			 winStoneCount++;  
    		 }
    		 stoneCurrent = board[lastRow][lastColumn+j]; //take the next stone
    		 j++;
    	 }

    	 //begin horizontal check towards left
    	 stoneCurrent = stoneLastPlayedColor;
    	 j = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastColumn-j > -1) {
    		 if (board[lastRow][lastColumn-j] == stoneLastPlayedColor){
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow][lastColumn-j];
    		 j++;
    	 }

    	 if (winStoneCount == 5) {
    		 System.out.println("ServerBoard : WINNER is Delected, send server MSG to both Players and do Board Cleanup for this game");
    	
    		 gameWinner = true;
    		 return gameWinner;
    	 }    		


    	 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// vertical checks towards up and down from the last played stone are considered as a single overall check
    	// and that is why winStoneCount initialized to 1 ONLY at the beginning of 2 checks.
    	// Also, winStoneCount is 1 because the last played stone is considered as the first winning stone in the winning pattern
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------

    	 //begin vertical check downwards
    	 stoneCurrent = stoneLastPlayedColor;
    	 winStoneCount = 1;
    	 i = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastRow+i < 15 ) {
    		 if (board[lastRow+i][lastColumn] == stoneLastPlayedColor) {
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow+i][lastColumn] ;
    		 i++;
    	 }

    	 //begin vertical check upwards
    	 stoneCurrent = stoneLastPlayedColor;
    	 i = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && (lastRow-i) > -1 ) {
    		 if(board[lastRow-i][lastColumn] == stoneLastPlayedColor) {
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow-i][lastColumn] ;
    		 i++;
    	 }

    	 if (winStoneCount == 5) {
    		 System.out.println("ServerBoard : WINNER is Delected, send server MSG to both Players and do Board Cleanup for this game");
    	
    		 gameWinner = true;
    		 return gameWinner;
    	 } 



    	 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// diagonal checks right downwards and left upwards from the last played stone are considered as a single overall check
    	// and that is why winStoneCount initialized to 1 ONLY at the beginning of 2 checks.
    	// Also, winStoneCount is 1 because the last played stone is considered as the first winning stone in the winning pattern
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------

    	 //begin diagonal check right downwards

    	 stoneCurrent = stoneLastPlayedColor;
    	 winStoneCount = 1;

    	 i = 1;
    	 j = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastRow+i < 15 && lastColumn+j < 15 ) {
    		 if (board[lastRow+i][lastColumn+j] == stoneLastPlayedColor) {
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow+i][lastColumn+j] ;

    		 i++;
    		 j++;
    	 }


    	 //begin diagonal check left upwards

    	 stoneCurrent = stoneLastPlayedColor;
    	 i = 1;
    	 j = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastRow-i > -1  && lastColumn-j > -1 ) {
    		 if (board[lastRow-i][lastColumn-j] == stoneLastPlayedColor) { 
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow-i][lastColumn-j];
    		 i++;
    		 j++;
    	 }

    	 if (winStoneCount == 5) {
    		 System.out.println("ServerBoard : WINNER is Delected, send server MSG to both Players and do Board Cleanup for this game");
    	
    		 gameWinner = true;
    		 return gameWinner;
    	 } 
    	 
    	 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// diagonal checks left downwards and right upwards from the last played stone are considered as a single overall check
    	// and that is why winStoneCount initialized to 1 ONLY at the beginning of 2 checks.
    	// Also, winStoneCount is 1 because the last played stone is considered as the first winning stone in the winning pattern
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------

    	 //begin diagonal check left downwards

    	 stoneCurrent = stoneLastPlayedColor;

    	 winStoneCount = 1;

    	 i = 1;
    	 j = 1;

    	 while (stoneCurrent == stoneLastPlayedColor && winStoneCount < 6 && lastRow+i < 15 && lastColumn-j > -1 ) {
    		 if (board[lastRow+i][lastColumn-j] == stoneLastPlayedColor) {
    			 winStoneCount++;
    		 }
    		 stoneCurrent = board[lastRow+i][lastColumn-j] ;

    		 i++;
    		 j++;
    	 }


    	 //begin diagonal check right upwards
    	 stoneCurrent = stoneLastPlayedColor;

    	 i = 1;
    	 j = 1;

    	 while 
    		 (stoneCurrent == stoneLastPlayedColor  && winStoneCount < 5  && lastRow-i > -1  && lastColumn+j < 15 ) {

    		 if (board[lastRow-i][lastColumn+j] == stoneLastPlayedColor){
    			 winStoneCount++;
    		 }

    		 stoneCurrent = board[lastRow-i][lastColumn+j];
    		 i++;
    		 j++;
    	 }

    	 if (winStoneCount == 5) {
    		 System.out.println("ServerBoard : WINNER is Delected, send server MSG to both Players and do Board Cleanup for this game");
    	
    		 gameWinner = true;
    		 return gameWinner;
    	 } 
    	
    	return gameWinner;  
    }
    
    
    protected void setBoard(int stoneLastPlayedRow, int stoneLastPlayedColumn, int stoneColor){
    	//update the game board with the last move
    	board[stoneLastPlayedRow][stoneLastPlayedColumn] = stoneColor;
    }

    //get GameID
    protected int getGameID() { return gameID; }
    //get player 1 ThreadID
    protected int getPlayer1ThreadID() { return player1TID; }
    //get player 1 color
    protected int getPlayer1Color() { return p1Color; } 
    //set player 1 color
    protected void setPlayer1Color(int stoneColor) { p1Color= stoneColor; }  
    
    //get player 2 ThreadID
    protected int getPlayer2ThreadID() { return player2TID; }
    //get player 2 color
    protected int getPlayer2Color() { return p2Color; }
    //set player 2 color
    protected void setPlayer2Color(int stoneColor) { p2Color= stoneColor; }    
    //get gameWinner
    protected boolean getGameWinner() { return gameWinner; }
    //set player 2 color
    protected void setGameWinner(boolean b) { gameWinner= b; }
    
    //get reset request
    protected boolean getPlayer1Reset() { return player1Reset; }
    //set reset request
    protected void setPlayer1Reset(boolean b) { player1Reset= b; } 
    
    //get reset request
    protected boolean getPlayer2Reset() { return player2Reset; }
    //set reset request
    protected void setPlayer2Reset(boolean b) { player2Reset= b; } 
    

    
}
