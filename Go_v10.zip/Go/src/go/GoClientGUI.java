package go;


import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;



import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

/**
 * ChatterClientGUI class
 * 
 * Creates GUI for Chatter based on information it receives from ChatterClient, and also
 * acts upon ChatterClient based on user input
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoClientGUI extends JFrame implements ActionListener, KeyListener {

	private static final int HELP_FRAME_WIDTH = 300;
	private static final int HELP_FRAME_HEIGHT = 350;
	
	private static final String HELP_MSG = "Welcome to our cute user manual";
	
	//Go GUI stuff
    private int[] dim = {15,15};                        //Default board width=15 and depth=15
    int boardSize=450;
   
    private GameBoardUI pBoard;                          //Game drawer


    
    private JButton[][] goBoardSquares = new JButton[15][15];
    private JPanel goBoard;
	
	private static final long serialVersionUID = 1L;
	private static final String WELCOME_TO_CHAT = "Welcome to the Chatroom\n\n";
	private static final String TYPE_CHAT_MSG = "Type Chat Message Here \n";
	private static final String NICK_NAME_COMMAND = "Type /nick \'name\' to change nickname";
	private static final String SLASH_NICK = "/nick";
	private static final String INVALID_UN = "Invalid Username (cannot contain spaces). Try again.";
	private static final String USER_LOGON_MSG = " logged on! Say hi!\n\n";
	private static final String LOGOUT_MSG = " Logged off :(\n\n";
//	private JLabel usernameLabel;							// label for username
	private JTextField username;							// hold current username
	private JTextField tfServer, tfPort;					// write server address and port number
	private JButton loginBtn, sendBtn, exitBtn, modeBtn, resetBtn, giveUpBtn, userManBtn;				// buttons
	private JComboBox usernameList; 						// list of clients
	private JTextArea taMsgHistory;							// message history text area
	private JTextArea taMessenger;							// text box
	private int defaultPort;								// the default port number
	private String defaultIP;								// the default ip
	private GoClient client;
	
	// Constructor connection receiving a socket number
	GoClientGUI(String host, int port) {		
		//System.out.println("inside clientGUI constructor");
		
		super("Go Client");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		defaultPort = port;
		defaultIP = host;
		
		// The NorthPanel
		JPanel northPanel = new JPanel(new GridLayout(3,2)); // the server name and port number
		JPanel serverAddress = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for server address
		JPanel portNumber = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for port number
		tfServer = new JTextField(defaultIP);
		tfPort = new JTextField("" + defaultPort);
		tfPort.setHorizontalAlignment(SwingConstants.RIGHT);
		serverAddress.add(new JLabel("Server Address:  "));
		serverAddress.add(tfServer);
		portNumber.add(new JLabel("Port Number:  "));
		portNumber.add(tfPort);
		// adds Server port field to GUI
		northPanel.add(serverAddress, BorderLayout.NORTH);
		northPanel.add(portNumber, BorderLayout.NORTH);

		/////////////////////////////////////////////////////////////////new buttons
		JPanel gameBtns1 = new JPanel(new GridLayout(1, 2));
		JPanel gameBtns2 = new JPanel(new GridLayout(1, 2));
		
		modeBtn = new JButton("Mode");
		modeBtn.addActionListener(this);
		modeBtn.setEnabled(true);
		userManBtn = new JButton("User Manual");
		userManBtn.addActionListener(this);
		userManBtn.setEnabled(true);
		gameBtns1.add(modeBtn);
		gameBtns1.add(userManBtn);
		northPanel.add(gameBtns1);
		
		///////////////////////////////////////////////////////////////////end of adding some new buttons

		//username TextField
		username = new JTextField("Enter your username here");
		username.setBackground(Color.WHITE);
		northPanel.add(username, BorderLayout.SOUTH);

		
		/////////////////////////////////////////////////////////////////new buttons
		resetBtn = new JButton("Reset");
		resetBtn.addActionListener(this);
		resetBtn.setEnabled(true);
		giveUpBtn = new JButton("Give Up");
		giveUpBtn.addActionListener(this);
		giveUpBtn.setEnabled(true);
		gameBtns2.add(resetBtn);
		gameBtns2.add(giveUpBtn);
		northPanel.add(gameBtns2);
		
		///////////////////////////////////////////////////////////////////end of adding some new buttons

		
		// username list creation
		PopupMenuListener pmListener = new PopupMenuListener() {
			boolean initialized = false;
			
			@Override
			public void popupMenuCanceled(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				String[] initList = {"G r o u p"};
				if (!initialized) {
					usernameList = (JComboBox) e.getSource();
					ComboBoxModel model = new DefaultComboBoxModel(initList);
					usernameList.setModel(model);
					initialized = true;
				}
				//System.out.println("should remove " + usernameList.getItemCount() + " -1 items");

				for (int i = usernameList.getItemCount()-1; i > 0; i--) {
					//System.out.println("will remove " + usernameList.getItemAt(i));

					usernameList.removeItemAt(i);
				}
				for (int i = 0; i < client.getNameList().size(); i++) {
					//System.out.println("adding " + client.getNameList().get(i));
					usernameList.addItem(client.getNameList().get(i));
				}
			}
		};
		usernameList = new JComboBox();
		usernameList.addItem("G r o u p");
		usernameList.setSelectedItem("G r o u p");
		usernameList.addPopupMenuListener(pmListener);
		usernameList.addActionListener(this);
		usernameList.setEnabled(false);
		northPanel.add(usernameList, BorderLayout.SOUTH);
		//add to frame
		add(northPanel, BorderLayout.NORTH);

		// CenterPanel
		JPanel centerPanel = new JPanel(new GridLayout(1,2));
		
		
		/////////////////////////////go board stuff
        //goBoard = new JPanel(new GridLayout(17, 17));
        
        pBoard = new GameBoardUI();
        //pBoard.setPreferredSize(new Dimension(460,460));
        
        centerPanel.add(pBoard);
		
	    // create the chess board squares
        
        /*
        Insets buttonMargin = new Insets(0,0,0,0);
        for (int i = 0; i < goBoardSquares.length; i++) {
            for (int j = 0; j < goBoardSquares[i].length; j++) {
                JButton b = new JButton();
                b.setMargin(buttonMargin);
                b.setBackground(Color.WHITE);
                goBoardSquares[j][i] = b;
            }
        }
        */
        
		add(centerPanel, BorderLayout.CENTER);
        
		
		// fill the black non-pawn piece row
		/*
		for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
				goBoard.add(goBoardSquares[j][i]);
			}
		}
*/
		
		
		/////////////////////////////////////////////////////////////////end of board creation
		taMsgHistory = new JTextArea(WELCOME_TO_CHAT, 80, 80);
		centerPanel.add(new JScrollPane(taMsgHistory));
		taMsgHistory.setEditable(false);

		// MessengerPanel
		taMessenger = new JTextArea(TYPE_CHAT_MSG + NICK_NAME_COMMAND);
		taMessenger.setBackground(Color.WHITE);
		taMessenger.setEditable(false);
		taMessenger.addKeyListener(this);
		centerPanel.add(taMessenger);
		//add(centerPanel, BorderLayout.LINE_END);
		
		// button creation
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(this);
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		exitBtn.setEnabled(false);		// must login before being able to exit
		sendBtn = new JButton("Send");
		sendBtn.addActionListener(this);
		sendBtn.setEnabled(false);

		JPanel southPanel = new JPanel();
		southPanel.add(loginBtn);
		southPanel.add(sendBtn);
		southPanel.add(exitBtn);
		add(southPanel, BorderLayout.SOUTH);
		
		//set the word wrap of message history and Messenger
		taMessenger.setWrapStyleWord(true);
		taMessenger.setLineWrap(true);
		taMsgHistory.setWrapStyleWord(true);
		taMsgHistory.setLineWrap(true);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				exitBtn.doClick();
			}
		});
        
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//setSize(750, 500);
		pack(); //automatically change the size of the frames according to the size of components in it. 
		setVisible(true);
		taMessenger.requestFocus();
	}

	// for enter key being pressed
	//mainly used for when enter key is pressed
	public void keyPressed(KeyEvent e) {
		if(sendBtn.isEnabled()) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER){
				sendBtn.doClick();
			}
		}
	}
	
	//for the key being released
	//mainly used for when enter key is released
	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER && 
				!(taMessenger.getText().trim().equals(INVALID_UN.trim()))) {			
			taMessenger.setText("");
		}
	}
	
	/**
	 * Button or JTextField clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// check for which button is pressed
		if(e.getSource() == exitBtn) {

			//Send exit command to the server
			Map<String, String> messageInfo = new HashMap<String, String>();
			messageInfo.put("type", ChatterMessage.EXIT);
			messageInfo.put("sender", client.getClientUsername());
			messageInfo.put("recipient", client.getClientUsername());
			messageInfo.put("message",client.getClientUsername() + LOGOUT_MSG);
			client.sendMessage(new ChatterMessage(messageInfo));
			
			//disable all buttons
			sendBtn.setEnabled(false);
			exitBtn.setEnabled(false);
			loginBtn.setEnabled(false);
			taMessenger.setEditable(false);
			usernameList.setEnabled(false);
			taMsgHistory.append("Logged off. Goodbye!\n\n");  //display bye to the user
					
		}
		else if (e.getSource() == sendBtn) {
			//System.out.println("click was sendBtn:: in sendBtn:: ");
			
			String msg = taMessenger.getText();
			String messageType = "";
			String nickChangeStr = "";
			
			if (msg.contains(SLASH_NICK)) {
				nickChangeStr = msg.substring(msg.indexOf(SLASH_NICK) + SLASH_NICK.length());
			}
			if ( (msg.indexOf(SLASH_NICK) == 0) && (nickChangeStr.indexOf(" ") == 0) ) {

				//System.out.println("----" + nickChangeStr + "-----");
				nickChangeStr = nickChangeStr.trim();
				if (checkValidUsernameInput(nickChangeStr)) {
					client.setUsername(nickChangeStr);
					username.setText(nickChangeStr);
					taMessenger.setText("");
				}
				else {
					//System.out.println("invalid username put in taMessenger");
					taMessenger.setText(INVALID_UN);
				}
			}			
			else { 
				if (((String) usernameList.getSelectedItem()).equalsIgnoreCase("g r o u p")) {
					messageType = ChatterMessage.PUBLIC;
				}
				else {
					messageType = ChatterMessage.PRIVATE;
				}

				Map<String, String> messageInfo = new HashMap<String, String>();
				messageInfo.put("type", messageType);
				messageInfo.put("sender", client.getClientUsername());
				messageInfo.put("recipient", (String) usernameList.getSelectedItem());
				messageInfo.put("message", msg + "\n\n");

				if ( messageType.equals(ChatterMessage.PRIVATE) 
						&& !( client.getClientUsername().equals((String) usernameList.getSelectedItem()) ) ) {
					taMsgHistory.append(client.getClientUsername() + " to " 
							+ (String) usernameList.getSelectedItem() + ": " + msg + "\n\n");
				}

				client.sendMessage(new ChatterMessage(messageInfo));
				taMessenger.setText("");
			}
		}
		else if(e.getSource() == loginBtn) {
			//System.out.println("actionPerformed: in loginBtn");

			// connection requested
			if (checkValidUsernameInput(getUsername())) {
				String username = getUsername().trim();
				String server = tfServer.getText().trim();
				String portNumber = tfPort.getText().trim();

				// create new Client
				client = new GoClient(server, Integer.parseInt(portNumber), username, this);
				// test to start Client
				if(!client.start()) 
					return;

				if (client.getNameList() != null) {
					for (int i = 0; i < client.getNameList().size(); i++) {
						usernameList.addItem(client.getNameList().get(i));
					}
				}
//				usernameLabel.setText(NICK_NAME_COMMAND);
				usernameList.setEnabled(true);
				//enable username List
				this.username.setEditable(false);
				// disable login button
				loginBtn.setEnabled(false);
				// enable the 2 buttons
				exitBtn.setEnabled(true);
				sendBtn.setEnabled(true);
				// disable the Server and Port JTextField
				tfServer.setEditable(false);
				tfPort.setEditable(false);
				taMessenger.setEditable(true);	
				taMessenger.setFocusable(true);
				// Action listener for when the user enter a message
				taMessenger.addFocusListener(new FocusListener() {
					public void focusGained(FocusEvent e) {}
					public void focusLost(FocusEvent e) {}
				});

				
				client.sendMessage(new ChatterMessage(ChatterMessage.PUBLIC, username, 
						(String) usernameList.getSelectedItem(), username + USER_LOGON_MSG));
				
				//printChatHistory();
			}
			else {
//				usernameLabel.setText(INVALID_UN);
				this.username.setText(INVALID_UN);
			}
		}
		else if ( e.getSource() == userManBtn ) {
			//System.out.println(HELP + " selected");
			JFrame helpFrame = new JFrame("User Manual Screen");

			JTextArea helpText = new JTextArea(HELP_MSG); 
			
			helpText.setWrapStyleWord(true);
			helpFrame.add(helpText);
			helpFrame.setSize(HELP_FRAME_HEIGHT,HELP_FRAME_WIDTH);
			helpFrame.setVisible(true);
		}
		if(e.getSource() == resetBtn) {
			pBoard.reset();  //reset the board and start a new game
		}
	}

	// outputs chat messages for the given user/client
	public void printChatHistory(ChatterMessage cm) {		
		String msgSender = cm.getSender();
		String msgReceiver = cm.getRecipient();

		//public message from server
		if (cm.getMessageType().equals(ChatterMessage.PUBLIC) && (cm.getSender().equals("SERVER >>") 
				|| cm.getMessage().equals(msgSender + USER_LOGON_MSG)) ) {
			taMsgHistory.append("SERVER >> " + cm.getMessage());
		}
		//public message from client to all
		else if (cm.getMessageType().equals(ChatterMessage.PUBLIC)) {
			//System.out.println(msgSender + " is the sender of this public message");
			taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
		}
		//private method
		else if ( cm.getMessageType().equals(ChatterMessage.PRIVATE) ) {
			if ( msgReceiver.equals(client.getClientUsername()) ) {
				taMsgHistory.append(msgSender + " to " + msgReceiver + ": " + cm.getMessage());
			}
		}
	}

	//check to see if the user name entered as a param is valid
	private boolean checkValidUsernameInput(String text) {
		boolean validUN = false;
		//check to see if client exists
		if (client != null) {
			for (int i = 0; i < client.getNameList().size(); i++) {
				String nameCompare = client.getNameList().get(i);
				if (text.equals(nameCompare)) {
					validUN = true;
				}
			}
		}
		//passed user name cannot contain spaces or be empty
		if (!(validUN || text.contains(" ") || text.equals(""))) {
			validUN = true;
		}
		return validUN;
	}
	
	//get the username from the client username text field
	protected String getUsername() {
		return username.getText();
	}

	//key typed... no action required for function
	@Override
	public void keyTyped(KeyEvent e) {}
	
	
	
	
	


	
	//GameBoardUI moved
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
} // END ChatterClientGui class
