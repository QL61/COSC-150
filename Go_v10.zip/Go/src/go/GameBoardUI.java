package go;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;



/**
 * This class draw the game board
 */
public final class GameBoardUI extends JPanel {
    /**
	 * 
	 */
	static final int PLAYER_A = 0;         //piece PLAYER_A
    static final int PLAYER_B = 1;         //piece PLAYER_B
    static final int FREE = 3;          //a free place on the board
    static final String COMPSTRATEGY = "Computer ";
    static final String HUMAN = "Human";
	private static final String DEFAULT_HOST = "localhost";
    
  
    private int[] strategy = {1,1};                     //strategy[1] for PLAYER_A and strategy[1] for PLAYER_B
    //playerType = {0,1}; Human vs Computer
    // playerType = {0,0}; Human vs Human   on the same screen, NOT ON MULTIPLE CLIENT SCREENS -dont use it
    // playerType = {1,1}; Computer vs Computer
    
    private int[] playerType = {0,1};                   //kind of player 0=Human; 1=computer
    private String[] moveGenerator = {"","",""};        //variable to store the version of the move generator
    private String[] host = {DEFAULT_HOST,DEFAULT_HOST};  	//move generator for player One=PLAYER_A and Two=PLAYER_B
    private int[] port = {0,0,3000};                    //default port and port for move generator for player One=PLAYER_A and Two=PLAYER_B
    private int falseMove = 0;                          //counter for wrong moves, if falseMove>5 than brakes the game
    
    private int[] winCounter = {0,0};                   //to store the game score
    private int[] dim = {15,15};                        //Default board width=15 and depth=15
    private int player = PLAYER_A;                        //player on the turn
    
    int boardSize=450;
    
    
	private static final long serialVersionUID = 1L;
	private int cellSize=30;      //size of the representation of a game field
    private int cellSizeSmall= 4; //start point to draw a piece
    private int cellSizeBig= 21;  //size of a piece
    private int moveThread=0;   //if a move move is being calculate 1 otherwise 0
    private boolean reset = false;  //if true the board will be reseted for a new game
    private GameBoard board;       //the GameBoard board for this game
    

    /**
     * initialize the game board
     */
    public GameBoardUI() {
    	board = new GameBoard(15,15);  //Create a new game board
    	
    	// add a mouse listener to detect user's mouse clicks on the board
        addMouseListener(new MouseAdapter(){@Override
        public void mouseClicked(MouseEvent e){thisMouseClicked(e);}});
    }

    /**
     * Draws the game board
     */
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.addRenderingHints(new RenderingHints(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON)
        );
        
        this.setSize(boardSize,boardSize);  //this refers to the board , its size is 450x450, all cellSizes are populated with integer numbers of 32 and 3
        this.setPreferredSize(new Dimension(boardSize,boardSize));  //board preferred size is set to 450x450
        refreshBoard();
       
	   PlayerPosition place = new PlayerPosition(0,0);   //initialize place to (0,0) cellSize
        int x = 0, y = 0;
        while (y < boardSize){    // y less than 30 x 15 = 450  board heigth
            while ( x < boardSize ){    // x is less than 30 x 15 = 450  board width
                place.setColumnRow(1+x/cellSize,1+y/cellSize);   // dividing x by cellSize gives us how many cellSizes x moved like 1,2,3.. . Same for y.
                if (board.getPiece(place)>=4){    // board.getPiece is larger than 4 for frame cellSizes that have 35, and 32 as values
                    if (board.getPiece(place)>=8) {   //either a frame or a winning row/column has larger than 8
                        //the win fields have special color
                        g2.setColor(new Color( 0,255,127)); // Spring Green 0,255,127
                        g2.fill3DRect(x, y, cellSize, cellSize,false);
                    } else {
                        //special colors to show winning row
                         g2.setColor(new Color((float)0.2,(float)0.75,(float)0.45));
                          g2.fill3DRect(x, y, cellSize, cellSize,true);
                        }
                } else {
                    if ((board.getPiece(place)&3)!=FREE) {
                    	 //PUT GRID LINES 
                        g2.setColor(Color.BLACK);
                        g2.setStroke(new BasicStroke(3));  //Set line thickness
                        g2.drawLine(x, y+(cellSize/2), x+cellSize, y+(cellSize/2));  //draw a horizontal line in the middle of cell
                        g2.drawLine(x+(cellSize/2), y, x+(cellSize/2), y+cellSize);  //draw a vertical line in the middle of cell
                        
                        //for cellSizes which contains pieces
                    	g2.setColor(new Color(65,105,225)); //Royal Blue 65,105,225 
                        //g2.fill3DRect(x, y, cellSize, cellSize,true);  //remove the frame from selected cells
                    	
                    	
                    	
                    } else {
                        //for cellSizes which don't contains pieces
                     	//g2.setColor(Color.WHITE);  //board color
                    	g2.setColor(new Color((float)1.0,(float)1.0,(float)1.0,(float)0.0));  // white board color, 100% transparent
                        g2.fill3DRect(x, y, cellSize, cellSize,true);
                        //PUT GRID LINES 
                        g2.setColor(Color.BLACK);
                        g2.setStroke(new BasicStroke(3));  //Set line thickness
                        g2.drawLine(x, y+(cellSize/2), x+cellSize, y+(cellSize/2));  //draw a horizontal line in the middle of cell
                        g2.drawLine(x+(cellSize/2), y, x+(cellSize/2), y+cellSize);  //draw a vertical line in the middle of cell
                    }
                }
                if ((board.getPiece(place)&3)==PLAYER_B) {
                    //set the color to black
                    g2.setColor(Color.white);
				    g2.fillOval(x+cellSizeSmall, y+cellSizeSmall , cellSizeBig, cellSizeBig);
                }
                if ((board.getPiece(place)&3)==PLAYER_A) {
                    //set the color to PLAYER_A
                    g2.setColor(Color.black);
					g2.fillOval(x+cellSizeSmall, y+cellSizeSmall , cellSizeBig, cellSizeBig);
                                  
			   }
                x += cellSize;
            }
            x = 0;
            y += cellSize;
        }
    }
    
    
    
    /**
     * Starts the game with a click on the game board.
     * @param   Mouseclick from human player or null
     */
    public void thisMouseClicked(final MouseEvent e) {
        new MakeMove(e).start();
    }
    
    /**
     * starts a new game 
     */
    public void startGame() {
        new MakeMove(null).start();
    }
    
     
    
    /**
     * redraw the board. But wait a time to be sure that the time between
     * two moves is at least one second.
     */
    public void refreshBoard(){
        refreshStatus();
        refresh();
        try {
            //Always wait 1s to be sure the moves are not too 
            //quickly redraw
            Thread.sleep(500);
        } catch  ( final Exception e ) {}
    }

    /**
     * refresh the status lines
     */
    private void refreshStatus() {
    }
    
   
    
    private void refresh() {
        repaint();
    }
    
    /**
     * Resets the GameBoard board for a new game.
     */
    public void reset() {
        reset = true;
        player=0;
        falseMove=0;
        board = new GameBoard(dim[0], dim[1]);
        do refreshBoard(); while (moveThread > 0);
        reset = false;
    }

    /**
     * gets the game status
     * @return     0 = PLAYER_A was the last player
     * @return     1 = PLAYER_B was the last player
     * @return     3 = the board is yet empty
     * @return     4 = game over and PLAYER_A won
     * @return     5 = game over and PLAYER_B won
     * @return     8 = game over without winner
     * @return     9 = board need to be accepted
     */
    public int getStatus() {
        return board.getStatus();  //returns 0 at the beginning of the game
    }
    
    /**
     * returns the next move. 
     * @param player   PLAYER_A or PLAYER_B player
     * @param e         position of mouse click (next move for human player)
     */
    private PlayerPosition play(final int player,final MouseEvent e) {
        PlayerPosition ret = new PlayerPosition();
        if (playerType[player] == 0  && e!=null ){     //Human player
            ret = new PlayerPosition(1+e.getX()/cellSize,1+e.getY()/cellSize);
            moveGenerator[2] = HUMAN;
        } else{   //Computer Player        	 
        	AI aiPlayer = new AI(new GomokuStrategy(board));  
        	//Evaluate the best move based on free spaces and potential game states
        	ret = aiPlayer.getNextMove();  
            moveGenerator[2] = COMPSTRATEGY;
        }
        // Output on console for log the game
        System.out.print("GameBoardUI PlayerPosition play ret value "+ret.toString() + " row: " + ret.getRow() + " column: " + ret.getColumn() + "\n");
        return ret;
    }
    
    /**
     *class to starts the move calculation into a thread
     */
    private final class MakeMove extends Thread {
        private final MouseEvent e; //position where the human player clicked
        
        /**
         *creates a new MakeMove to calculate a move
         **/
        public MakeMove(final MouseEvent e) {
            this.e = e;
            moveThread++;
        }
        
        /**
         *starts the calculation
         */
        @Override
        public void run() {
            if (moveThread==1 ) {
                //if moveThread is bigger than 1 than there are another 
                //calculation on going and this should be stopped
                do {
                    if ( board.getStatus() <= FREE && falseMove<5 ){
                        //resetSuggestions();
                        if ( board.setPiece(play(player,e),(int) player)) {
                            moveGenerator[player] = moveGenerator[2];
                            player = ( player + 1 ) % 2;
                            falseMove = 0;
                        } else {
                            // move is not allowed
                            falseMove++;
                            
                        }
                    }
                    refreshBoard();
                } while ( board.getStatus() <= FREE && falseMove<5 && (playerType[player] != 0 && !reset) );
            }
            moveThread--;
        }
    } //class MakeMove
} //class GameBoardUI

