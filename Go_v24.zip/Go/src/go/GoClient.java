package go;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.io.*;

/**
 * ChatterClient class
 * 
 * Is used by ChatterClientGUI to process user input; communicates with server through Socket
 * connection to send and receive ChatterMessages and SArrays
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class GoClient {
	
	private static final String DEFAULT_PLAYER_TYPE = "ai";
	private static final String DEFAULT_HOST = "localhost";
	private static final int DEFAULT_PORT = 11732;
	private static final int COLOR_NOT_ASSIGNED = 3;
	private static final int WHITE = 0;
	private static final int BLACK = 1;
	
	private String username;
	private ArrayList<String> nameList = new ArrayList<String>();
	private int port;
	private String ip;
	private Socket sock;
	private ObjectOutputStream oOut;
	private ObjectInputStream oIn;
	private GoClientGUI cGUI;
	private boolean keepGoing = true;
	private int stoneColor = COLOR_NOT_ASSIGNED; //White is 0 and Black is 1 Not assigned color is 3
	
	protected int getStoneColor() {
		stoneColor = 0;
		return stoneColor;
	}
	private void setStoneColor(int color) {
		stoneColor = color;
	}

	// run once for each user who wants to use the chat
	public static void main(String[] args) {
		if ( args.length == 3 ){
			String serverAddress = args[0];
			int portNumber = Integer.parseInt(args[1]);
			String playerType = args[2];
			new GoClientGUI(serverAddress, portNumber, playerType);
		}
		else new GoClientGUI(DEFAULT_HOST, DEFAULT_PORT, DEFAULT_PLAYER_TYPE);			//default player is an ai
	}

	// ChatterClient constructor
	public GoClient(String server, int portNumber, String clientName, GoClientGUI ccg) {
		this.ip = server;
		this.port = portNumber;
		this.username = clientName;
		this.cGUI = ccg;
	}
	
	// connects socket and creates input and output streams
	public boolean start() {
		System.out.println("chat client started...");
		boolean startValue = true;
		keepGoing = true; 
		
		try
		{
			//System.out.println("about to try to call 'localhost' / " + port);
			sock = new Socket(ip, port);
			oOut = new ObjectOutputStream(sock.getOutputStream());
			
			//System.out.println("setting username: " + cGUI.getUsername());
			setUsername(cGUI.getUsername());
			oOut.flush();
			oIn = new ObjectInputStream(sock.getInputStream());

			//System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();
		}
		catch ( IOException ioe ) {
			System.err.println("Client connection was closed.");
		}
		
		return startValue;
	}

	// called when user attempts to change username
	protected void setUsername(String newName) {
		//Use the new protocol for the game nickname changes
		if ( !(username.equals(newName)) ) {
			String msg = GomokuProtocol.generateChangeNameMessage(username, newName);

			try {
				oOut.writeObject(msg);
				oOut.flush();
			}
			catch(IOException ioe) { 
				System.err.println("Error caught: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
	}
	
	// function to send message through output stream
	/*
	public void sendMessage(ChatterMessage cm) {
		try {
			oOut.writeObject(cm);
			oOut.flush();
		}
		catch (IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}	
	}
	*/
	
	// function to send message through output stream
	public void sendMessage(String msg) {
		try {
			oOut.writeObject(msg);
			oOut.flush();
		}
		catch (IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}	
	}
	
	
	//get the list of names
	protected ArrayList<String> getNameList() {
		return nameList;
	}
	
	//get the current client username
	protected String getClientUsername(){
		return this.username;
	}

	// thread that runs to listen for new messages and add them to chat history list if
	// they are public messages or private messages meant for this client
	class Listen implements Runnable {
		@Override
		public void run() {
			//System.out.println("Listen running...");

			try {
				while (keepGoing) {
					
					username = cGUI.getUsername();
					
					//System.out.println("reading from oIn");
					Object readObj = oIn.readObject();

					if (readObj instanceof String) {
						String msg = (String)readObj; 
						//Print the message on Chat history
						cGUI.printChatHistory("received : " + msg);
						if (GomokuProtocol.isPlayMessage(msg)) {
							int[] detail = GomokuProtocol.getPlayDetail(msg);
							// black is 1 and white is 0
							System.out.println("color is " + detail[0]);
							System.out.println("row is " + detail[1]);
							System.out.println("col is " + detail[2]);

							//check winner for opponent here, if not success, turn on myTurn
							//also server checks for opponent team's client, and does not post the stone here
							cGUI.setMyTurn(true); //enable client to run
							PlayerPosition pp = new PlayerPosition();
							pp.setColumnRow(detail[2]+1, detail[1]+1);
							//CHECK INCOMING HERE
							cGUI.pBoard.board.placeAIStone(pp, (int)detail[0]);	
							cGUI.pBoard.refreshBoard();

							//call the following line only for AI mode
							if (cGUI.getPlayerMode()==1){
								cGUI.pBoard.makeMove(null);
							}
						}			
						
						else if (GomokuProtocol.isChangeNameMessage(msg)) {
							cGUI.printChatHistory(msg);
						}
						

						else if (GomokuProtocol.isChatMessage(msg)) {
							cGUI.printChatHistory(msg);
						}

						else if (GomokuProtocol.isGiveupMessage(msg)) {
							cGUI.setWinCounter(true);  //pass true if win the game 
							cGUI.printChatHistory("You win!!!!!");
							cGUI.pBoard.board.reset();
						}

						else if (GomokuProtocol.isLoseMessage(msg)) {
							cGUI.setMyTurn(false);
							cGUI.setWinCounter(false);  //pass false if lost the game 
							cGUI.printChatHistory("You lose");
						}

						else if (GomokuProtocol.isWinMessage(msg)) {
							cGUI.setMyTurn(false);
							cGUI.setWinCounter(true);  //pass true if win the game 
							cGUI.printChatHistory("You win!!!!!");
						}

						else if (GomokuProtocol.isResetMessage(msg)) {
							cGUI.pBoard.board.reset();
						}						
						//send black stone color
						else if (GomokuProtocol.isSetBlackColorMessage(msg)) {
							System.out.println(msg);
							setStoneColor(BLACK);
							cGUI.setPlayer(true);  //set black stone
							cGUI.setPlayer(BLACK);
							cGUI.setMyTurn(true);
							//call the following line only for AI mode
							if (cGUI.getPlayerMode()==1){
								cGUI.pBoard.makeMove(null);
							}

						}
						//send white stone color
						else if (GomokuProtocol.isSetWhiteColorMessage(msg)) {
							System.out.println(msg);
							setStoneColor(WHITE);
							cGUI.setPlayer(false); //set white stone
							cGUI.setPlayer(WHITE);
							cGUI.setMyTurn(false);
						}	
					}
				}
			} // END try 
			catch(ClassNotFoundException cnfe) {
				System.err.println("caught: " + cnfe + " from ");
				cnfe.printStackTrace();
			} // END catch 
			catch(SocketException se) {
				System.err.println("caught: " + se + " from ");
				se.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("\n\n\nUser connection was closed");
			} // END catch
		} // END public void run()
	} // END class Listen

	
	
	
	////////////////////////////////////////////////////////////		new methods recently added		////////////////////////////////////////
	
	public void resetGame(String msgToServer) {	}
	public void giveUpGame(String msgtoServer) { }
	public void getColor(String msgFromServer) { }
	public void isWin(String msgFromServer) { }
	public void isLost(String msgFromServer) { }
	public void setMyMove(String msgToServer) {	}
	public void getOpponent(String msg) { }
	public void useProtocol(String msg) { }
	public void selectMode(String msg) { }
	
	
} // END public class ChatterClient