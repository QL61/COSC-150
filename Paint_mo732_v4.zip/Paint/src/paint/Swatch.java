// Swatch.java  Barrett Koster and CS-212 class 2013
// takes over a square region of the window with a color
// boxes are 20 pixels square

package paint;

import java.awt.*;

public class Swatch
{
	protected Color color;
	protected int x, y; // pixels from upper left to upper left corner

	protected Color palleteColor[] = 
		{Color.WHITE, Color.PINK, Color.RED, 
				Color.ORANGE, Color.YELLOW, Color.GREEN, 
				Color.BLUE, Color.MAGENTA, Color.BLACK};
	protected static int currentColorPos = 0;
	

	// constructor, give upper left corner and color
	public Swatch( int x1, int y1, Color c1 )
	{
//		System.out.println("Enter Swatch (3 param)");
		x = x1; y = y1; color = c1;
	}

	// constructor without color, makes random color
	public Swatch( int x1, int y1 )
	{
//		System.out.println("Enter Swatch (1 param)");
		
		x = x1; y = y1; 
		setSwatchColor();
	}

	// given coordinates mx,my (like a mouse click) say if
	// the click is on THIS Swatch.
	public boolean zatyou( int mx, int my )
	{
		return ( x<=mx && mx<x+20 && y<=my && my<y+20);
	}

	// sets the color attribute to a random color
	public void setSwatchColor()
	{
//		System.out.println("Enter setSwatchColor()");
		//set color pallete
		if(currentColorPos < palleteColor.length) {
//			System.out.println("can setSwatchColor()");
//			System.out.println(palleteColor.length);
//			System.out.println(currentColorPos);
			color = palleteColor[currentColorPos];
			currentColorPos++;
		}
		//sets default color from colorPallete
		else {
			color = Color.BLACK;
		}
	}

	// fills a rectangle at xy with color, 20x20 pixels
	public void drawMe ( Graphics g )
	{
//		System.out.println("Enter Swatch: drawMe()");
		g.setColor( color );
//		System.out.println("x= " + x + " | y= " + y);
		g.fillRect( x, y, 20, 20 ); 
	}

	// access
	public void setColor( Color c ) { color = c; }
	public Color getColor() { return color ; }
}
