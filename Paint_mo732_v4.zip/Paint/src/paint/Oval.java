package paint;
import java.awt.Color;
import java.awt.Graphics;


/**
 * Oval class
 */

// calculates area and perimeter for ovals

import java.lang.Math;

public class Oval extends Shape {
	
	// FIELDS
	private	double maj = 0, min = 0;
	private Coordinates v1, v2;

	// CONSTRUCTOR
	public Oval(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(release);
		this.updateAxes();
		this.color = color;
	}
	
	// METHODS
	@Override public double getArea() {
		return Math.PI * maj * min;
	}
	@Override public double getPerimeter() { // calculated using Ramanujan's Formula 1
		return Math.PI*(3*(maj+min)-Math.sqrt((3*maj+min)*(maj+3*min)));
	}
	public void setV1(Coordinates c) {
//		this.v2.x += this.v1.x - c.x;
//		this.v2.y += this.v1.y - c.y;
		this.v1 = c;
		this.updateAxes();
	}
	public void setV2(Coordinates c) {
//		this.v1.x += this.v2.x - c.x;
//		this.v1.y += this.v2.y - c.x;
		this.v2 = c;
		this.updateAxes();
	}
	
	public void setMajAxis(double w) {
		this.maj = w;
	}
	
	public void setMinAxis(double h) {
		this.min = h;
	}
	
	public Coordinates getV1() {
		return v1;
	}
	
	public Coordinates getV2() {
		return v2;
	}
	
	public double getMajAxis() {
		return maj;
	}
	
	public double getMinAxis() {
		return min;
	}
	
	private void updateAxes() {
		if (getV1() != null && getV2() != null ) {
			double h = Math.abs((v1.getX() - v2.getX()) / 2);
			double v = Math.abs((v1.getY() - v2.getY()) / 2);
			if (h >= v) {
				setMajAxis(h);
				setMinAxis(v);
			}
			else {
				setMajAxis(v);
				setMinAxis(h);
			}
		}
	}

	@Override
	public void drawShape(Graphics g) {
		g.drawOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
		g.setColor(getColor());
		g.fillOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
	}
}





