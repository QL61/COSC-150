package paint;
/**
 * abstract Shape class
 * 
 *
 */
import java.awt.Color;
import java.awt.Graphics;

//parent class for various shapes

public abstract class Shape {
	
	// FIELDS
	protected Color color;
	
	// METHODS
	public abstract double getArea();
	public abstract double getPerimeter();	
	
	public abstract void drawShape(Graphics g);
	
	public double distanceBetween(Coordinates a, Coordinates b) {
		return Math.sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
	}
	public Color getColor() { return this.color; }
}

