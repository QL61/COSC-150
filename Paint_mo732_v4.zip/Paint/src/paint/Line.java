package paint;

import java.awt.Color;
import java.awt.Graphics;

//calculates length of line

public class Line extends Shape {
	
	private double length = 0;
	private Coordinates v1, v2;
	
	// CONSTRUCTOR
	public Line(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(release);;
		setLength(distanceBetween(getV1(), getV2()));
		this.color = color;
	}

	// METHODS
	public double getLength() { return length; }
	@Override public double getArea() { return 0; }
	@Override public double getPerimeter() { return 0; }
	public void setV1(Coordinates c) {
		v1 = c;
//		this.length = distanceBetween(this.v1, this.v2);									/////////////////////causes errors
	} // END setV1(Coordinates)
	public void setV2(Coordinates c) {
		v2 = c;
//		this.length = distanceBetween(this.v1, this.v2);									//////////////////////causes errors
	} // END setV2(Coordinates)

	public Coordinates getV1() {
		return v1;
	}
	
	public Coordinates getV2() {
		return v2;
	}
	
	public void setLength(double l) {
		this.length = l;
	}

	@Override
	public void drawShape(Graphics g) {
		g.drawLine(v1.getX(),v1.getY(), v2.getX(), v2.getY());	
		g.setColor(getColor());
	}
}
