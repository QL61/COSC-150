package chatter;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * SArray class
 * 
 * This is one of two object classes that travel along the input and output streams of the
 * sockets between server and clients. This is a serializable version of the ArrayList, and is
 * used by the server to deliver updated version of the list of client usernames to each client
 * when there has been a username change, when a user leaves the chat, or when a new user joins
 * the chat.
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class SArray implements Serializable {
	private static final long serialVersionUID = 1L;
	private ArrayList<String> al = new ArrayList<String>();

	//constructor to create an SArray
	public SArray() { al = new ArrayList<String>(); }
	//constructor with param
	public SArray(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
	//get this arrayList
	protected ArrayList<String> getAL() { return al; }
	//set this arrayList to the passed ArrayList
	private void setAL(ArrayList<String> toSet) { al = new ArrayList<String>(toSet); }
} // END SArray class
