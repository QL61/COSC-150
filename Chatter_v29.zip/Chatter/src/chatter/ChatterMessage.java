package chatter;

import java.io.*;
import java.util.Map;

/**
 * ChatterMessage class
 * 
 *  This is a class of messages containing all the information that the server and clients
 *  need in order to decide what to do with a message, including the sender's name, the 
 *  recipient's name, the nature of the message (public, private, or a name change), and the
 *  contents of the message. This is one of two object classes sent along the input and output
 *  streams between the server and the clients.
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class ChatterMessage implements Serializable {
	
	private static final long serialVersionUID = 1L;
	public static final String EXIT = "exit";
	public static final String PUBLIC = "public";
	public static final String PRIVATE = "private";
	public static final String NAME_CHANGE = "name change";
	
	protected String message;
	protected String messageType;
	protected String sender;
	protected String recipient;
	
	// Default constructor
	public ChatterMessage() {
		this.message = "";
		this.messageType = PUBLIC;
		this.sender = "";
		this.recipient = "";
	}
	
	// Constructor with parameters
	public ChatterMessage(String messageType, String sender, String recipient, String msg) {
		this.messageType = messageType;
		this.sender = sender;
		this.recipient = recipient;
		this.message = msg;
	}
	
	// Constructor with HashMap
	public ChatterMessage(Map<String, String> info) {
		this.messageType = info.get("type");
		this.sender = info.get("sender");
		this.recipient = info.get("recipient");
		this.message = info.get("message");
	}

	//get the type of message
	protected String getMessageType() { return messageType; }

	//get the message that was sent
	protected String getMessage() { return message; }
	
	//get the sender of the message
	protected String getSender() { return sender; }

	//get the recipient of the message
	protected String getRecipient() { return recipient; }
	
} // END ChatMessage class
