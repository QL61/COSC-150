package paint;
import java.util.HashMap;

/**
 * Rectangle class
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public class Rectangle extends Shape {

	//constants
	private static final double DEFAULT_EMPTY_VALUE = 0.0;
	private static final int RECT_PER_MULT_FACTOR = 2;
	private static final String SIDE_STRING_1 = "side1";
	private static final String SIDE_STRING_2 = "side2";

	//class member variables
	private double width;
	private double height;

	/**
	 * Rectangle constructor
	 * @param args	a hashmap that contains the shape and associated side values
	 */
	Rectangle(HashMap<String, Double> args){
		setWidth((Double)args.getOrDefault(SIDE_STRING_1, DEFAULT_EMPTY_VALUE));
		setHeight((Double)args.getOrDefault(SIDE_STRING_2, DEFAULT_EMPTY_VALUE));
	}

	/**
	 * set the width of rectangle
	 * 
	 * @param width
	 */
	private void setWidth(double width) {
		this.width = width;
	}

	/**
	 * set the height of rectangle
	 * @param height
	 */
	private void setHeight(double height) {
		this.height = height;
	}

	/**
	 * 
	 * @return width
	 */
	protected double getWidth() {
		return width;
	}

	/**
	 * 
	 * @return height
	 */
	protected double getHeight() {
		return height;
	}

	/**
	 * calculate area
	 * @return area 
	 */
	public double getArea(){
		double area = 0;
		if (width > DEFAULT_EMPTY_VALUE && height > DEFAULT_EMPTY_VALUE) {
			area = width * height;	
		}
		return area;
	}

	/**
	 * calculate perimeter
	 * @return perimeter
	 */
	public double getPerimeter(){
		double perimeter = 0;
		if (width > DEFAULT_EMPTY_VALUE && height > DEFAULT_EMPTY_VALUE) {
			perimeter = (width + height) * RECT_PER_MULT_FACTOR;
		}
		return perimeter;
	}
}
