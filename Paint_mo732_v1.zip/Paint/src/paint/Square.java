package paint;
import java.util.HashMap;

/**
 * Square class
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public class Square extends Shape {
	
	//constants
	private static final double DEFAULT_EMPTY_VALUE = 0.0;
	private static final double SQUARE_PER_MULTIPLIER = 4.0;
	private static final double SQUARE_AREA_POWER = 2.0;
	private static final String SIDE_STRING_1 = "side1";
	
	//class member variables
	private double side;

	/**
	 * Square constructor
	 * @param args	a hashmap that contains the shape and associated side values
	 */
	Square(HashMap<String, Double> args){
		setSideSize((Double)args.getOrDefault(SIDE_STRING_1, DEFAULT_EMPTY_VALUE));
	}
	
	/**
	 * set value of side for Square
	 * @param sideSize
	 */
	private void setSideSize(double sideSize) {
		this.side = sideSize;
	}
	
	/**
	 * @return side
	 */
	protected double getSideSize() {
		return side;
	}
	
	/**
	 * @return perimeter
	 */
	public double getPerimeter() {
		return side * SQUARE_PER_MULTIPLIER;
	}
	
	/**
	 * @return area
	 */
	public double getArea() {
		return Math.pow(side, SQUARE_AREA_POWER);
	}
}
