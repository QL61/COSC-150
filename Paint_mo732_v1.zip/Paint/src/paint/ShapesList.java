package paint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * ShapesList class used to handle
 * various different shapes.
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public class ShapesList {

	//constants
	private static final double DEFAULT_EMPTY_VALUE = 0.0;
	private static final String CIRCLE_STRING = "circle";
	private static final String TRIANGLE_STRING = "triangle";
	private static final String RECTANGLE_STRING = "rectangle";
	private static final String SQUARE_STRING = "square";
	private static final String FILE_NOT_FOUND= "File not found.";
	private static final String INVALID_SHAPE = "Invalid input shape detected";
	private static final String SIDE_STRING = "side";
	private static final String INVALID_SHAPE_DATA_VALUE = " is invalid side value; continuing...\n";
	private static final int TRIANGLE_SIDE_NUMBER = 3;
	private static final int RECTANGLE_SIDE_NUMBER = 2;
	private static final int CIRCLE_SIDE_NUMBER = 1;
	private static final int SQUARE_SIDE_NUMBER = 1;
	
	//class variables
	private ArrayList<Shape> shapesList = new ArrayList<Shape>();
	private double totalPerimeter = 0.0;
	private double totalArea = 0.0;
	
	/**
	 * sets the total Perimeter
	 * @param p	the perimeter value passed
	 */
	private void setTotalPerimeter(double p) {
		totalPerimeter = p;
	}

	/**
	 * sets the total Area
	 * @param a	the area value passed
	 */
	private void setTotalArea(double a) {
		totalArea = a;
	}	

	/**
	 * @return totalPerimeter class member value
	 */
	public double getTotalPerimeter() {
		return totalPerimeter;
	}

	/**
	 * @return totalArea class member value
	 */
	public double getTotalArea() {
		return totalArea;
	}

	/**
	 * calculate total perimeter function that calls get Perimeter function
	 * @return tempPer	the total perimeter calculated
	 */
	private double calculateTotalPerimeter() {
		double tempPer = 0;

		for (int i = 0; i < shapesList.size(); i++) {
			tempPer += (shapesList.get(i)).getPerimeter();
		}
		return tempPer;
	}

	/**
	 * calculate total area function that calls get Area function
	 * @return tempArea the total area calculated
	 */
	private double calculateTotalArea() {
		double tempArea = 0;

		for (int i = 0; i < shapesList.size(); i++) {
			tempArea += (shapesList.get(i)).getArea();
		}

		return tempArea;
	}

	/**
	 * Determine if the shape is one of the four valid shape inputs.
	 * @param shapeString	the string to be test for validity
	 * @return validInputString	of type boolean
	 */
	private static boolean detectValidShape(String shapeString) throws Exception {

		boolean validInputShape = false;

		//determine if the string of the shape passed is valid
		if (shapeString.equalsIgnoreCase(CIRCLE_STRING) || shapeString.equalsIgnoreCase(RECTANGLE_STRING) 
				|| shapeString.equalsIgnoreCase(SQUARE_STRING) || shapeString.equalsIgnoreCase(TRIANGLE_STRING)) {
			validInputShape = true;
		}

		return validInputShape;
	}

	/**
	 * @param shapeString	the shape
	 * @param hp	a hashmap of values associated to the shape
	 * @return determinedShape the shape that corresponds to the shape passed
	 * @throws Exception 
	 */
	private Shape makeValidShape(String shapeString, HashMap<String, Double> hp) throws Exception {
		Shape determinedShape = null;
		boolean validNumberArg = false;
		int correctSides = 0;
		
//		//create correct shape with correct values
//		if (shapeString.equalsIgnoreCase(CIRCLE_STRING)) {
//			if (hp.size() != CIRCLE_SIDE_NUMBER) {
//				correctSides = CIRCLE_SIDE_NUMBER;
//				validNumberArg = true;
//			}
//			determinedShape = new Circle(hp);
//		}
		//else 
		if (shapeString.equalsIgnoreCase(RECTANGLE_STRING)) {
			if (hp.size() != RECTANGLE_SIDE_NUMBER) {
				correctSides = RECTANGLE_SIDE_NUMBER;
				validNumberArg = true;
			}
			determinedShape = new Rectangle(hp);
		}
		else if (shapeString.equalsIgnoreCase(SQUARE_STRING)) {
			if (hp.size() != SQUARE_SIDE_NUMBER) {
				correctSides = SQUARE_SIDE_NUMBER;
				validNumberArg = true;
			}
			determinedShape = new Square(hp);
		}
		else if (shapeString.equalsIgnoreCase(TRIANGLE_STRING)) {
			if (hp.size() != TRIANGLE_SIDE_NUMBER) {
				correctSides = TRIANGLE_SIDE_NUMBER;
				validNumberArg = true;
			}
			determinedShape = new Triangle(hp);
		}
		//if shape does not have correct number of sides
		//display error message and throw exception
		if (validNumberArg) {
			System.out.println(shapeString + " cannot have " + hp.size() + " side(s)");
			System.out.println(shapeString + " must have " + correctSides + " correct side(s)");
			throw new Exception();
		}
		
		return determinedShape;
	}
}