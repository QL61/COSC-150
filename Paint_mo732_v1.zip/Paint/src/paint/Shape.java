package paint;
/**
 * abstract Shape class
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public abstract class Shape {
	
	//abstract methods of the abstract class
	abstract double getArea();
	abstract double getPerimeter();
}
