package chatter;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.io.*;

/**
 * ChatterClient class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */
public class ChatterClient {
	
	private static final String DEFAULT_HOST = "localhost";
	private static final int DEFAULT_PORT = 55305;
	
	private String username;
	private ArrayList<String> nameList = new ArrayList<String>();
	private int port;
	private String ip;
	private Socket sock;
	private ObjectOutputStream oOut;
	private ObjectInputStream oIn;
	private ChatterClientGUI cGUI;	
	private boolean keepGoing = true;

	public static void main(String[] args) {
		if ( args.length >= 2 ){
			String serverAddress = args[0];
			int portNumber = Integer.parseInt(args[1]);
			new ChatterClientGUI(serverAddress, portNumber);
		}
		else new ChatterClientGUI(DEFAULT_HOST, DEFAULT_PORT);
	}

	public ChatterClient(String server, int portNumber, String clientName, ChatterClientGUI ccg) {
		this.ip = server;
		this.port = portNumber;
		this.username = clientName;
		this.cGUI = ccg;
	}
	
	public boolean start() {
		System.out.println("chat client started...");
		boolean startValue = true;
		keepGoing = true; 
		
		try
		{
			//System.out.println("about to try to call 'localhost' / " + port);
			sock = new Socket(ip, port);
			oOut = new ObjectOutputStream(sock.getOutputStream());
			
			//System.out.println("setting username: " + cGUI.getUsername());
			setUsername(cGUI.getUsername());
			oOut.flush();
			oIn = new ObjectInputStream(sock.getInputStream());

			//System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("Client connection was closed.");
		}
		
		return startValue;
	}

	protected void setUsername(String newName) {
		Map<String, String> nameInfo = new HashMap<String, String>();
		nameInfo.put("type", "name change");
		nameInfo.put("sender", username);
		nameInfo.put("recipient", username);
		nameInfo.put("message", newName);
		ChatterMessage nameCM = new ChatterMessage(nameInfo);
		
		try {
			oOut.writeObject(nameCM);
			oOut.flush();
		}
		catch(IOException ioe) { 
			System.err.println("Error caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}
	
	class Listen implements Runnable {
		@Override
		public void run() {
			//System.out.println("Listen running...");

			try {
				while (keepGoing) {
					//System.out.println("reading from oIn");
					Object readObj = oIn.readObject();
					
					if (readObj instanceof SArray) {
						//System.out.println("received updated name list");
						SArray sa = new SArray();
						sa = (SArray) readObj;
						if (nameList != null) {
							for (int i = nameList.size()-1; i > -1; i--) {
								//System.out.println("former name: " + nameList.get(i));
								nameList.remove(i);
							}
						}
						for (int i = 0; i < sa.getAL().size(); i++) {
							//System.out.println("new name: " + sa.getAL().get(i));
							nameList.add(sa.getAL().get(i));
						}
						username = cGUI.getUsername();
					}
					else if (readObj instanceof ChatterMessage) {
						ChatterMessage cm = (ChatterMessage) readObj;
						cGUI.printChatHistory(cm);
					}
				} // END while
			} // END try 
			catch(ClassNotFoundException cnfe) {
				System.err.println("caught: " + cnfe + " from ");
				cnfe.printStackTrace();
			} // END catch 
			catch(SocketException se) {
				System.err.println("caught: " + se + " from ");
				se.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("\n\n\nUser connection was closed");
			} // END catch
		} // END public void run()
	} // END class Listen
	
	public void sendMessage(ChatterMessage cm) {
		try {
			oOut.writeObject(cm);
			oOut.flush();
		}
		catch (IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}	
	}
	
	public ArrayList<String> getNameList() {
		return nameList;
	}
	
	public String getClientUsername(){
		return this.username;
	}

} // END public class ChatterClient