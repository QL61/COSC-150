package go;


import java.util.Arrays;

/**
 * GomokuStrategy class 
 * perform MiniMax and ALPHA-BETA algorithms
 * 
 * AI Class
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 * 
 */


public class GomokuStrategy {

	// Added constants MARK
	static final int PLAYER_A = 0;         //piece PLAYER_A
	static final int PLAYER_B = 1;         //piece PLAYER_B
	static final int FREE = 3;          //a free place on the board
	static  int[] EMPTY = {32};    // empty integer array
	static final int INFINIT = 999999;
	
    /**board to be analyzed*/
    protected GameBoard board;          
    /**next move to be simulated*/
    protected PlayerPosition move;      
    /**sorted set with all Free valid places*/
    protected GomokuAvailableField sortedAvailableFields;         
    /**value of the actual board*/
    protected int value = 0;          
    /**Intermediate values of a think level for the position*/
    protected int intValue;           
    /**player that set the last piece*/
    protected int TDPlayer;          
    
    //AI Thinking Depth
    protected int maxTD =3;  //next potential game states are taken into consideration             
        
    /**for the ALPHA-BETA algorithms*/
    protected int alpha = -INFINIT;   
    /**for the ALPHA-BETA algorithms*/
    protected int beta = INFINIT;     

// specialPattern array stores patterns
    protected int[][] specialPattern = {{0,0,0,0},{0,0,0,0}};
    /** Structure for line evaluation */
    Eval evaluateLine;

    /**
     *constructor
     */
    protected GomokuStrategy(GameBoard b) {
        TDPlayer = b.getStatus();
        evaluateLine = new Eval(TDPlayer,specialPattern);
        board = new GameBoard(b);
        sortedAvailableFields = new GomokuAvailableField(15,15);
        if (board.getStatus() < FREE) {
            calcFreeList();
            calcBoardValue();
            if (maxTD>1) orderAvailableChoices();
        }
    }
    
    /**
     * constructor
     */
    protected GomokuStrategy(GomokuStrategy es) {
        value = es.value;
        alpha = es.alpha;
        beta = es.beta;
        maxTD = es.maxTD;

        TDPlayer = es.TDPlayer;
        board = new GameBoard(es.board);
        sortedAvailableFields = new GomokuAvailableField(es.sortedAvailableFields);
        if (es.move != null) 
            move = (PlayerPosition) sortedAvailableFields.get(es.sortedAvailableFields.indexOf(es.move));
        for (int i=PLAYER_A;i<=PLAYER_B;i++) 
            System.arraycopy(es.specialPattern[i],0,specialPattern[i],0,specialPattern[i].length);
        evaluateLine = new Eval(es.evaluateLine.lastStone,specialPattern);
    }
    
//evaluate each move
    protected void copyEvaluation( GomokuStrategy es) {
        value = es.value;
        alpha = es.alpha;
        beta = es.beta;
        maxTD = es.maxTD;
        TDPlayer = (int) ((es.TDPlayer+1)%2);
        board.copyBoard(es.board);
        sortedAvailableFields = new GomokuAvailableField(es.sortedAvailableFields);
        if (es.move != null) 
            move = (PlayerPosition) sortedAvailableFields.get(es.sortedAvailableFields.indexOf(es.move));
        for (int i=PLAYER_A;i<=PLAYER_B;i++) 
            System.arraycopy(es.specialPattern[i],0,specialPattern[i],0,specialPattern[i].length);
    }

//calculate available positions
    protected void calcFreeList() {
        availablePosition(board.getFullList());
    }
       
//free positions
    protected void availablePosition( PlayerPosition p) {
        PlayerPosition[] freeCoord = board.getFreeRound(p);
        for (int i=0; freeCoord != null && i < freeCoord.length;i++ ) {
            sortedAvailableFields.addLast(freeCoord[i]);
        }
    }
    
    /**
     * set all free fields, around all position of the list p, into free
     * @param p     the position list which should be analyzed
     */
    protected void availablePosition( PlayerPosition[] p) {
        for (int i=0; i < p.length; i++ ) availablePosition(p[i]);
    }

    /**
     * Sort free with the best moves at first, to accelerate the algorithm to 
     * find the next best move. With a sorted free the ALPHA-BETA algorithm will
     * cut early a calculation.
     * This method use think depth 1 to sort free.
     **/
    protected void orderAvailableChoices() {
        GomokuStrategy firstEvaluation = new GomokuStrategy(this);  // create firstEvaluation as copy
        firstEvaluation.maxTD = (int) 1;                   
        AI firstMove = new AI(firstEvaluation);         // calculate the moves
        sortedAvailableFields = new GomokuAvailableField(firstMove.getAscendOrder(), 15, 15);
    }
    
   

//calculate the value if player puts a stone
    protected void simulateMove(){
        // specialPattern will be changed into this method
        value += evaluateLine.negativeLineValue(board.getRow(move));
        value += evaluateLine.negativeLineValue(board.getColumn(move));
        value += evaluateLine.negativeLineValue(board.getDiagUp(move));
        value += evaluateLine.negativeLineValue(board.getDiagDown(move));
        board.placeAIStone(move,TDPlayer);
        availablePosition(move);
        value += evaluateLine.calculateLineValue(board.getRow(move));
        value += evaluateLine.calculateLineValue(board.getColumn(move));
        value += evaluateLine.calculateLineValue(board.getDiagUp(move));
        value += evaluateLine.calculateLineValue(board.getDiagDown(move));
        intValue = (1-2*TDPlayer)*INFINIT;
    }
    
    /**
     * Calculates the value of the game situation. This is only used to
     * Initialize a new GomokuStrategy.
     */
    protected void calcBoardValue(){
        int i;
        for ( i=1; i <= 15; i++) //board size is 15
            value += evaluateLine.calculateLineValue(board.getRow(i));
        for ( i=1; i <= 15; i++) 
            value += evaluateLine.calculateLineValue(board.getColumn(i));
        for ( i=5; i < 15 + 15 -4; i++) 
            value += evaluateLine.calculateLineValue(board.getDiagUp(i));
        for ( i=5; i < 15+ 15-4; i++) //board size is 15
            value += evaluateLine.calculateLineValue(board.getDiagDown(i));
    }
    
    /*
     * The subclass Eval calculate the value
     * of each line on a board
     */
    private class Eval {
        private int lastStone;         
        private int intValMax;  
        private int intVal;     
        private int pattern;
        private int count;      
        private int color;
        private int[] value = new int[2];  
        private int[] ss = new int[4];  
        private int[][] eP;            
        
//evaluate last move
        protected Eval( int lastStone, int[][] extPat) {
            this.lastStone=lastStone;
            eP=extPat;
        }
        
        /*
         * accept values of patterns and counts the number of special patterns
         */
        private void determinePattern() {
            int i;
            if (color!=FREE) {
                if ( maxTD == 1 || lastStone==PLAYER_A ) {
                    if ( lastStone == color ) {
                        intValMax <<= 1;
                    }
                }
                value[color] += intValMax;
                for (i=3; i>=0; i--) {
                    if (ss[i]>0) {
                        eP[color][i]++;
                        break;
                    }
                }
                for (i=0;i<ss.length;i++) ss[i]=0;
                intValMax = 0;
            }
        }
        
// calculate a negative value of a move
        protected int negativeLineValue( int[] js ) {
            for (int i=0; i<eP[0].length; i++) eP[PLAYER_A][i] *= (-1);
            for (int i=0; i<eP[1].length; i++) eP[PLAYER_B][i] *= (-1);
            int ret = calculateLineValue(js);
            for (int i=0; i<eP[0].length; i++) eP[PLAYER_A][i] *= (-1);
            for (int i=0; i<eP[1].length; i++) eP[PLAYER_B][i] *= (-1);
            return -ret;
        }            
        
//calculate line value 

        protected int calculateLineValue( int[] js ) {
            Arrays.fill(value,(int) 0);
            if ( js.length > 15 ) {  
                intValMax = 0;
                pattern = 0;
                color = FREE;
                Arrays.fill(ss,(int) 0);
                int pos;   
                for ( pos=1 ; js[pos] == FREE && pos < js.length-1 ; pos++);
                count = java.lang.Math.min(pos,6)-1;
                for ( ; pos < js.length-1 ; pos++){
                    intVal = 0;
                    if ( js[pos] == FREE ) {
                        pattern <<= 1;
                        if (count<6) count ++;
                    } else {
                        if ( color == FREE ) color=js[pos];
                        if ( color == js[pos] ) {
                            pattern <<= 1;
                            pattern |= 1;
                            count ++;
                        } else {
                            determinePattern();
                            color = js[pos];
                            for ( count = 0; pattern % 2 == 0 ; count++ ) pattern >>= 1;
                            pattern = 1;
                            count++;
                        }
                    }
                    if ( count == 6 ) {
                        if ( pattern != 0) {
                        	intVal = checkPattern2(pattern);
 
                            if ( intVal != 0 && intValMax < intVal ){
                                intValMax = intVal;
                            }
                        }
                        // reduces the pattern to the least four bits
                        pattern &= 31;
                        count--;
                        if ( pattern == 0 ) {
                            // the line is finished or five free cells are determinePatternd.
                            determinePattern();
                            color = js[pos];
                        }
                    }
                    if ( count == 5 && intVal == 0 && pattern != 0) {
                    	intVal = checkPattern1(pattern);

                        if ( intVal != 0 && intValMax < intVal ) {
                            intValMax = intVal;
                        }
                    }
                    if ( pos==(js.length-2)) {
                        // the line is finished or five free cells are determinePatternd.
                        determinePattern();
                    }
                } 
            } 
            // If line is empty is nothing to do
            return (value[PLAYER_A] - value[PLAYER_B]);
        }

//five stones position pattern
        private int checkPattern1(int pattern) {
        	int retPattern=0;
        	if (pattern==1){
        		retPattern=1;
        	}
        	else if(pattern==2){
        		retPattern=1;
        	}
        	else if(pattern==3){
        		retPattern=9;
        	}
        	else if(pattern==4){
        		retPattern=1;
        	}
        	else if(pattern==5){
        		retPattern=8;
        	}
        	else if(pattern==6){
        		retPattern=10;
        	}
        	else if(pattern==7){
        		retPattern=90;
        	}
        	else if(pattern==8){
        		retPattern=1;
        	}
        	else if(pattern==9){
        		retPattern=7;
        	}else if(pattern==10){
        		retPattern=9;
        	}
        	else if(pattern==11){
        		retPattern=80;
        	}
        	else if(pattern==12){
        		retPattern=10;
        	}
        	else if(pattern==13){
        		retPattern=80;
        	}
        	else if(pattern==14){
        		retPattern=100;
        	}
        	else if(pattern==15){ 
        		ss[1]++;
        		retPattern=450;}
        	else if(pattern==16){
        		retPattern=1;
        	}
        	else if(pattern==17){
        		retPattern=5;
        	}
        	else if(pattern==18){
        		retPattern=7;
        	}
        	else if(pattern==19){
        		retPattern=60;
        	}
        	else if(pattern==20){
        		retPattern=8;
        	}
        	else if(pattern==21){
        		retPattern=60;
        	}
        	else if(pattern==22){
        		retPattern=80;
        	}
        	else if(pattern==23){
        		ss[1]++;
        		retPattern=350;}
        	else if(pattern==24){
        		retPattern=9;
        	}
        	else if(pattern==25){
        		retPattern=60;
        	}
        	else if(pattern==26){
        		retPattern=80;
        	}
        	else if(pattern==27){
        		ss[1]++; 
        		retPattern=350;}
        	else if(pattern==28){
        		retPattern=90;
        	}
        	else if(pattern==29){
        		ss[1]++; 
        		retPattern=350;}
        	else if(pattern==30){
        		ss[1]++; 
        		retPattern=350;}
        	else if(pattern==31){
        		ss[3]++; 
        		retPattern=200000;
        		}
        	return retPattern;
        }

 //six stones position pattern
        private int checkPattern2(int pattern) {
        	int retPattern=0;
        	if (pattern==2){
        		retPattern=20;
        		}
        	else if(pattern==4){
        		retPattern=20;
        	}
        	else if(pattern==6){
        		retPattern=200;
        	}
        	else if(pattern==8){
        		retPattern=20;
        	}
        	else if(pattern==10){
        		retPattern=180;}
        	else if(pattern==12){
        		retPattern=200;
        	}
        	else if(pattern==14){
        		ss[0]++;
        		retPattern=1000;}
        	else if(pattern==16){
        		retPattern=20;
        	}
        	else if(pattern==18){
        		retPattern=160;
        	}
        	else if(pattern==20){
        		retPattern=180;
        	}
        	else if(pattern==22){
        		ss[0]++;
        		retPattern=900;}
        	else if(pattern==24){
        		retPattern=200;
        		}
        	else if(pattern==26){
        		ss[0]++;
        	retPattern=900;}
        	else if(pattern==28){
        		ss[0]++;
        		retPattern=1000;
        		}
        	else if(pattern==30){
        		ss[2]++;
        		retPattern=50000;
        		}
        	return retPattern;

        }

    
    
    } //inner class Eval
}
