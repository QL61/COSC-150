package go;


/**
 * 
 * PlayerPosition Class
 * 
 * Class to represent a board field
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 * 
 */
public class PlayerPosition  {
    private int col;
    private int row;
    
    /** 
     * Creates a new instance of PlayerPosition
     */
    public PlayerPosition() {
    }

    /** 
     * constructor
     * @param col     column position
     * @param row     row position
     */
    public PlayerPosition(int col,int row) {
    	//GUI paintComponent initializes with 0,0 when game starts
        this.col = col;    
        this.row = row;
    }
    
//set column and row 
    protected void setColumnRow( int col, int row) {
        this.col = col;
        this.row = row;
    }
    
//get column
    protected  int getColumn() {
        return col;
    }
    
//get row
    protected int getRow() {
        return row;
    }
    
// integer value representing a position
    protected int positionValue() {
        return row+(col+row-2)*(col+row-1)/2;
    }
    
//calculate unique integer value as position address
    protected void positionAddress( int h ) {
        int c = (int) (Math.sqrt(2*h)-0.5);
        row = (int) (h - c*(c+1)/2);
        col = c - row + 2;
    }
    
//Check two positions are the same
    public boolean equals ( PlayerPosition pos ) {
        return pos.col==col && pos.row==row;
    }
    
//print positionValue
    @Override
    public String toString() {
        return ""+this.positionValue();
    }
}
