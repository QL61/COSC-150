package go;

import java.util.Arrays;
import javax.swing.JPanel;

/**
 * GameBoard.java
 */


// AI Class


public class GameBoard extends JPanel {
	
	private static final long serialVersionUID = 1L;
	/**
     * Creates a new empty GameBoard board.
     * @param totalColumns     the board totalColumns
     * @param width     the board width
     * 
    */
     
    // Added constants MARK
	static final int PLAYER_A = 0;         //piece PLAYER_A
	static final int PLAYER_B = 1;         //piece PLAYER_B
	static final int FREE = 3;          //a free place on the board
	static final int GAMEOVER = 8;      //the game is over
    static final int VALID = 32;        //a free line on a board
    static  int[] EMPTY = {32};    //no lines are found
    static final int[] NOTEXIST = {16}; //not possible
    static final int SIZE = 15;         //size of a square board
    
    
    /**field for the board*/
    protected int[][] board; 
    /**total columns of board*/
    private int totalColumns = SIZE;
    /**total rows of board*/
    private int totalRows = SIZE;   
    
    /**Number of free spaces on the board*/
    private int freeSpaces;     
    
    
  
    public GameBoard(final int totalColumns,final int totalRows) {
        board = new int[totalRows+2][totalColumns+2]; //add 2 extra rows and columns to store position information
        this.totalColumns = totalColumns;
        freeSpaces = totalRows*totalColumns;  //calculate total number of freeSpaces on the board 15 x 15
        reset();

    }
    
    /**
     * Creates a new GameBoard as copy from other
     * @param g     GameBoard to be copied
     **/
    public GameBoard( final GameBoard g ) {
    	board = new int[g.totalRows+2][g.totalColumns+2];
        this.copyBoard(g);
    }
    
    protected void copyBoard(GameBoard b) {
        this.totalColumns = b.totalColumns;
        this.freeSpaces = b.freeSpaces;
        for ( int i=0; i<totalColumns+2 ; i++)
            System.arraycopy(b.board[i],0,board[i],0,totalColumns+2);		
	}

    
	/**
     * Resets the GameBoard board for a new game.
     */
  
    public void reset() {
        freeSpaces = totalRows*totalColumns;
        board[0][0] = VALID; //first cell value is set to 32        
        
        for ( int i=0; i < totalRows+2; i++)  //rows
            for ( int j=0; j < totalColumns+2; j++)  //columns
                if ( i==0 || j==0 || i==totalRows+1 || j==totalColumns+1 ) { 
                    // status frame
                    board[i][j] = VALID;    //update frame cells values
                } else {
                    // valid board positions
                    board[i][j] = FREE;
                }
        // game status
        setStatus(FREE);
    }
    
    
    /**
     * Get number of rows 
     * @return  total Rows of this board.
     */ 
    protected int getTotalRows() {
        return totalRows;
	}

    
    
    /**
     * Get number of columns 
     * @return  width of this board.
     */   
    protected int getTotalColumns() {
        return totalColumns;
	}


   
    /**
     * AI to place a stone on the game board.
     * @param      position where the stone should be placed
     * @param      stone color 1-Black, 0-White
     */
    protected void placeAIStone(final PlayerPosition p,final int stone) {

        final int xCoordinate = p.getColumn();    //Column position of p
        final int yCoordinate = p.getRow();    //Row position of p
        if ( xCoordinate>0 && yCoordinate>0 && xCoordinate<=totalColumns && yCoordinate<=getTotalRows() ) {
            // set stone on the board:
            board[xCoordinate][yCoordinate] = stone;
            // set vertical as used:
            board[xCoordinate][0] = (int)(board[xCoordinate][0] | 1);
            // set horizontal as used:
            board[0][yCoordinate] = (int)(board[0][yCoordinate] | 2);
            // set diagonal down as used:
            if ( yCoordinate-xCoordinate >= 0 )
                board[0][yCoordinate-xCoordinate+1] = (int)(board[0][yCoordinate-xCoordinate+1] | 4);
            else
                board[xCoordinate-yCoordinate+1][0] = (int)(board[xCoordinate-yCoordinate+1][0] | 4);
            // set DiagUp as used:
            if ( xCoordinate+yCoordinate-1 <= getTotalRows() ) 
                board[0][xCoordinate+yCoordinate-1] = (int)(board[0][xCoordinate+yCoordinate-1] | 8);
            else
                board[xCoordinate+yCoordinate-getTotalRows()][0] = (int)(board[xCoordinate+yCoordinate-getTotalRows()][0] | 8);
            // reduce the number of free freeSpaces:
            freeSpaces--;
        }
        
       // boolean isBlack ;
       //  if (stone == 1) { isBlack = true;} else {isBlack = false;}
      //  generatePlayMessage(p,isBlack);
        setStatus((int)1);
    }
    
    
    public boolean setPiece(final PlayerPosition p, int piece) {
        if (p==null) return false; //error on the move generator!!
        int x = p.getColumn();
        int y = p.getRow();
        boolean validMove = true;

        if ( getStatus() == FREE ) {  
            setStatus(piece);
            validMove = placeStoneOnBoard(p,piece);
            return validMove;
        }

       if ( board[x][y] != FREE ) return false;

         int count, countOp;
        for (int dx=-1; dx < 2; dx++)
            for (int dy=-1; dy < 1; dy++) {
                count = countOp = 1;
                if ( dy!=0 || dx==-1 ) {
                    while ( board[x+count*dx][y+count*dy] == piece ) count++;
                    while ( board[x-countOp*dx][y-countOp*dy] == piece ) countOp++;
                    countOp--;
                }
                if ( count + countOp >= 5 ) {
                	checkGameOver(x,y,dx,dy,piece);
                    piece += 4;
                }
            }
        if (validMove) {
        	validMove = placeStoneOnBoard(p,piece);
            if (getStatus() < FREE) setStatus(piece);
            if (getFreeSpaces()==0) setStatus(GAMEOVER); //game ending without winner
        }

        return validMove;
    }
    
    
    
    /**
     * Gets the number of free freeSpaces of this board.
     * @return  Number of free spaces.
     */
    protected int getFreeSpaces() {
        return freeSpaces;
    }

	/**
     * Sets a stone on the game board
     * @param   position p 
     * @param   stone to place 
     * @return  true if success
     */
    protected boolean placeStoneOnBoard(final PlayerPosition p, final int piece) {
        boolean validMove = false;       //return value
        final int col = p.getColumn();    //Column position of p
        final int row = p.getRow();    //Row position of p
        if ( col<=totalColumns && row<=getTotalRows() && col>0 && row>0  ) {
            // set stone on the board:
            board[col][row] = piece;
            // vertical marker
            board[col][0] = (int)(board[col][0] | 1);
            // horizontal marker
            board[0][row] = (int)(board[0][row] | 2);
            // diagonal marker
            if ( row-col >= 0 )
                board[0][row-col+1] = (int)(board[0][row-col+1] | 4);
            else
                board[col-row+1][0] = (int)(board[col-row+1][0] | 4);
            // Diagonal Up marker
            if ( col+row-1 <= getTotalRows() ) 
                board[0][col+row-1] = (int)(board[0][col+row-1] | 8);
            else
                board[col+row-getTotalRows()][0] = (int)(board[col+row-getTotalRows()][0] | 8);
            // update freeSpaces:
            freeSpaces--;

            validMove = true;
        }
        return validMove;
    }
    
    
    
    //	check if  last move finishes game
    private void checkGameOver(int i, int j, int stepi, int stepy, int stone) {
        int k=1; //first count
        int z=1; //second count
        while ( board[i+k*stepi][j+k*stepy] == stone ) {
            board[i+k*stepi][j+k*stepy] += 4;
            k++;
        }
        while ( board[i-z*stepi][j-z*stepy] == stone ) {
            board[i-z*stepi][j-z*stepy] += 4;
            z++;
        }
        
    }
    
 
    //general status of the game
    public int getStatus() {
        return (int)(board[0][0]-32);  //return the first cell of the frame (32 at the beginning) to GUI.refreshboard -> refreshStatus
    }
    
    /**
     * Gets the game status.
     * @param     free to be set
     */
    private void setStatus(int free) {
        board[0][0]=(int)(free|VALID);
    }


    //get a list of all full positions
    protected PlayerPosition[] getFullList() {
        int counter=0;
        PlayerPosition[] retPosition;
        PlayerPosition[] retHelp = new PlayerPosition[totalColumns*getTotalRows()];
        for ( int col=1; col<=totalColumns; col++){
            // > VALID means the column exists and is not empty:
            if ( board[col][0] > VALID ) 
                for ( int row=1; row<=getTotalRows(); row++ )
                    // < FREE means the field is occupied:
                    if ( board[col][row] < FREE ) 
                        retHelp[counter++] = new PlayerPosition(col,row);  //count how many cells are full
        }
        if ( counter > 0 ) {
        	retPosition = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,retPosition,0,counter);
            return retPosition;
        }
        return null;
    }
    
    /**
     * Row, column position
     * @param   position 
     * @return  All free player positions
     */
    protected PlayerPosition[] getFreeRound(final PlayerPosition p) {
        final int col = p.getColumn();   // coordinate col of p
        final int row = p.getRow();   // coordinate row of p
        int i,j,counter=0;
        int[] column;      // column of board to check
        PlayerPosition[] ret;     // return value
        PlayerPosition[] retHelp = new PlayerPosition[8];   // help variable for return value  //4 PLAYER_A, 4 PLAYER_B max
        // check the values around p:
        for ( i=-1; i<2 ; i++ ) {
            if ( col+i > 0 && col+i <= totalColumns ) {
                column = board[col+i];
                for ( j=-1; j<2 ; j++ )
                    // row +j can be out of board but in this case column[y+j]!=FREE
                    if ( column[row+j]==FREE ) retHelp[counter++] = new PlayerPosition(col+i,row+j);
            }
        }
        if ( counter > 0 ) {
            ret = new PlayerPosition[counter];
            System.arraycopy(retHelp,0,ret,0,counter);
            return ret;
        }
        // no freeSpaces around p
        return null;
    }

//get row
    protected int[] getRow( PlayerPosition p ) {
        return getRow( getRowNum(p) );
    }
    
//get row that has a stone
    protected int getRowNum(final PlayerPosition p) {
        return p.getRow();
    }
    

//get all rows that has a stone
    protected int[] getRow(int row ) {
        int[] retPosition;
        if ( row > 0 | row<=getTotalRows() ) {
            // if the row is not empty
            if ( (board[0][row] & 2) > 0 ) {
                int[] help = new int[totalColumns+2];
                for ( int col=0; col < help.length; col++)
                    help[col] = board[col][row];
                retPosition = help;
            } else {
            	retPosition = EMPTY;
            }
        } else {
        	retPosition = NOTEXIST;
        }
        return retPosition;
    } 

//get array of all columns that have a stone
    protected int[] getColumn(final int col) {
        int[] retPosition;
        if ( col > 0 && col<=totalColumns ) {
        	 if ( (Arrays.asList(board[col][0]).contains(0))  ) {
        		 retPosition = board[col];  //return the column
            } else {
            	retPosition = EMPTY;
            }
        } else {
        	retPosition = NOTEXIST;
        }
        return retPosition;
    }

    
//get a list of columns that have a stone
    protected int[] getColumn(final PlayerPosition p) {
        return getColumn(getColumnNum(p));
    }
 
//get column number that has a stone
    protected int getColumnNum(final PlayerPosition p) {
        return p.getColumn();
    }
    
    
//	get diagonal that has a stone
    protected int[] getDiagUp(final PlayerPosition p) {
        return getDiagUp(getDiagUpNum(p));
    }
    
//get the diagonal number that has a stone
    protected int getDiagUpNum(final PlayerPosition p) {
        return p.getColumn()+p.getRow()-1;
    }

//get array list of diagonal numbers
//dNumber is the diagonal number
     
    protected int[] getDiagUp( int dNumber) {
        int[] help;
        int[] ret = NOTEXIST;
        // check if c is valid:
        if ( dNumber > 0 &&  dNumber < getTotalRows()+totalColumns ) {
            if (dNumber <= getTotalRows()) {
                 if ( (board[0][dNumber] & 8) > 0 ) {
                    if ( dNumber <= totalColumns ) {
                        help = new int[dNumber+2];
                    } else {
                        help = new int[totalColumns+2];
                    }
                    for ( int i=1; i <= help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[i][dNumber-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            } else {
                if ( (board[dNumber-getTotalRows()+1][0] & 8) > 0 ) {
                    if ( dNumber <= totalColumns ) {
                        help = new int[getTotalRows()+2];
                    } else {
                        help = new int[totalColumns+getTotalRows()-dNumber+2];
                    }
                    for ( int i=1; i < help.length-1; i++)
                        // copies the pieces into the help array
                        help[i] = board[dNumber-getTotalRows()+i][getTotalRows()-i+1];
                    ret = help;
                } else {
                    ret = EMPTY;
                }
            }
        }
        return ret;
    }


    
    
// Get diagonal down which contain position
    protected int[] getDiagDown(final PlayerPosition pos) {
        return getDiagDown(getDiagDownNum(pos));
    }
    
// Gets the number of the diagonal Down which contain position
    protected int getDiagDownNum(final PlayerPosition pos) {
        return getTotalRows()-pos.getRow()+pos.getColumn();
    }

    
// Get the diagonal down with number dDiagNum

    protected int[] getDiagDown( int dDiagNum ) {
        int[] help;
        int[] retPosition;
        if ( dDiagNum > 0 | dDiagNum < getTotalRows()+totalColumns ) {
            if (dDiagNum <= getTotalRows()) {
                // if there are pieces on the diagonal
                if ( (board[0][getTotalRows()-dDiagNum+1] & 4) > 0 ) {
                    // create help with proper length
                    if ( dDiagNum <= totalColumns ) {
                        help = new int[dDiagNum+2];
                    } else {
                        help = new int[totalColumns+2];
                    }
                    for ( int col=1; col < help.length-1; col++)
                        // set help array
                        help[col] = board[col][getTotalRows()-dDiagNum+col];
                    retPosition = help;
                } else {
                	retPosition = EMPTY;
                }
            } else {
                // if there are pieces on the diagonal
                if ( (board[dDiagNum-getTotalRows()+1][0] & 4) > 0 ) {
                    // create help with proper length
                    if (dDiagNum <= totalColumns ) {
                        help = new int[getTotalRows()+2];
                    } else {
                        help = new int[getTotalRows()+totalColumns-dDiagNum+2];
                    }
                    for ( int col=1; col < help.length-1; col++)
                        // set help array
                        help[col] = board[dDiagNum-getTotalRows()+col][col];
                    retPosition = help;
                } else {
                	retPosition = EMPTY;
                }
            }
        } else {

        	retPosition = NOTEXIST;
        }
        return retPosition;
    }
        
// Get stone for position pos

    protected int getStone(final PlayerPosition pos) {
        return board[pos.getColumn()][pos.getRow()];
    }
    
}
