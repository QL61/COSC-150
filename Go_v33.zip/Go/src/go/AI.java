package go;

/**
 * AI.java
 */

//AI Class

/**
 * AI implements the AI and Alpha-Beta algorithms to play GameBoard
 * It creates a GomokuStrategy array
 * GS[1] evaluates the best move
 * GS[2] evaluates the following move if the move is made as per GS[1]
 * GS[3] evaluates the following move if the move is made as per GS[2] 
 * GS[i] evaluates the following move if the move is made as per GS[i-1] 
 */
public class AI  {
	
	
	static final int PLAYER_B = 1;       //piece PLAYER_B
    static final int FREE = 3;          //a free place on the board
	static final int INFINIT = 999999;
	
	private int player;
	
	protected void setPlayer(int p){
		player=p;
	}
	
	
    private GomokuStrategy[] GS;    //think depth +1 GomokuStrategy structures are needed
    private int TD;             //actual think level
    private boolean foundBest=false; //found a move where the player wins?
    
    /** 
     * Creates a new instance of AI
     * @param e    initial GomokuStrategy structure
     */
    public AI(final GomokuStrategy e) {
        //array of Evaluations for the next potential game states ("think levels")
        GS = new GomokuStrategy[e.maxTD+1];    	
        for (int i=0; i<GS.length;i++) {
            GS[i] = new GomokuStrategy(e);
           GS[i].TDPlayer = player;
        }
        TD = 0;
    }
        
        
    
    /**
     * calculates the AI and alpha-beta algorithms 
     * @return  best position for the next move
     */
    public PlayerPosition getNextMove() {
        // if this is the first move, than give back a middle position
        if (GS[TD].board.getStatus() == FREE) {
            return new PlayerPosition(7,7);
        }
        for (int i=0; i<GS[TD].sortedAvailableFields.size() ; i++){
            // calculate for all valid free position
            GS[TD].move = ((PlayerPosition) GS[TD].sortedAvailableFields.get(i));
            calcMoveValue(); //recursion - calculate the next think level
            // returned value (of the next think level) is the value for this move
            GS[TD].sortedAvailableFields.setIndex(GS[TD].move.positionValue(), GS[TD+1].value);
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>1000) foundBest=true;
            if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
            if ((GS[TD+1].value*(1-2*GS[1].TDPlayer))>1000) foundBest=true;
        }
        
        PlayerPosition nextPlayerPosition = new PlayerPosition();
        nextPlayerPosition = GS[TD].sortedAvailableFields.MaxMin(GS[TD].TDPlayer); //best move

        return nextPlayerPosition;
    }
    
    /**
     * calculates the AI and alpha-beta algorithms for think depth > 0
     */
    private void calcMoveValue() {
        TD++;
        GS[TD].copyEvaluation(GS[TD-1]); //Initialize GS
        GS[TD].sortedAvailableFields.remove(GS[TD].move); //remove actual move from free list
        GS[TD].simulateMove(); //set actual move into the board
        if (TD < GS[TD].maxTD) {
            for (int i=0; i<GS[TD].sortedAvailableFields.size() ; i++){
                // calculate for all valid free position
                GS[TD].move = ((PlayerPosition) GS[TD].sortedAvailableFields.get(i));
                calcMoveValue(); //recursion - calculate the next think level
                if ( GS[TD].TDPlayer == player ) {
                    if ( GS[TD+1].value > GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value > GS[TD].alpha ) GS[TD].alpha = GS[TD+1].value;
                } else {
                    if ( GS[TD+1].value < GS[TD].intValue ) GS[TD].intValue =  GS[TD+1].value;
                    if ( GS[TD+1].value < GS[TD].beta ) GS[TD].beta = GS[TD+1].value;
                }
                if ( GS[TD].beta < GS[TD].alpha ) {
                    break;
                }
            }
        }
        if ( GS[TD].intValue!=INFINIT && GS[TD].intValue!=-INFINIT) {
            GS[TD].value = GS[TD].intValue;
        }
        TD--;
    }
    
    /**
     * Calculates with think depth = 1 and give back a sorted array with the
     * best positions to the next move
     * @return  array with the best positions for the next move
     */
    public int[] getAscendOrder() {
        getNextMove();
        return GS[0].sortedAvailableFields.getAscendOrder(GS[0].TDPlayer);
    }
    
    /**
     * Displays values of some given positions.
     * This method is only for tests
     * @param   positions list to be checked
     * @return  to standard output the wanted values
     */
    public String valuesOf(final PlayerPosition[] p) {
        String ret = "";
        for (int i=0; i<p.length; i++)
            ret += p[i]+"\t"+GS[0].sortedAvailableFields.valueOf(p[i])+"\n";
        return ret;
    }
    


    //Check possible winner stones for next move PASS SERVER VALUES
    protected int[][] isNextMoveWinner(int stoneLastPlayedRow, int stoneLastPlayedColumn, int stoneMyColor, GameBoard g) {
    	//update the game board with the last move
    	//setBoard(stoneLastPlayedRow, stoneLastPlayedColumn, stoneColor);
    	//System.out.println("in serverBoard class isWinner method- after setting last stone to board - color, row, column  " + stoneMyColor + stoneLastPlayedRow + stoneLastPlayedColumn);
    	//static final int FREE_S = 3;          //a free place on the board
    	int FREE = 3; //erase later on if this is among static final constants above at the beginning of the class

    	//get color, row, and column of stone
    	int stoneColor = stoneMyColor;
    	int lastRow= stoneLastPlayedRow+1;
    	int lastColumn = stoneLastPlayedColumn+1;    	

    	//set stone row and column counters
    	int i = 0;
    	int j = 0;
    	int noWinSpace = 100;			//Later do this as a constant

    	//possible winner spaces array  
    	int[][] winnerSpaces = new int[64][2]; 

    	//reset winner spaces array. Maximum 64 next winner spaces from a single placed stone
    	for( i = 0; i<64; i++) {
    		for( j = 0; j<2; j++) {
    			winnerSpaces[i][j] = noWinSpace; 	
    		} 
    	}

    	int[][] myboard = g.board;

    	i = -1;
    	j = -1;

    	//-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// Begin vertical check in both directions
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------
    	if ((lastRow-1) > 0 && (lastRow+3) < 16){
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && 
    				myboard[lastColumn][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0]= lastRow-1;
    			winnerSpaces[i][1]= lastColumn;
    		}
    	}

    	if ((lastRow+4) < 16){
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && 
    				myboard[lastColumn][lastRow+4] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+4;
    			winnerSpaces[i][1]  = lastColumn;
    		}
    		
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && myboard[lastColumn][lastRow+4] == stoneColor && 
    				myboard[lastColumn][lastRow+2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+2;
    			winnerSpaces[i][1]  = lastColumn;
    		}
    		
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+4] == stoneColor && 
    				myboard[lastColumn][lastRow+3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+3;
    			winnerSpaces[i][1]  = lastColumn;
    		}
    	}
    	if (lastRow-3 > 0 && (lastRow+1) < 16){
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor &&
    				myboard[lastColumn][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-4) > 0){
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor &&
    				myboard[lastColumn][lastRow-4] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-4;
    			winnerSpaces[i][1] = lastColumn;
    		}
    		
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor && myboard[lastColumn][lastRow-4] == stoneColor &&
    				myboard[lastColumn][lastRow-2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-2;
    			winnerSpaces[i][1] = lastColumn;
    		}
    		
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow-4] == stoneColor &&
    				myboard[lastColumn][lastRow-3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-3;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-2) > 0 && (lastRow+2) < 16){
    		if (myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor &&
    				myboard[lastColumn][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn;
    		}
    		if (myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor &&
    				myboard[lastColumn][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn;
    		} 
    	}

    	if ((lastRow-3) > 0 && (lastRow+1) < 16){
    		if (myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor && myboard[lastColumn][lastRow+1] == stoneColor &&
    				myboard[lastColumn][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-1) > 0 && (lastRow+3) < 16){
    		if (myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && myboard[lastColumn][lastRow-1] == stoneColor &&
    				myboard[lastColumn][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-4) > 0){
    		if (myboard[lastColumn][lastRow-2] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor && myboard[lastColumn][lastRow-4] == stoneColor &&
    				myboard[lastColumn][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow+4) < 16){
    		if (myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && myboard[lastColumn][lastRow+4] == stoneColor &&
    				myboard[lastColumn][lastRow+1] == FREE){
    			//old if (myboard[lastColumn][lastRow+2] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor && myboard[lastColumn][lastRow+4] == stoneColor &&
    			//myboard[lastColumn][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn;
    		}	
    	}

    	if ((lastRow-1) > 0 && (lastRow+3) < 16){
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+3] == stoneColor &&
    				myboard[lastColumn][lastRow+2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+2;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-3) > 0 && (lastRow+1) < 16){
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-3] == stoneColor &&
    				myboard[lastColumn][lastRow-2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-2;
    			winnerSpaces[i][1] = lastColumn;
    		} 
    	}

    	if ((lastRow-1) > 0 && (lastRow+3) < 16){
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor &&
    				myboard[lastColumn][lastRow+3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+3;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-3) > 0 && (lastRow+1) < 16){
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor &&
    				myboard[lastColumn][lastRow-3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-3;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	if ((lastRow-2) > 0 && (lastRow+2) < 16){
    		if (myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow-2] == stoneColor &&
    				myboard[lastColumn][lastRow+2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+2;
    			winnerSpaces[i][1] = lastColumn;
    		}
    		if (myboard[lastColumn][lastRow-1] == stoneColor && myboard[lastColumn][lastRow+1] == stoneColor && myboard[lastColumn][lastRow+2] == stoneColor &&
    				myboard[lastColumn][lastRow-2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-2;
    			winnerSpaces[i][1] = lastColumn;
    		}
    	}

    	//-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// Begin horizontal check in both directions
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------

    	if ((lastColumn-1) > 0 && (lastColumn+3) < 16){
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor &&
    				myboard[lastColumn-1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-1;
    		}
    	}

    	if ((lastColumn+4) < 16){
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor &&
    				myboard[lastColumn+4][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+4;
    		}
    		
    		if (myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor && myboard[lastColumn+4][lastRow] == stoneColor &&
    				myboard[lastColumn+2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+2;
    		}
    		
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+4][lastRow] == stoneColor &&
    				myboard[lastColumn+3][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+3;
    		}
    	}

    	if (lastColumn-3 > 0 && (lastColumn+1) < 16){
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor &&
    				myboard[lastColumn+1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+1;
    		}
    	}

    	if ((lastColumn-4) > 0){
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor &&
    				myboard[lastColumn-4][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-4;
    		}
    		
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor && myboard[lastColumn-4][lastRow] == stoneColor &&
    				myboard[lastColumn-2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-2;
    		}
    		
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn-4][lastRow] == stoneColor &&
    				myboard[lastColumn-3][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-3;
    		}
    	}

    	if ((lastColumn-2) > 0 && (lastColumn+2) < 16){
    		if (myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor &&
    				myboard[lastColumn-1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-1;
    		}

    		if (myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor &&
    				myboard[lastColumn+1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+1;
    		} 
    	}

    	if ((lastColumn-3) > 0 && (lastColumn+1) < 16){
    		if (myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor && myboard[lastColumn+1][lastRow] == stoneColor &&
    				myboard[lastColumn-1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-1;
    		}
    	}

    	if ((lastColumn-1) > 0 && (lastColumn+3) < 16){
    		if (myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor && myboard[lastColumn-1][lastRow] == stoneColor &&
    				myboard[lastColumn+1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+1;
    		}
    	}

    	if ((lastColumn-4) > 0){
    		if (myboard[lastColumn-2][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor && myboard[lastColumn-4][lastRow] == stoneColor &&
    				myboard[lastColumn-1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-1;
    		}
    	}

    	if ((lastColumn+4) < 16){
    		if (myboard[lastColumn+2][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor && myboard[lastColumn+4][lastRow] == stoneColor &&
    				myboard[lastColumn+1][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+1;
    		}	 
    	}

    	if ((lastColumn-1) > 0 && (lastColumn+3) < 16){
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+3][lastRow] == stoneColor &&
    				myboard[lastColumn+2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+2;
    		}
    	}

    	if ((lastColumn-3) > 0 && (lastColumn+1) < 16){
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-3][lastRow] == stoneColor &&
    				myboard[lastColumn-2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-2;
    		} 
    	}

    	if ((lastColumn-1) > 0 && (lastColumn+3) < 16){  
    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor &&
    				myboard[lastColumn+3][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+3;
    		}
    	}

    	if ((lastColumn-3) > 0 && (lastColumn+1) < 16){ 
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor &&
    				myboard[lastColumn-3][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-3;
    		}
    	}

    	if ((lastColumn-2) > 0 && (lastColumn+2) < 16){
    		if (myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn-2][lastRow] == stoneColor &&
    				myboard[lastColumn+2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn+2;
    		}

    		if (myboard[lastColumn-1][lastRow] == stoneColor && myboard[lastColumn+1][lastRow] == stoneColor && myboard[lastColumn+2][lastRow] == stoneColor &&
    				myboard[lastColumn-2][lastRow] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow;
    			winnerSpaces[i][1] = lastColumn-2;
    		}
    	}

    	//-----------------------------------------------------------------------------------------------------------------------------------------------------
    	// Begin diagonal check for upwards left and downwards right in both directions
    	//-----------------------------------------------------------------------------------------------------------------------------------------------------
    	if ((lastRow-1) > 0 && (lastColumn-1) > 0 && (lastRow+3) < 16 && (lastColumn+3) < 16){
    		if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor &&
    				myboard[lastColumn-1][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn-1;
    		}		 
    	}

    	if ((lastRow+4) < 16 && (lastColumn+4) < 16){
    		if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor &&
    				myboard[lastColumn+4][lastRow+4] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+4;
    			winnerSpaces[i][1] = lastColumn+4;
    		}
    		
    		if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+4][lastRow+4] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor &&
    				myboard[lastColumn+2][lastRow+2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+2;
    			winnerSpaces[i][1] = lastColumn+2;
    		}
    		
    		if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn+4][lastRow+4] == stoneColor &&
    				myboard[lastColumn+3][lastRow+3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+3;
    			winnerSpaces[i][1] = lastColumn+3;
    		}
    	}

    	if ((lastRow-3) > 0 && (lastColumn-3) > 0 && (lastRow+1) < 16 && (lastColumn+1) < 16){
    		if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor &&
    				myboard[lastColumn+1][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn+1;
    		}
    	}

    	if ((lastRow-4) > 0 && (lastColumn-4) > 0){
    		if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor &&
    				myboard[lastColumn-4][lastRow-4] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-4;
    			winnerSpaces[i][1] = lastColumn-4;
    		}
    		
    		if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor && myboard[lastColumn-4][lastRow-4] == stoneColor &&
    				myboard[lastColumn-2][lastRow-2] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-2;
    			winnerSpaces[i][1] = lastColumn-2;
    		}
    		
    		if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn-4][lastRow-4] == stoneColor &&
    				myboard[lastColumn-3][lastRow-3] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-3;
    			winnerSpaces[i][1] = lastColumn-3;
    		}
    	}

    	if ((lastRow-2) > 0 && (lastColumn-2) > 0 && (lastRow+2) < 16 && (lastColumn+2) < 16){	 
    		if (myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor &&
    				myboard[lastColumn-1][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn-1;
    		}
    		if (myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor &&
    				myboard[lastColumn+1][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn+1;
    		} 
    	}

    	if ((lastRow-3) > 0 && (lastColumn-3) > 0 && (lastRow+1) < 16 && (lastColumn+1) < 16){
    		if (myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor && myboard[lastColumn+1][lastRow+1] == stoneColor &&
    				myboard[lastColumn-1][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn-1;
    		}
    	}

    	if ((lastRow-1) > 0 && (lastColumn-1) > 0 && (lastRow+3) < 16 && (lastColumn+3) < 16){
    		if (myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor && myboard[lastColumn-1][lastRow-1] == stoneColor &&
    				myboard[lastColumn+1][lastRow+1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow+1;
    			winnerSpaces[i][1] = lastColumn+1;
    		}
    	}

    	if ((lastRow-4) > 0 && (lastColumn-4) > 0){
    		if (myboard[lastColumn-2][lastRow-2] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor && myboard[lastColumn-4][lastRow-4] == stoneColor &&
    				myboard[lastColumn-1][lastRow-1] == FREE){
    			winnerSpaces[i=i+1][0] = lastRow-1;
    			winnerSpaces[i][1] = lastColumn-1;
    		}

    		if ((lastRow+4) < 16 && (lastColumn+4) < 16){
    			if (myboard[lastColumn+2][lastRow+2] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor && myboard[lastColumn+4][lastRow+4] == stoneColor &&
    					myboard[lastColumn+1][lastRow+1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+1;
    				winnerSpaces[i][1] = lastColumn+1;
    			}	 
    		}

    		if ((lastRow-1) > 0 && (lastColumn-1) > 0 && (lastRow+3) < 16 && (lastColumn+3) < 16){
    			if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+3][lastRow+3] == stoneColor &&
    					myboard[lastColumn+2][lastRow+2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+2;
    				winnerSpaces[i][1] = lastColumn+2;
    			}
    		}

    		if ((lastRow-3) > 0  && (lastColumn-3) > 0 && (lastRow+1) < 16 && (lastColumn+1) < 16){
    			if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-3][lastRow-3] == stoneColor &&
    					myboard[lastColumn-2][lastRow-2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-2;
    				winnerSpaces[i][1] = lastColumn-2;
    			}
    		}

    		if ((lastRow-1) > 0 && (lastColumn-1) > 0 && (lastRow+3) < 16 && (lastColumn+3) < 16){  
    			if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor &&
    					myboard[lastColumn+3][lastRow+3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+3;
    				winnerSpaces[i][1] = lastColumn+3;
    			}
    		}

    		if ((lastRow-3) > 0 && (lastColumn-3) > 0 && (lastRow+1) < 16 && (lastColumn+1) < 16){ 
    			if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor &&
    					myboard[lastColumn-3][lastRow-3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-3;
    				winnerSpaces[i][1] = lastColumn-3;
    			}
    		}

    		if ((lastRow-2) > 0 && (lastColumn-2) > 0 && (lastRow+2) < 16 && (lastColumn+2) < 16){
    			if (myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn-2][lastRow-2] == stoneColor &&
    					myboard[lastColumn+2][lastRow+2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+2;
    				winnerSpaces[i][1] = lastColumn+2;
    			}

    			if (myboard[lastColumn-1][lastRow-1] == stoneColor && myboard[lastColumn+1][lastRow+1] == stoneColor && myboard[lastColumn+2][lastRow+2] == stoneColor &&
    					myboard[lastColumn-2][lastRow-2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-2;
    				winnerSpaces[i][1] = lastColumn-2;
    			} 
    		}


    		//-----------------------------------------------------------------------------------------------------------------------------------------------------
    		// Begin diagonal check for upwards right and downwards left in both directions
    		//-----------------------------------------------------------------------------------------------------------------------------------------------------
    		if ((lastRow-1) > 0 && (lastColumn+1) < 16 && (lastRow+3) < 16 && (lastColumn-3) > 0){
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor &&
    					myboard[lastColumn+1][lastRow-1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-1;
    				winnerSpaces[i][1] = lastColumn+1;
    			}
    		}

    		if ((lastRow+4) < 16 && (lastColumn-4)  > 0){
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor &&
    					myboard[lastColumn-4][lastRow+4] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+4;
    				winnerSpaces[i][1] = lastColumn-4;
    			}
    			
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-4][lastRow+4] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor &&
    					myboard[lastColumn-2][lastRow+2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+2;
    				winnerSpaces[i][1] = lastColumn-2;
    			}
    			
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn-4][lastRow+4] == stoneColor &&
    					myboard[lastColumn-3][lastRow+3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+3;
    				winnerSpaces[i][1] = lastColumn-3;
    			}
    		}

    		if ((lastRow-4) > 0 && (lastColumn+4) < 16){
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor &&
    					myboard[lastColumn+4][lastRow-4] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-4;
    				winnerSpaces[i][1] = lastColumn+4;
    			}
    			
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+4][lastRow-4] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor &&
    					myboard[lastColumn+2][lastRow-2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-2;
    				winnerSpaces[i][1] = lastColumn+2;
    			}
    			
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn+4][lastRow-4] == stoneColor &&
    					myboard[lastColumn+3][lastRow-3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-3;
    				winnerSpaces[i][1] = lastColumn+3;
    			}
    		}

    		if ((lastRow+1) < 16 && (lastColumn-1) > 0 && (lastRow-3) > 0 && (lastColumn+3) < 16 ){
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor &&
    					myboard[lastColumn-1][lastRow+1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+1;
    				winnerSpaces[i][1] = lastColumn-1;
    			}
    		}

    		if ((lastRow-2) > 0 && (lastColumn+2) < 16 && (lastRow+2) < 16 && (lastColumn-2) > 0){	
    			if (myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor &&
    					myboard[lastColumn+1][lastRow-1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-1;
    				winnerSpaces[i][1] = lastColumn+1;
    			}
    			if (myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor &&
    					myboard[lastColumn-1][lastRow+1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+1;
    				winnerSpaces[i][1] = lastColumn-1;
    			}
    		}

    		if ((lastRow-3) > 0 && (lastColumn+3) < 16 && (lastRow+1) < 16 && (lastColumn-1) > 0){
    			if (myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor && myboard[lastColumn-1][lastRow+1] == stoneColor &&
    					myboard[lastColumn+1][lastRow-1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-1;
    				winnerSpaces[i][1] = lastColumn+1;
    			}
    		}

    		if ((lastRow-1) > 0 && (lastColumn+1) < 16 && (lastRow+3) < 16 && (lastColumn-3) > 0){
    			if (myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor && myboard[lastColumn+1][lastRow-1] == stoneColor &&
    					myboard[lastColumn-1][lastRow+1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+1;
    				winnerSpaces[i][1] = lastColumn-1;
    			}
    		}

    		if ((lastRow-4) > 0 && (lastColumn+4) < 16 ){
    			if (myboard[lastColumn+2][lastRow-2] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor && myboard[lastColumn+4][lastRow-4] == stoneColor &&
    					myboard[lastColumn+1][lastRow-1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-1;
    				winnerSpaces[i][1] = lastColumn+1;
    			}
    		}

    		if ((lastRow+4) < 16 && (lastColumn-4)  > 0){
    			if (myboard[lastColumn-2][lastRow+2] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor && myboard[lastColumn-4][lastRow+4] == stoneColor &&
    					myboard[lastColumn-1][lastRow+1] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+1;
    				winnerSpaces[i][1] = lastColumn-1;
    			}
    		}

    		if ((lastRow-1) > 0 && (lastColumn+1) < 16 && (lastRow+3) < 16 && (lastColumn-3) > 0){
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-3][lastRow+3] == stoneColor &&
    					myboard[lastColumn-2][lastRow+2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+2;
    				winnerSpaces[i][1] = lastColumn-2;
    			}
    		}

    		if ((lastRow-3) > 0 && (lastColumn+3) < 16 && (lastRow+1) < 16 && (lastColumn-1) > 0){
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+3][lastRow-3] == stoneColor &&
    					myboard[lastColumn+2][lastRow-2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-2;
    				winnerSpaces[i][1] = lastColumn+2;
    			} 
    		}

    		if ((lastRow-1) > 0 && (lastColumn+1) < 16 && (lastRow+3) < 16 && (lastColumn-3) > 0){
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor &&
    					myboard[lastColumn-3][lastRow+3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+3;
    				winnerSpaces[i][1] = lastColumn-3;
    			}
    		}

    		if ((lastRow-3) > 0 && (lastColumn+3) < 16 && (lastRow+1) < 16 && (lastColumn-1) > 0){
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor &&
    					myboard[lastColumn+3][lastRow-3] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-3;
    				winnerSpaces[i][1] = lastColumn+3;
    			}
    		}

    		if ((lastRow-2) > 0 && (lastColumn+2) < 16 && (lastRow+2) < 16 && (lastColumn-2) > 0){
    			if (myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn+2][lastRow-2] == stoneColor &&
    					myboard[lastColumn-2][lastRow+2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow+2;
    				winnerSpaces[i][1] = lastColumn-2;
    			}
    			if (myboard[lastColumn+1][lastRow-1] == stoneColor && myboard[lastColumn-1][lastRow+1] == stoneColor && myboard[lastColumn-2][lastRow+2] == stoneColor &&
    					myboard[lastColumn+2][lastRow-2] == FREE){
    				winnerSpaces[i=i+1][0] = lastRow-2;
    				winnerSpaces[i][1] = lastColumn+2;
    			}
    		}

    		//return winner spaces array

    	}//end isNextMoveWinner method

    	//Erase later
    	if (winnerSpaces[0][0] != 100) {
    		System.out.println("AI class isNextMoveWinner  method array first row values - row: " + winnerSpaces[0][0] 
    				+ " column: " + winnerSpaces[0][1] +  " stone color: " + stoneColor);
    		System.out.println("AI class isNextMoveWinner  method array next row values - row: " + winnerSpaces[1][0] 
    				+ " column: " + winnerSpaces[1][1]   +  " stone color: " + stoneColor);
    	}

    	return winnerSpaces;
    }


}
