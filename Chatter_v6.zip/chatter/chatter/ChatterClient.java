package chatter;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;


public class ChatterClient {
	
	public String username;
	public ArrayList<String> nameList = new ArrayList<String>();
	
	private int port;
	private String ip;
	private Socket sock;
	private ObjectOutputStream oOut;
	private ObjectInputStream oIn;
	
	private ArrayList<ChatterMessage> allHistory = new ArrayList<ChatterMessage>();
	private ClientGUI cGUI;
	
	private boolean keepGoing = true;

	public static void main(String[] args) {
		String serverAddress = "localhost";
		int portNumber = 55305;
		new ClientGUI(serverAddress, portNumber);
	}

	public ChatterClient(String server, int portNumber, String name, ClientGUI cg) {
		this.ip = server;
		this.port = portNumber;
		this.username = name;
		this.cGUI = cg;
	}
	
	public boolean start() {
		System.out.println("chat client starting ...");
		keepGoing = true; 

		try
		{
			System.out.println("about to try to call 'localhost' / " + port);

			sock = new Socket("localhost", port);

			oOut = new ObjectOutputStream(sock.getOutputStream());
			System.out.println("setting username: " + cGUI.getUsername());
			setUsername(cGUI.getUsername());
			oOut.flush();
			oIn = new ObjectInputStream(sock.getInputStream());


			System.out.println("creating listen thread");
			Thread listenThread = new Thread(new Listen());
			listenThread.start();
		}
		catch ( IOException ioe ) { 
			System.err.println("caught in ChatterClient(): " + ioe + " from ");
			ioe.printStackTrace();
		}
		
		return true;
	}

	public void setUsername(String newName) {
		Map<String, String> nameInfo = new HashMap<String, String>();
		nameInfo.put("type", "name change");
		nameInfo.put("sender", username);
		nameInfo.put("recipient", username);
		nameInfo.put("message", newName);
		ChatterMessage nameCM = new ChatterMessage(nameInfo);
		try {
			oOut.writeObject(nameCM);
			oOut.flush();
		}
		catch(IOException ioe) { 
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}

	public ArrayList<ChatterMessage> getAllHistoryList() {
		return allHistory;
	}
	
	class Listen implements Runnable {
		@Override
		public void run() {
			System.out.println("Listen running...");

			try {
				while (keepGoing) {
						System.out.println("reading from oIn");
						Object readObj = oIn.readObject();
						if (readObj instanceof SArray) {
							System.out.println("received updated name list");
							SArray sa = (SArray) readObj;
							if (nameList != null) {
								for (int i = nameList.size()-1; i > -1; i--) {
									System.out.println("former name: " + nameList.get(i));
									nameList.remove(i);
								}
							}
							for (int i = 0; i < sa.getAL().size(); i++) {
								System.out.println("new name: " + sa.getAL().get(i));
								nameList.add(sa.getAL().get(i));
							}
						}
						else if (readObj instanceof ChatterMessage) {
							ChatterMessage cm = (ChatterMessage) readObj;
							allHistory.add(cm);
							cGUI.printChatHistory();
						}
				} // END while
			} // END try 
			catch(ClassNotFoundException cnfe) {
				System.err.println("caught: " + cnfe + " from ");
				cnfe.printStackTrace();
			} // END catch 
			catch (IOException ioe) {
				System.err.println("caught: " + ioe + " from ");
				ioe.printStackTrace();
			} // END catch
		} // END public void run()
	} // END class Listen
	
	public void sendMessage(Map<String, String> info) {
		try {
			ChatterMessage cm = new ChatterMessage(info);
			oOut.writeObject(cm);
			oOut.flush();
		}
		catch (IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}	
	}
	
	public ArrayList<String> getNameList() {
		return nameList;
	}
	
	public void disconnect() {
		try {
			if (oIn != null) { oIn.close();	}
			if (oOut != null) { oOut.close(); }
			if (sock != null) { sock.close(); }
			if (cGUI != null) { cGUI.connectionFailed(); }
		}
		catch(IOException ioe) {
			System.err.println("caught: " + ioe + " from ");
			ioe.printStackTrace();
		}
	}
//
//	class Write implements Runnable { // TODO delete?
//		@Override
//		synchronized public void run() {
//			System.out.println("Write running...");
//
//			try {			
//				Scanner scan = new Scanner(System.in);
//				while(keepGoing) {
//					String userInput = scan.nextLine();
//					if (userInput != null)
//					{
//						Map<String, String> cmInfo = new HashMap<String, String>();
//						cmInfo.put("type", "public"); // TODO link to GUI
//						cmInfo.put("sender", username);
//						cmInfo.put("recipient", "all"); // TODO link to GUI
//						cmInfo.put("message", userInput);
//						System.out.println("creating CM w/ public " + username + " all " + userInput);
//						ChatterMessage cm = new ChatterMessage(cmInfo);
//						System.out.println("writing CM");
//						oOut.writeObject(cm);
//						oOut.flush();
//					} // END if
//				} // END while
//				scan.close();
//			} // END try
//			catch (IOException ioe) {
//				System.err.println("caught: " + ioe + " from ");
//				ioe.printStackTrace();
//			} // END catch
//		} // END public void run()
//	} // END class Write


} // END public class ChatterClient