package chatter;

import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class ChatterServer
{
	private ServerSocket sock;
	private boolean keepGoing = true;
	public int publicPort = 55305;
	private ArrayList<ClientThread> clientList = new ArrayList<ClientThread>();
	private ArrayList<String> clientNameList = new ArrayList<String>();

	public static void main( String[] args ) //throws IOException
	{
		new ChatterServer();
	}

	public ChatterServer()
	{
		System.out.println("chat server starting ...");
		try
		{
			sock = new ServerSocket(publicPort); // open socket

			while (keepGoing)
			{
				// listen for connections
				Socket client = sock.accept(); // this blocks until a client calls      
				System.out.println("ChatterServer: accepts client connection ");

				ClientThread threadToAdd = new ClientThread(client);
				System.out.println("adding ClientThread to ArrayList");
				clientList.add(threadToAdd);
				System.out.println("starting ClientThread");
				threadToAdd.start();

			}

			sock.close();
		}
		catch( Exception e ) { 
			System.err.println("Caught in ChatServer(): " + e +" from ");
			e.printStackTrace();
		}      
		System.exit(0);
	}

	class ClientThread extends Thread {

		public Socket sock;
		public String username = "";
		public String welcomeMessage = "Welcome to Chatter. Messages from other users will appear below. "
				+ "Select a username from the drop-down menu on the top right to begin a private chat with another user.\n";

		protected ObjectInputStream oIn;
		protected ObjectOutputStream oOut;
		protected boolean keepGoing = true;

		ClientThread(Socket s) {
			System.out.println("ClientThread constructor executing");
			sock = s;
			try {
				oOut = new ObjectOutputStream(sock.getOutputStream());
				oOut.writeObject(new ChatterMessage("public", "SERVER", "all", welcomeMessage));
				oOut.flush();
				oIn = new ObjectInputStream(sock.getInputStream());
			}
			catch(IOException ioe) {
				System.err.println("Caught in ClientThread constructor: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}

		@Override
		public void run() {
			System.out.println("ClientThread running...");
			try {
				while (keepGoing) {
						ChatterMessage cm = (ChatterMessage) oIn.readObject();
						System.out.println("received a message: '" + cm.getMessage() + "'");
						System.out.println("message type: " + cm.getMessageType());
						if (cm.getMessageType().equalsIgnoreCase("name change")) {
							changeName(cm.getMessage());
						}
						
						else { sendOut(cm); }
				}
			}
			catch (IOException ioe) {
				System.err.println("Caught in ClientThread.run: " + ioe + " from ");
				ioe.printStackTrace();
			} catch (ClassNotFoundException cnfe) {
				System.err.println("Caught in ClientThread.run: " + cnfe + " from ");
				cnfe.printStackTrace();
			}
		}
	
		public void changeName(String newName) {
			System.out.println("\tchanging username");
			
			boolean nameFound = false;
			for (int i = 0; (i < clientNameList.size()) && (!nameFound); i++) {
				if (clientNameList.get(i).equals(this.username)) {
					clientNameList.remove(i);
					nameFound = true;
				}
			}
			this.username = newName;
			clientNameList.add(this.username);
			updateNameList();
		}
		
		public void updateNameList() {
			try {
				for (int i = 0; i < clientList.size(); i++) {
					System.out.println("\tsending to " + clientList.get(i).username);
					for (int j = 0; j < clientNameList.size(); j++) {
						System.out.println(clientNameList.get(j));
					}
					SArray toSend = new SArray(clientNameList);
					clientList.get(i).oOut.writeObject(toSend); // Demeter violation, but using
					clientList.get(i).oOut.flush(); 					// fairly dependable objects
				}
			}
			catch(IOException ioe) {
				System.err.println("Caught: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
		
		public synchronized void sendOut(ChatterMessage cm) {
			try {
				System.out.println("sending out a message: '" + cm.getMessage() + "'");
				if (cm.getMessageType().equalsIgnoreCase("public")) {
					System.out.println("\tdetermined that message is public");
					for (int i = 0; i < clientList.size(); i++) {
						System.out.println("\tsending to " + clientList.get(i).username);
						clientList.get(i).oOut.writeObject(cm); // Demeter violation, but using
						clientList.get(i).oOut.flush(); 		// fairly dependable objects
					}
				}
				else {
					System.out.println("\tdetermined that message is private");
					for (int i = 0; i < clientList.size(); i++) {
						if ((clientList.get(i).username.equals(cm.getRecipient()))
								|| (clientList.get(i).username.equals(cm.getSender()))) {
							System.out.println("\tsending to " + clientList.get(i).username);
							clientList.get(i).oOut.writeObject(cm); // Demeter violation, but using
							clientList.get(i).oOut.flush(); 		// fairly dependable objects
						}
					}
				}
			}
			catch(IOException ioe) {
				System.err.println("Caught in ClientThread.run: " + ioe + " from ");
				ioe.printStackTrace();
			}
		}
	}

}