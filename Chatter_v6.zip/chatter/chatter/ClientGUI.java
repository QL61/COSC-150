package chatter;

import javax.swing.*;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/*
 * The Client with its GUI
 */
public class ClientGUI extends JFrame implements ActionListener, KeyListener{

	private static final long serialVersionUID = 1L;
	private static final String WELCOME_TO_CHAT = "Welcome to the Chatroom";
	private static final String TYPE_CHAT_MSG = "Type Chat Message Here";
	private JLabel usernamelabel;							// to hold label to ask for username
	private JTextField username;							// to hold current username
	private String oldUsername;											////////////////////////////////////////chekc thiss shit out
	private JTextField tfServer, tfPort;					// to write the server address and port number
	private JButton loginBtn, sendBtn, exitBtn;	// buttons
	private JComboBox usernameList; 						// to see list of all people
	private JTextArea taMsgHistory;							// to see message history
	private JTextArea taMessenger;							// for person to type
	private boolean connected;								// if it is for connection
	private int defaultPort;								// the default port number
	private String defaultIP;								// the default host
	private ChatterClient client;
	
	// to start the whole thing the server
	public static void main(String[] args) {
		new ClientGUI("localhost", 55305);
	}
	
	
	// Constructor connection receiving a socket number
	ClientGUI(String host, int port) {		
		super("Chat Client");
		defaultPort = port;
		defaultIP = host;

		System.out.println("inside clientGUI constructor");
		
		// The NorthPanel with:
		JPanel northPanel = new JPanel(new GridLayout(3,2)); // the server name and port number
		JPanel serverAddress = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for server address
		JPanel portNumber = new JPanel(new GridLayout(1, 2)); // the JTextField with default value for port number
		tfServer = new JTextField(host);
		tfPort = new JTextField("" + port);
		tfPort.setHorizontalAlignment(SwingConstants.RIGHT);

		serverAddress.add(new JLabel("Server Address:  "));
		serverAddress.add(tfServer);
		portNumber.add(new JLabel("Port Number:  "));
		portNumber.add(tfPort);
		// adds the Server an port field to the GUI
		northPanel.add(serverAddress, BorderLayout.NORTH);
		northPanel.add(portNumber, BorderLayout.NORTH);

		// the Label and the TextField
		usernamelabel = new JLabel("Enter your username below", SwingConstants.CENTER);
		northPanel.add(usernamelabel, BorderLayout.LINE_START);
		northPanel.add(new JLabel(""));
		username = new JTextField("Anonymous");
		username.setBackground(Color.WHITE);
		northPanel.add(username, BorderLayout.SOUTH);

		// username list creation
		PopupMenuListener pmListener = new PopupMenuListener() {
			boolean initialized = false;

			@Override
			public void popupMenuCanceled(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				String[] initList = {"Group"};
				if (!initialized) {
					usernameList = (JComboBox) e.getSource();
					ComboBoxModel model = new DefaultComboBoxModel(initList);
					usernameList.setModel(model);
					initialized = true;
				}
				else {
					System.out.println("should remove " + usernameList.getItemCount() + " -1 items");
					
					for (int i = usernameList.getItemCount()-1; i > 0; i--) {
						System.out.println("will remove " + usernameList.getItemAt(i));

						usernameList.removeItemAt(i);
					}
					for (int i = 0; i < client.getNameList().size(); i++) {
						System.out.println("adding " + client.getNameList().get(i));
						usernameList.addItem(client.getNameList().get(i));
					}
				}
			}
		};
		usernameList = new JComboBox();
		usernameList.addItem("Group");
		usernameList.setSelectedItem("Group");
		usernameList.addPopupMenuListener(pmListener);
		usernameList.addActionListener(this);
		usernameList.setEnabled(false);
		northPanel.add(usernameList, BorderLayout.SOUTH);
		//add to frame
		add(northPanel, BorderLayout.NORTH);

		// The CenterPanel which is the chat room
		taMsgHistory = new JTextArea(WELCOME_TO_CHAT, 80, 80);
		JPanel centerPanel = new JPanel(new GridLayout(1,1));
		centerPanel.add(new JScrollPane(taMsgHistory));
		taMsgHistory.setEditable(false);

		// The MessagerPanel where one can type
		taMessenger = new JTextArea(TYPE_CHAT_MSG);
		taMessenger.setBackground(Color.WHITE);
		taMessenger.setEditable(false);
		taMessenger.addKeyListener(this);
		centerPanel.add(taMessenger);
		add(centerPanel, BorderLayout.CENTER);
		
		// button creation
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(this);
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		exitBtn.setEnabled(false);		// you have to login before being able to exit
		sendBtn = new JButton("Send");
		sendBtn.addActionListener(this);
		sendBtn.setEnabled(false);

		JPanel southPanel = new JPanel();
		southPanel.add(loginBtn);
		southPanel.add(exitBtn);
		southPanel.add(sendBtn);
		add(southPanel, BorderLayout.SOUTH);
		
		//set the word wrap of message history and Messenger
		taMessenger.setWrapStyleWord(true);
		taMessenger.setLineWrap(true);
		taMsgHistory.setWrapStyleWord(true);
		taMsgHistory.setLineWrap(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(750, 500);
		setVisible(true);
		taMessenger.requestFocus();
	}

	// called by the GUI is the connection failed
	// we reset our buttons, label, textfield
	void connectionFailed() {
		loginBtn.setEnabled(true);
		exitBtn.setEnabled(false);
		usernamelabel.setText("Enter your username below");
		username.setText("Anonymous");
		// reset port number and host name as a construction time
		tfPort.setText("" + defaultPort);
		tfServer.setText(defaultIP);
		// let the user change them
		tfServer.setEditable(false);
		tfPort.setEditable(false);
		// don't react to a <CR> after the username
		username.removeActionListener(this);
		connected = false;
	}

	/*
	 * for enter key being pressed
	 */
	public void keyPressed(KeyEvent e) {
		if(sendBtn.isEnabled()) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER){
				sendBtn.doClick();
			}
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) taMessenger.setText("");
	}
	
	/*
	 * Button or JTextField clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// check for which button is pressed
		if(e.getSource() == exitBtn) {
//			client.sendPrivateMessage(new ChatMessage(ChatMessage.LOGOUT, ""));
			return;
		}
		else if (e.getSource() == sendBtn) {
			System.out.println("click was sendBtn:: in sendBtn:: ");
			
			String msg = taMessenger.getText() + "\n\n";
			String messageType;
			
			if (taMsgHistory.getText().equals(WELCOME_TO_CHAT)) {
				taMsgHistory.setText("");
			}
			
			if (((String) usernameList.getSelectedItem()).equalsIgnoreCase("group")) {
				messageType = "public";
			}
			else {
				messageType = "private";
			}
			
			Map<String, String> messageInfo = new HashMap<String, String>();
			messageInfo.put("type", messageType);
			messageInfo.put("sender", this.username.getText());
			messageInfo.put("recipient", (String) usernameList.getSelectedItem());
			messageInfo.put("message", msg);
			
//			usernameList.removeAllItems();
//			usernameList.addItem("Group");
//			for (int i = 0; i < client.getNameList().size(); i++) {
//				usernameList.addItem(client.getNameList().get(i));
//			}
			
			client.sendMessage(messageInfo);
			taMessenger.setText("");
		}
		else if (usernameList.isFocusOwner()){
			System.out.println("usernameList is focus owner");
			printChatHistory();
		}
//		else if(e.getSource() == username) {
//			System.out.println("username is being changed"); 								//////////////////username update
//			System.out.println("username is " + username);
//			oldUsername = username.getText();
//
//			Map<String, String> messageInfo = new HashMap<String, String>();
//			messageInfo.put("type", "name change");
//			messageInfo.put("sender", this.username.getText());
//			messageInfo.put("recipient", this.username.getText());
//			messageInfo.put("message", this.username.getText());
//		}
		else if(e.getSource() == loginBtn) {
			System.out.println("actionPerformed: in loginBtn");

			// ok it is a connection request
			String username = this.username.getText().trim();
			// empty serverAddress ignore it
			String server = tfServer.getText().trim();
			// empty or invalid port number, ignore it
			String portNumber = tfPort.getText().trim();
			int port = 0;
			try {
				port = Integer.parseInt(portNumber);
			}
			catch(Exception en) {
				return;   // nothing to do if port number is invalid
			}

			// try creating a new Client
			client = new ChatterClient(server, Integer.parseInt(portNumber), username, this);
			// test if we can start the Client
			if(!client.start()) 
				return;
			connected = true;

			if (client.getNameList() != null) {
				for (int i = 0; i < client.getNameList().size(); i++) {
					usernameList.addItem(client.getNameList().get(i));
				}				
			}

			//enable username List
			usernameList.setEnabled(true);
			// disable login button
			loginBtn.setEnabled(false);
			// enable the 2 buttons
			exitBtn.setEnabled(true);
			sendBtn.setEnabled(true);
			// disable the Server and Port JTextField
			tfServer.setEditable(false);
			tfPort.setEditable(false);
			taMessenger.setEditable(true);	
			taMessenger.setFocusable(true);
			// Action listener for when the user enter a message
			taMessenger.addFocusListener(new FocusListener() {
				public void focusGained(FocusEvent e) {}
				public void focusLost(FocusEvent e) {}
			});
			
			printChatHistory();
		}
	}

	public void printChatHistory() {
		taMsgHistory.setText("");
		taMessenger.setText("");
		String curSelection = (String) usernameList.getSelectedItem();

		if ((!(curSelection.equals(null)) && curSelection.equals("Group"))) {
			for (int i = 0; i<client.getAllHistoryList().size(); i++) {
				ChatterMessage cm = client.getAllHistoryList().get(i);
				if (cm.getMessageType().equals("public") ) {
					taMsgHistory.append(cm.getSender()+ ": " + cm.getMessage());

				}
			}
		}
		else if ((!(curSelection.equals(null)))) {
			for (int i = 0; i<client.getAllHistoryList().size(); i++) {
				ChatterMessage cm = client.getAllHistoryList().get(i);
				if ( ((cm.getSender().equals((String) curSelection)) && cm.getMessageType().equals("private"))
						|| (cm.getSender().equals(username.getText()) && cm.getRecipient().equals(curSelection)) ) {
					taMsgHistory.append(cm.getSender()+ ": " + cm.getMessage());
				}
			}
		}
	}

	public JTextArea getTAMsgHist() {
		return taMsgHistory;
	}
	
	public ChatterClient getClient() {
		return client;
	}
	
	public JComboBox getUNameList() {
		return usernameList;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}


	public String getUsername() {
		return username.getText();
	}
}
