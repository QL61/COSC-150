package paint;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Circle class
 * 
 * @author Mark Ozdemir (mo732)
 *
 */
public class Oval extends Shape {
	
	//constants
	private static final double DEFAULT_EMPTY_VALUE = 0.0;
	private static final String SIDE_STRING_1 = "side1";
	
	//class member variables
	private static final int RADIUS_POWER = 2;
	private double radius;
		
	/**
	 * Circle constructor
	 * @param args	a hashmap that contains the shape and associated side values
	 */
	Oval(HashMap<String, Double> args){
		setRadius((Double)args.getOrDefault(SIDE_STRING_1, DEFAULT_EMPTY_VALUE));
	}
	
	/**
	 * set radius of Circle
	 * @param radius
	 */
	private void setRadius(double radius) {
		this.radius = radius;
	}
	
	/**
	 * 
	 * @return radius
	 */
	protected double getRadius() {
		return radius;
	}
		
	/**
	 * calculate area
	 * @return area
	 */
	public double getArea() {
		double area = 0;
		area = Math.pow(radius, RADIUS_POWER) * Math.PI;
		return area;
	}

	/**
	 * calculate perimeter
	 * @return perimeter
	 */
	public double getPerimeter() {
		double perimeter = 0;
		perimeter = RADIUS_POWER * radius * Math.PI;
		return perimeter;
	}

//	@Override
//	public void setV1(Coordinates c) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void setV2(Coordinates c) {
//		// TODO Auto-generated method stub
//		
//	}

	@Override
	public void setCoordinates(ArrayList<Coordinates> coordList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drawShape(Graphics g) {
		// TODO Auto-generated method stub
		
	}
	
}
