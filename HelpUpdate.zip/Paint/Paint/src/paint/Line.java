package paint;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

//calculates length of line

public class Line extends Shape {
	private static final int MAX_COORD = 2;
	
	private double length = 0;
	private Coordinates v1, v2;
	
	// CONSTRUCTOR
	public Line(Coordinates press, Coordinates release, Color color) {
		this.v1 = press;
		this.v2 = release;
		this.length = distanceBetween(this.v1, this.v2);
		this.color = color;
	}

	// METHODS
	public double getLength() { return length; }
	@Override public double getArea() { return 0; }
	@Override public double getPerimeter() { return 0; }
	public void setV1(Coordinates c) {
		v1 = c;
		this.length = distanceBetween(this.v1, this.v2);
	} // END setV1(Coordinates)
	public void setV2(Coordinates c) {
		v2 = c;
		this.length = distanceBetween(this.v1, this.v2);
	} // END setV2(Coordinates)

	@Override
	public void setCoordinates(ArrayList<Coordinates> coordList) {
		int currentPos = 0;
		if (coordList.size() >= MAX_COORD) {
			setV1(coordList.get(currentPos));
			currentPos++;
			setV2(coordList.get(currentPos));
			this.length = distanceBetween(this.v1, this.v2);
		}
		else System.out.println("Invalid number of coordinates");
	}

	@Override
	public void drawShape(Graphics g) {
		g.drawLine(v1.getX(),v1.getY(), v2.getX(), v2.getY());	
		g.setColor(getColor());
	}
}
