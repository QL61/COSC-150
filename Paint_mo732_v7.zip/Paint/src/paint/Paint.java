package paint;


/**
 * Paint class that contains main function for program.
 * 
 * @author Mark Ozdemir (mo732)
 */

public class Paint {

	//constants
	private static final String WELCOME_MESSAGE = "Welcome to the Paint.\n";

	public static void main(String[] args) {

		System.out.println(WELCOME_MESSAGE);
		new Drawing();

	}	
}