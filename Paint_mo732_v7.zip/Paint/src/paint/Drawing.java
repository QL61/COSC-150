package paint;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Drawing extends JFrame implements MouseListener,  MouseMotionListener, ActionListener, ChangeListener {

	
	private static final String RECTANGLE_STRING = "Rectangle";
	private static final String OVAL_STRING = "Oval";
	private static final String TRIANGLE_STRING = "Triangle";
	private static final String LINE_STRING = "Line";
	private static final String TOTAL_AREA_STRING = "Total Area";
	private static final String TOTAL_PER_STRING = "Total Perimeter";
	private static final String ROUND_FORMAT = "#.###";
	
	private static final String ERR_EXIT_MSG = "Now, gracefully exiting program... ";
	private static final String TOT_AREA_MSG = "totalArea=";
	private static final String TOT_PER_MSG = "totalPerimeter=";
	
	private static final int WINDOW_HEIGHT = 500;
	private static final int COLOR_PALLETE_WIDTH = 50;
	private static final int COLOR_PALLETE_HEIGHT = 30;
	static final int REQ_TRI_CO = 3; //needed for required triangle presses
	
	private JPanel panelButtons = new JPanel();
	private JPanel panelColors = new JPanel();
	private JButton rectangleButton;
	private JButton ovalButton;
	private JButton triangleButton;
	private JButton lineButton;
	private JButton totAreaButton;
	private JButton totPerButton;
	private JLabel colorPalLabel = new JLabel ("Colors");
	
	
	//for color pallette
	private static final int COLOR_COL = 1;
	private static final int COLOR_ROW = 9;

	private static final int NEGATIVE_INT = -1;
	private Swatch b; // this is the special box out to the side that shows the
	// chosen color
	private Swatch[][] boxes; // 2-d array of Box objects, form a color pallet
	//end for color pallete

	// attributes for line
	private int downX, downY; // where the mouse is when button is pressed
	private int mouseX, mouseY; // mouse last seen at
	private int upX, upY; // where mouse is when button is released
	//end attributes for line

	//for triangle
	ArrayList<Coordinates> trianglePresses = new ArrayList<Coordinates>();
	
	
	private boolean lineExists = false;
	private boolean rectangleExists = false;
	private boolean ovalExists = false;
	private boolean triangleExists = false;
	private boolean mouseOnShape = false;
	private boolean onColorPal = false;
		
	private ShapesList allShapes = new ShapesList();
	
	private int selectedShapeIndex = 0;
	
	public Drawing() {
		setDefaultCloseOperation( EXIT_ON_CLOSE );
		setTitle("Paint Program");

		panelButtons.setLayout(new GridLayout(2, 4));
		
		addMouseListener(this);
		addMouseMotionListener(this);
		
		//add buttons to panel
		rectangleButton	= new JButton(RECTANGLE_STRING); // makes the object
		panelButtons.add(rectangleButton); // adds it to the window
		rectangleButton.addActionListener(this); // so when you press on it, something happens

		ovalButton = new JButton(OVAL_STRING);
		panelButtons.add(ovalButton);
		ovalButton.addActionListener(this);

		triangleButton = new JButton(TRIANGLE_STRING);
		panelButtons.add(triangleButton);
		triangleButton.addActionListener(this);

		lineButton = new JButton(LINE_STRING);
		panelButtons.add(lineButton);
		lineButton.addActionListener(this);
			
		totAreaButton = new JButton(TOTAL_AREA_STRING);
		panelButtons.add(totAreaButton);
		totAreaButton.addActionListener(this);
		
		totPerButton = new JButton(TOTAL_PER_STRING);
		panelButtons.add(totPerButton);
		totPerButton.addActionListener(this);
		//finished adding buttons to panel
		
		panelColors.add(colorPalLabel);
		
		
		
		// declare array and fill with 8 boxes
		boxes = new Swatch[COLOR_ROW][COLOR_COL];
		for ( int i=0; i<COLOR_ROW; i++ )
		{
			for ( int j=0; j<COLOR_COL; j++ )
			{
				boxes[i][j] = new Swatch(0, WINDOW_HEIGHT/4+COLOR_PALLETE_HEIGHT*i );
			}
		}
		b = new Swatch(0, WINDOW_HEIGHT/3 + COLOR_PALLETE_HEIGHT*COLOR_ROW);
		
		add(panelButtons, BorderLayout.NORTH);
		add(panelColors, BorderLayout.LINE_START);
		setSize(500,500);
		setVisible(true);
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("click at x="+e.getX()+" y="+e.getY());

		int boxi=0, boxj=0; // index of the clicked on box in the double array
		int mx = e.getX();  int my = e.getY();
		// convert window coords to box array indexes.
		boxi = (mx)/COLOR_PALLETE_WIDTH; // convert mouse x to box index
		boxj = (my-WINDOW_HEIGHT/4)/COLOR_PALLETE_HEIGHT;

		System.out.println("mouseClicked");
		
		if (onColorPal)
		{
			System.out.println("click at boxi="+boxi+" boxj="+boxj);
			b.setColor( boxes[boxj][boxi].getColor() );
			repaint();
		}
		else if (triangleExists && !mouseOnShape) {
			
			System.out.println("inside mouseclicked: if tria exists");
			downX = e.getX();
			downY = e.getY();

			trianglePresses.add(new Coordinates(downX, downY));
			
			repaint();
		}
		mouseOnShape = false;
	}

	// record position of mouse when mouse button is pressed
	@Override public void mousePressed ( MouseEvent m )
	{
		System.out.println("inside mousepressed");
		boolean topShape = false;
		int boxi=0, boxj=0; // index of the clicked on box in the double array
		int mx = m.getX();  int my = m.getY();
		boxi = (mx)/COLOR_PALLETE_WIDTH; // convert mouse x to box index
		boxj = (my-WINDOW_HEIGHT/4)/COLOR_PALLETE_HEIGHT;
		
		
		if (!( m.getX() <= COLOR_PALLETE_WIDTH && boxi < COLOR_COL
				&& (boxj > NEGATIVE_INT && boxj < COLOR_ROW)))
		{
			System.out.println("inside mousepressed first if");

			for(int i = 0; i < allShapes.listSize() && !topShape; i++ ) {
				if (allShapes.getShape(i).isInRange(new Coordinates(m.getX(), m.getY()))) {
					System.out.println("inside mousepressed second if");

					selectedShapeIndex = i;
					mouseOnShape = true;
					topShape = true;
					System.out.println("inside mousepressed for ontop of shapes");
					downX = m.getX(); 
					downY = m.getY();
				}
			}
			if(!mouseOnShape && (lineExists || rectangleExists || ovalExists))
			{
				mouseX = downX = m.getX(); 
				mouseY = downY = m.getY();
			}
		}
		else onColorPal = true;
	}	
	
	@Override
	public void mouseReleased( MouseEvent m )
	{
		System.out.println("inside mousereleased");
		if (!onColorPal) {
			if (mouseOnShape) {
				mouseX = upX = m.getX();
				mouseY = upY = m.getY();
				allShapes.getShape(selectedShapeIndex).resize(new Coordinates(downX, downY), new Coordinates(upX, upY));
				repaint();
			}
			else if ( lineExists || rectangleExists || ovalExists 
					|| (triangleExists && trianglePresses.size() == REQ_TRI_CO) )
			{
				mouseX = upX = m.getX();
				mouseY = upY = m.getY();
				System.out.println("up X " + upX + " up Y " + upY);
				repaint();
			}
		}
	}

	// MouseMotionListener methods (just 2 needed)
	// when the mouse is dragged, update the mouseXY position
	public void mouseDragged ( MouseEvent m )
	{
		if(mouseOnShape) {
			mouseX = m.getX();
			mouseY = m.getY();	
		}
		else if(lineExists || rectangleExists || ovalExists)
		{
			mouseX = m.getX();
			mouseY = m.getY();
		}
	}
	
	@Override
	public void actionPerformed( ActionEvent e )
	{
		System.out.println("inside actionPerformed");
		DecimalFormat df = new DecimalFormat(ROUND_FORMAT); //used to round to three decimal places
		lineExists = ovalExists = triangleExists = rectangleExists = false;
		System.out.println("Shape picked");
		if ( e.getSource()==ovalButton ) { 
			System.out.println(OVAL_STRING + " selected"); 
			ovalExists = true;
		}
		else if ( e.getSource()==triangleButton ) { 
			System.out.println(TRIANGLE_STRING + " selected"); 
			triangleExists = true;
		}
		else if ( e.getSource()==rectangleButton ) { 
			System.out.println(RECTANGLE_STRING + " selected"); 
			rectangleExists = true;
		}
		else if ( e.getSource()==lineButton ) { 
			System.out.println(LINE_STRING + " selected"); 
			lineExists = true;
		}
		else if ( e.getSource()==totAreaButton ) { 								//
			System.out.println(TOTAL_AREA_STRING + " selected");
			JOptionPane.showMessageDialog(this, TOT_AREA_MSG + df.format(allShapes.getTotalArea()));
		}
		else if ( e.getSource()==totPerButton ) { 
			System.out.println(TOTAL_PER_STRING + " selected");
			JOptionPane.showMessageDialog(this, TOT_PER_MSG + df.format(allShapes.getTotalPerimeter()));
		}

	}
	
	// draw the grid of boxes and also the picked one
	public void paint( Graphics g )
	{
		super.paint(g);
		
		//color pallete painting
		b.drawMe(g);
		for ( int i=0; i<COLOR_ROW; i++ )
		{
			for ( int j=0; j<COLOR_COL; j++ )
			{
				boxes[i][j].drawMe(g);
			}
		}
		g.setColor(b.getColor());
		
		//paint all current shapes
		for (int i = 0; i < allShapes.listSize(); i++) {
			allShapes.getShape(i).drawShape(g);
		}
		
		if (onColorPal) onColorPal = false;
		else if (mouseOnShape) mouseOnShape = false;
		//paint new line
		else if(lineExists)
		{
			System.out.println("line exists true and entered in paint");			
			Shape tempLine = new Line(new Coordinates(downX, downY), new Coordinates(mouseX, mouseY), b.getColor());
			allShapes.addToList(tempLine);
			tempLine.drawShape(g);
		}
		//paint new rectangle
		else if(rectangleExists)
		{
			System.out.println("rectangle exists true and entered in paint");
			Shape tempRect = new Rectangle(new Coordinates(downX, downY), new Coordinates(mouseX, mouseY), b.getColor());
			allShapes.addToList(tempRect);
			tempRect.drawShape(g);
		}
		//paint new oval
		else if(ovalExists)
		{
			System.out.println("oval exists true and entered in paint");
			Shape tempOval = new Oval(new Coordinates(downX, downY), new Coordinates(mouseX, mouseY), b.getColor());
			allShapes.addToList(tempOval);
			tempOval.drawShape(g);
		}
		//paint new triangle
		else if(triangleExists && trianglePresses.size() == REQ_TRI_CO)
		{
			System.out.println("traingle exists true and entered in paint");
			Shape tempTriangle = new Triangle(trianglePresses, b.getColor());
			allShapes.addToList(tempTriangle);
			System.out.println("added triag to list");
			tempTriangle.drawShape(g);
			//clear arrayList after each use
			while (!(trianglePresses.isEmpty()))
			{
				int firstPos = 0;
				trianglePresses.remove(firstPos);
				System.out.println("triangle Presses is empty? " + trianglePresses.isEmpty());
			}
		}
	}	


	/** unused functions **/
	@Override
	public void mouseEntered(MouseEvent arg0) { }
	
	@Override
	public void mouseMoved(MouseEvent arg0) { }
	
	@Override
	public void mouseExited(MouseEvent arg0) { }
	
	@Override
	public void stateChanged(ChangeEvent e) { }
}
