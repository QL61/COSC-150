package paint;
import java.util.HashMap;

/**
 * Rectangle class
 * 
 */

//calculates area and perimeter for rectangles
public class Rectangle extends Shape {
	
	// FIELDS
	private	double height = 0, width = 0;
	Coordinates v3, v4; // start with v1 at top left, go clockwise

	// CONSTRUCTOR
	public Rectangle(Coordinates press, Coordinates release) {
		this.v1 = press;
		this.v2 = new Coordinates(release.x, press.y);
		this.v3 = release;
		this.v4 = new Coordinates(press.x, release.y);
		updateDimensions();
	}
	
	// METHODS
	public double getArea() { return height * width; }
	public double getPerimeter() { return (2 * height) + (2 * width); }
	
	// methods to adapt to changing a vertex
	@Override public void setV1(Coordinates newCoordinates) {
		this.v1 = newCoordinates;
		this.v2.y = this.v1.y;
		this.v4.x = this.v1.x;
		updateDimensions();
	}
	@Override public void setV2(Coordinates newCoordinates) {
		this.v2 = newCoordinates;
		this.v1.y = this.v2.y;
		this.v3.x = this.v2.x;
		updateDimensions();
	}
	public void setV3(Coordinates newCoordinates) {
		this.v3 = newCoordinates;
		this.v4.y = this.v3.y;
		this.v2.x = this.v3.x;
		updateDimensions();
	}
	public void setV4(Coordinates newCoordinates) {
		this.v4 = newCoordinates;
		this.v3.y = this.v4.y;
		this.v1.x = this.v4.x;
		updateDimensions();
	}
	
	// use top-left, top-right, and bottom-left vertices to calculate height and width
	private void updateDimensions() {
		this.height = distanceBetween(v1, v4);
		this.width = distanceBetween(v1, v2);
	}
}