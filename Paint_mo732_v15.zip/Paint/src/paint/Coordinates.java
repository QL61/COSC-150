package paint;


//stores a single 2-tuple
public class Coordinates {
	
	// FIELDS
	private int x, y;
	
	// CONSTRUCTOR
	public Coordinates(int xval, int yval) {
		setX(xval);
		setY(yval);
	}
	
	protected void setX(int xVal) {
		this.x = xVal;
	}
	
	protected void setY(int yVal) {
		this.y = yVal;
	}
	
	protected int getX() {
		return x;
	}
	protected int getY() {
		return y;
	}
}
