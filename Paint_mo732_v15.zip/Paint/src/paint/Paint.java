package paint;


/**
 * Paint class that contains main function for program.
 * 
 * @author Christian Collier (chc46), Qingyue Li (ql61), Mark Ozdemir (mo732)
 */

public class Paint {

	//constants
	private static final String WELCOME_MESSAGE = "Welcome to the Paint.\n";
	private static final String ERR_EXIT_MSG = "Now, gracefully exiting program... ";

	public static void main(String[] args) {
		try {
			System.out.println(WELCOME_MESSAGE);
			new Drawing();
		}
		catch (Exception e) {
			System.out.println(ERR_EXIT_MSG);
		}
	}	
}