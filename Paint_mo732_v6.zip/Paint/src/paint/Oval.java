package paint;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

/**
 * Oval class
 */

// calculates area and perimeter for ovals

import java.lang.Math;

public class Oval extends Shape {
	
	// FIELDS
	private	double maj = 0, min = 0;
	private Coordinates v1, v2;

	// CONSTRUCTOR
	public Oval(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(release);
		this.updateAxes();
		this.color = color;
	}
	
	// METHODS
	@Override public double getArea() {
		return Math.PI * maj * min;
	}
	@Override public double getPerimeter() { // calculated using Ramanujan's Formula 1
		return Math.PI*(3*(maj+min)-Math.sqrt((3*maj+min)*(maj+3*min)));
	}
	public void setV1(Coordinates c) {
//		this.v2.x += this.v1.x - c.x;
//		this.v2.y += this.v1.y - c.y;
		this.v1 = c;
		this.updateAxes();
	}
	public void setV2(Coordinates c) {
//		this.v1.x += this.v2.x - c.x;
//		this.v1.y += this.v2.y - c.x;
		this.v2 = c;
		this.updateAxes();
	}
	
	public void setMajAxis(double w) {
		this.maj = w;
	}
	
	public void setMinAxis(double h) {
		this.min = h;
	}
	
	public Coordinates getV1() {
		return v1;
	}
	
	public Coordinates getV2() {
		return v2;
	}
	
	public double getMajAxis() {
		return maj;
	}
	
	public double getMinAxis() {
		return min;
	}
	
	private void updateAxes() {
		if (getV1() != null && getV2() != null ) {
			double h = Math.abs((v1.getX() - v2.getX()));
			double v = Math.abs((v1.getY() - v2.getY()));

			setMajAxis(h);
			setMinAxis(v);
		}
	}

	@Override
	public boolean isInRange(Coordinates c) {
		boolean inRange = false;
		Ellipse2D curOval = new Ellipse2D.Double(v1.getX(), v1.getY(), getMajAxis(), getMinAxis());
		if (curOval.contains(c.getX(), c.getY())) {
			inRange = true;
		}
		return inRange;
	}
	
	@Override
	public void drawShape(Graphics g) {
		int tempY1 = v2.getY();
		int tempY2 = v1.getY();
		int tempX1 = v2.getX();
		int tempX2 = v1.getX();
		
		g.setColor(getColor());
		if(v1.getX() < v2.getX() && v1.getY() > v2.getY()) {
			v1.setY(tempY1);
			v2.setY(tempY2);
		}
		else if(v1.getX() > v2.getX() && v1.getY() < v2.getY()) {
			v1.setX(tempX1);
			v2.setX(tempX2);
		}
		else if(v1.getX() > v2.getX() && v1.getY() > v2.getY()) {
			v1.setY(tempY1);
			v2.setY(tempY2);
			v1.setX(tempX1);
			v2.setX(tempX2);
		}
		g.drawOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
		g.fillOval(v1.getX(), v1.getY(), (int)getMajAxis(), (int)getMinAxis());
		
	}
	
	@Override
	public void resize (Coordinates press, Coordinates release) {
		if (isInRange(press)) {
			if (distanceBetween(press, v1) <= distanceBetween(press, v2) ) setV1(release);
			else setV2(release);
			updateAxes();
		} // END if
	}
	
}





