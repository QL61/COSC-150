package paint;

import java.awt.Color;
import java.util.ArrayList;

public class ShapesList {

	/********** FIELDS **********/
	private ArrayList<Shape> list = new ArrayList<Shape>();
	private double totalArea = 0, totalPerimeter = 0;

	/*********** METHODS **********/

	//ADD TO LIST
	public void addToList(Shape s) {
		list.add(s);
		setTotalArea(calculateTotalArea());
		setTotalPer(calculateTotalPerimeter());
	}
	
	
	public double calculateTotalArea() {
		double sum = 0;
		for (int i = 0; i < list.size(); i++)
		{
			sum += (list.get(i)).getArea();

		}
		return sum;
	}

	public double calculateTotalPerimeter() {
		double sum = 0;
		for (int i = 0; i < list.size(); i++)
		{
			sum += (list.get(i)).getPerimeter();

		}
		return sum;
	}

	private void setTotalArea(double area) {
		totalArea = area;
	}
	
	private void setTotalPer(double per) {
		totalPerimeter = per;
	}
	
	public double getTotalArea() {
		return this.totalArea;
	}

	public double getTotalPerimeter() {
		return this.totalPerimeter;
	}
	
	public int listSize() {
		return list.size();
	}
	
	public Shape getShape(int index) {
		return list.get(index);
	}

} // END class ShapesList
