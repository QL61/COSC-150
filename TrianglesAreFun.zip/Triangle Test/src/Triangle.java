import java.awt.*;

import java.awt.geom.*;

import javax.swing.JPanel;

import javax.swing.JComponent;

 

 

public class Triangle extends JComponent

{

     

    public Triangle (int [] xValues, int [] yValues)

    {

        xCoordinate = xValues;

        yCoordinate = yValues;

    }

     

    public void paintComponent (Graphics g)

    {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        Point2D.Double pointA = new Point2D.Double(xCoordinate[0], yCoordinate[0]);

        Point2D.Double pointB = new Point2D.Double(xCoordinate[1], yCoordinate[1]);

        Point2D.Double pointC = new Point2D.Double(xCoordinate[2], yCoordinate[2]);

        Line2D.Double sideA = new Line2D.Double(pointA, pointB);

        Line2D.Double sideB = new Line2D.Double(pointA, pointC);

        Line2D.Double sideC = new Line2D.Double(pointB, pointC);

        g2.draw(sideA);

        g2.draw(sideB);

        g2.draw(sideC);

    }
     

    private int [] xCoordinate;

    private int [] yCoordinate;

}

