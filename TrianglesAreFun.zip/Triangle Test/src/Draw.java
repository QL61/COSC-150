import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Draw
{

    public static void main (String [] args)

    {

        final JFrame frame = new JFrame();

        frame.setVisible(true);

        frame.setTitle("Draw Triangles and Circles");

        frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final int [] xCoordinate = new int [3];

        final int [] yCoordinate = new int [3];

        class MousePressListener implements MouseListener

        {
            public void mousePressed (MouseEvent event)

            {

                xCoordinate[counter] = event.getX();

                yCoordinate[counter] = event.getY();

                System.out.println("(" + xCoordinate[counter] + ", " + yCoordinate[counter] + ")");

                counter++;

                if (counter % 3 == 0)

                {

                    frame.add(new Triangle(xCoordinate, yCoordinate));
                    frame.validate();
                    counter = 0;

                }

            }

            public void mouseReleased(MouseEvent event) {}

            public void mouseClicked(MouseEvent event) {}

            public void mouseEntered(MouseEvent event) {}

            public void mouseExited(MouseEvent event) {}

        }

        MouseListener listener = new MousePressListener();

        frame.addMouseListener(listener);

    }

    private static int counter = 0;
    private static final int FRAME_WIDTH = 400;
    private static final int FRAME_HEIGHT = 400;
}
