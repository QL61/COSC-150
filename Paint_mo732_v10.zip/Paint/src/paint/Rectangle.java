package paint;
import java.awt.Color;
import java.awt.Graphics;

/**
 * Rectangle class
 * 
 */

//calculates area and perimeter for rectangles
public class Rectangle extends Shape {
	
	// FIELDS
	private	double height = 0, width = 0;
	Coordinates v1, v2, v3, v4; // start with v1 at top left, go clockwise

	// CONSTRUCTOR
	public Rectangle(Coordinates press, Coordinates release, Color color) {
		setV1(press);
		setV2(new Coordinates(release.x, press.y));
		setV3(release);
		setV4(new Coordinates(press.x, release.y));
		this.color = color;
		updateDimensions();
	}
	
	// METHODS
	public double getArea() { return height * width; }
	public double getPerimeter() { return (2 * height) + (2 * width); }
	
	// methods to adapt to changing a vertex
	public void setV1(Coordinates newCoordinates) {
		this.v1 = newCoordinates;
		updateDimensions();
	}
	public void setV2(Coordinates newCoordinates) {
		this.v2 = newCoordinates;
		updateDimensions();
	}
	public void setV3(Coordinates newCoordinates) {
		this.v3 = newCoordinates;
		updateDimensions();
	}
	public void setV4(Coordinates newCoordinates) {
		this.v4 = newCoordinates;
		updateDimensions();
	}
	
	public void setHeight(double d) {
		this.height = d;
	}
	
	public void setWidth(double aWidth) {
		this.width = aWidth;
	}
	
	public Coordinates getV1() {
		return v1;
	}
	public Coordinates getV2() {
		return v2;
	}
	public Coordinates getV3() {
		return v3;
	}
	public Coordinates getV4() {
		return v4;
	}
	
	
	// use top-left, top-right, and bottom-left vertices to calculate height and width
	private void updateDimensions() {
		if (getV1() != null && getV2() != null && getV3() != null && getV4() != null ) {
			setHeight(distanceBetween(getV1(), getV4()));
			setWidth(distanceBetween(getV1(), getV2()));
		}
	}

	@Override
	public void drawShape(Graphics g) {
		int tempY1 = v1.getY();
		int tempY2 = v2.getY();
		int tempY3 = v3.getY();
		int tempY4 = v4.getY();
		int tempX1 = v1.getX();
		int tempX2 = v2.getX();
		int tempX3 = v3.getX();
		int tempX4 = v4.getX();		
		
		if(v1.getX() < v3.getX() && v1.getY() > v3.getY()) {
			v1.setY(tempY4);
			v4.setY(tempY1);
			v2.setY(tempY3);
			v3.setY(tempY2);
		}
		else if(v1.getX() > v3.getX() && v1.getY() < v3.getY()) {
			v1.setX(tempX2);
			v2.setX(tempX1);
			v3.setX(tempX4);
			v4.setX(tempX3);
		}
		else if(v1.getX() > v3.getX() && v1.getY() > v3.getY()) {
			v1.setY(tempY3);
			v1.setX(tempX3);
			v3.setY(tempY1);
			v3.setX(tempX1);
			v2.setY(tempY4);
			v2.setX(tempX4);
			v4.setY(tempY2);
			v4.setX(tempX2);
		}

		g.setColor(getColor());
		g.drawRect(v1.getX(), v1.getY(), (int)width, (int)height);
		g.fillRect(v1.getX(), v1.getY(), (int)width, (int)height);
	}
	
	@Override
	public boolean isInRange(Coordinates c) {
		System.out.println("in Rectangle: isInRange ");
		
		boolean inRange = false;
		// check that coordinate is on or inside rectangle
		if ( (c.getX() >= v1.getX() && c.getY() >= v1.getY()) && (c.getX() <= v3.getX() && c.getY() <= v3.getY()) ) {
			System.out.println("isInRange is true");
			inRange = true;
		}
		return inRange;

	} // END isInRange(Coordinates)

	@Override
	public void resize (Coordinates press, Coordinates release) {
		if (isInRange(press)) {
			if (distanceBetween(press, v1) < distanceBetween(press, v2) && distanceBetween(press, v1) < distanceBetween(press, v4)) {
				this.setV1(release);
				v2.setY(release.getY());
				v4.setX(release.getX());
			}
			else if (distanceBetween(press, v2) < distanceBetween(press, v3) && distanceBetween(press, v2) < distanceBetween(press, v1)) {
				this.setV2(release);
				v1.setY(release.getY());
				v3.setX(release.getX());
			}
			else if (distanceBetween(press, v3) < distanceBetween(press, v2) && distanceBetween(press, v3) < distanceBetween(press, v4)) {
				this.setV3(release);
				v2.setX(release.getX());
				v4.setY(release.getY());
				
			}
			else { 
				this.setV4(release); 
				v1.setX(release.getX());
				v3.setY(release.getY());
			}
			updateDimensions();
		} // END if
	} // END resize

}